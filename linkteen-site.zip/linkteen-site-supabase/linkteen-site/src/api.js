import { supabase } from "./supabaseClient";

const fmtTime = (iso) =>
  new Date(iso).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });

/* ---------------- Auth ---------------- */
export async function signUp(email, password, role) {
  const { data, error } = await supabase.auth.signUp({
    email,
    password,
    options: { data: { role } },
  });
  if (error) throw error;
  return data;
}

export async function signIn(email, password) {
  const { data, error } = await supabase.auth.signInWithPassword({ email, password });
  if (error) throw error;
  return data;
}

export async function signOut() {
  await supabase.auth.signOut();
}

/* ---------------- Profiles ---------------- */
export async function getMyProfile() {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return null;
  const { data } = await supabase.from("profiles").select("*").eq("id", user.id).maybeSingle();
  return data;
}

export async function getProfile(id) {
  const { data } = await supabase.from("profiles").select("*").eq("id", id).maybeSingle();
  return data;
}

export async function upsertProfile(fields) {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) throw new Error("Not signed in");
  const { data, error } = await supabase
    .from("profiles")
    .upsert({ id: user.id, ...fields })
    .select()
    .single();
  if (error) throw error;
  return data;
}

/* ---------------- Mentors & journeys ---------------- */
export async function fetchMentorsRaw() {
  const { data: mentors } = await supabase.from("profiles").select("*").eq("role", "mentor");
  if (!mentors || mentors.length === 0) return [];
  const ids = mentors.map((m) => m.id);
  const { data: exps } = await supabase
    .from("experiences").select("*").in("mentor_id", ids).order("position");
  return mentors.map((m) => ({
    ...m,
    experiences: (exps || []).filter((e) => e.mentor_id === m.id),
  }));
}

export async function fetchMyExperiences() {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return [];
  const { data } = await supabase
    .from("experiences").select("*").eq("mentor_id", user.id).order("position");
  return data || [];
}

export async function addExperience(e, position) {
  const { data: { user } } = await supabase.auth.getUser();
  const { data, error } = await supabase
    .from("experiences")
    .insert({ mentor_id: user.id, title: e.t, story: e.story || "", why: e.why || "", note: e.note || "", position })
    .select().single();
  if (error) throw error;
  return data;
}

/* ---------------- Milestones ---------------- */
const rowToMilestone = (r) => ({
  id: r.id, title: r.title, desc: r.description, date: r.target_date,
  category: r.category, tag: r.tag, status: r.status, mentorId: r.mentor_ref,
});

export async function fetchMilestones() {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return [];
  const { data } = await supabase
    .from("milestones").select("*").eq("student_id", user.id).order("position");
  return (data || []).map(rowToMilestone);
}

export async function addMilestone(m, position) {
  const { data: { user } } = await supabase.auth.getUser();
  const { data, error } = await supabase
    .from("milestones")
    .insert({
      student_id: user.id, title: m.title, description: m.desc || "",
      target_date: m.date || "", category: m.category || "", tag: m.tag || "",
      status: "Not Started", position, mentor_ref: m.mentorId || null,
    })
    .select().single();
  if (error) throw error;
  return rowToMilestone(data);
}

export async function updateMilestoneStatus(id, status) {
  if (typeof id !== "number") return;
  await supabase.from("milestones").update({ status }).eq("id", id);
}

export async function deleteMilestone(id) {
  if (typeof id !== "number") return;
  await supabase.from("milestones").delete().eq("id", id);
}

export async function saveMilestoneOrder(items) {
  for (const it of items) {
    if (typeof it.id === "number") {
      await supabase.from("milestones").update({ position: it.position }).eq("id", it.id);
    }
  }
}

/* ---------------- Messages ---------------- */
export async function sendMessage(recipientId, body) {
  const { data: { user } } = await supabase.auth.getUser();
  const { error } = await supabase
    .from("messages")
    .insert({ sender_id: user.id, recipient_id: recipientId, body });
  if (error) throw error;
}

export async function fetchMyChats(myId) {
  const { data: msgs } = await supabase
    .from("messages").select("*")
    .or(`sender_id.eq.${myId},recipient_id.eq.${myId}`)
    .order("created_at");
  const chats = {};
  const otherIds = new Set();
  (msgs || []).forEach((m) => {
    const other = m.sender_id === myId ? m.recipient_id : m.sender_id;
    otherIds.add(other);
    (chats[other] = chats[other] || []).push({
      from: m.sender_id === myId ? "me" : "them",
      text: m.body,
      time: fmtTime(m.created_at),
    });
  });
  let contacts = [];
  if (otherIds.size) {
    const { data } = await supabase.from("profiles").select("*").in("id", [...otherIds]);
    contacts = data || [];
  }
  return { chats, contacts };
}

export function subscribeToMessages(myId, onIncoming) {
  const channel = supabase
    .channel("incoming-messages")
    .on(
      "postgres_changes",
      { event: "INSERT", schema: "public", table: "messages", filter: `recipient_id=eq.${myId}` },
      (payload) => onIncoming({
        senderId: payload.new.sender_id,
        entry: { from: "them", text: payload.new.body, time: fmtTime(payload.new.created_at) },
      })
    )
    .subscribe();
  return () => supabase.removeChannel(channel);
}
