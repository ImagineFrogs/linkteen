# LinkTeen + Supabase — beginner setup

Follow these once. ~15 minutes. Everything is free.

## A. Create your Supabase project
1. Go to https://supabase.com → **Start your project** → sign up (easiest: "Continue with GitHub").
2. Click **New project**. Pick any name (e.g. `linkteen`), let it generate a database password (you won't need it day-to-day), choose the region closest to you, click **Create new project**. Wait ~2 minutes while it sets up.

## B. Create the database tables
1. In the left sidebar click **SQL Editor** → **New query**.
2. Open the file `supabase-setup.sql` from this project, copy EVERYTHING in it, paste it into the query box, and click **Run**.
3. You should see "Success. No rows returned." Done — your tables, security rules, and realtime are all configured.

## C. Turn off email confirmation (so sign-up works instantly)
1. Left sidebar → **Authentication** → **Sign In / Providers** (may be called "Providers").
2. Click **Email** → turn OFF the "**Confirm email**" toggle → Save.
   (Without this, new users get stuck waiting for a confirmation email.)

## D. Copy your two keys into the code
1. Left sidebar → ⚙️ **Project Settings** → **API** (or "API Keys").
2. You need two values:
   - **Project URL** (looks like `https://abcdefgh.supabase.co`)
   - **anon / public key** (a long string starting with `eyJ...`)
3. Open `src/supabaseClient.js` in this project and replace the two
   PASTE_YOUR_... placeholders with those values. Keep the quotes!
4. The anon key is safe to publish — it's designed to be public.
   Real security comes from the database rules you created in step B.

## E. Run it
```bash
npm install
npm run dev
```
Create a student account and a mentor account (use two different emails —
or open a second browser/incognito window to be both people at once) and
send a message from one to the other. It should appear instantly. 🎉

## F. Publish
Deploy to GitHub Pages exactly like before (push / upload the updated
project). The live site talks to Supabase directly — no extra hosting needed.
