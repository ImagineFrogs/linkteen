-- ============================================================
-- LinkTeen scheduling update
-- Run this in Supabase -> SQL Editor -> New query -> Run
-- (only needed once, if you set up your database before calls existed)
-- ============================================================

alter table public.profiles add column if not exists availability jsonb default '{}'::jsonb;

create table if not exists public.bookings (
  id bigint generated always as identity primary key,
  student_id uuid not null references public.profiles(id) on delete cascade,
  mentor_id uuid not null references public.profiles(id) on delete cascade,
  minutes int not null,
  price int not null,
  day_label text not null,
  time_label text not null,
  status text not null default 'Requested',
  created_at timestamptz default now()
);

alter table public.bookings enable row level security;

drop policy if exists "read own bookings" on public.bookings;
drop policy if exists "student books calls" on public.bookings;
drop policy if exists "mentor updates booking status" on public.bookings;

create policy "read own bookings" on public.bookings
  for select to authenticated using (student_id = auth.uid() or mentor_id = auth.uid());
create policy "student books calls" on public.bookings
  for insert to authenticated with check (student_id = auth.uid());
create policy "mentor updates booking status" on public.bookings
  for update to authenticated using (mentor_id = auth.uid());
