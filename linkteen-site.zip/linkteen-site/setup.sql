-- ============================================================
-- LinkTeen database setup — paste this whole file into
-- Supabase → SQL Editor → New query → Run
-- ============================================================

-- User profiles (one row per signed-up student or mentor)
create table public.profiles (
  id uuid primary key references auth.users on delete cascade,
  role text not null check (role in ('student','mentor')),
  name text not null default '',
  photo_url text,
  grade text,
  target text,
  interests jsonb default '[]',
  school text,
  year int,
  role_title text,
  bio text,
  tags jsonb default '[]',
  created_at timestamptz default now()
);
alter table public.profiles enable row level security;
create policy "profiles readable by everyone" on public.profiles
  for select using (true);
create policy "users insert own profile" on public.profiles
  for insert with check (auth.uid() = id);
create policy "users update own profile" on public.profiles
  for update using (auth.uid() = id);

-- Mentor journey experiences
create table public.experiences (
  id bigint generated always as identity primary key,
  mentor_id uuid not null references public.profiles(id) on delete cascade,
  title text not null,
  story text default '',
  why text default '',
  note text default '',
  position int default 0,
  created_at timestamptz default now()
);
alter table public.experiences enable row level security;
create policy "experiences readable by everyone" on public.experiences
  for select using (true);
create policy "mentors insert own experiences" on public.experiences
  for insert with check (auth.uid() = mentor_id);
create policy "mentors update own experiences" on public.experiences
  for update using (auth.uid() = mentor_id);
create policy "mentors delete own experiences" on public.experiences
  for delete using (auth.uid() = mentor_id);

-- Student roadmap milestones
create table public.milestones (
  id bigint generated always as identity primary key,
  student_id uuid not null references public.profiles(id) on delete cascade,
  title text not null,
  description text default '',
  date text default '',
  category text default '',
  tag text default '',
  status text default 'Not Started',
  position int default 0,
  mentor_ref text,
  created_at timestamptz default now()
);
alter table public.milestones enable row level security;
create policy "students manage own milestones" on public.milestones
  for all using (auth.uid() = student_id) with check (auth.uid() = student_id);

-- Direct messages between users
create table public.messages (
  id bigint generated always as identity primary key,
  sender_id uuid not null references public.profiles(id) on delete cascade,
  recipient_id uuid not null references public.profiles(id) on delete cascade,
  text text not null,
  created_at timestamptz default now()
);
alter table public.messages enable row level security;
create policy "participants read their messages" on public.messages
  for select using (auth.uid() = sender_id or auth.uid() = recipient_id);
create policy "senders write their messages" on public.messages
  for insert with check (auth.uid() = sender_id);

-- Turn on realtime delivery for messages
alter publication supabase_realtime add table public.messages;
