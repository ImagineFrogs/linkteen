import React, { useState, useEffect, useRef } from "react";
import { supabase, SUPABASE_CONFIGURED } from "./supabaseClient";
import * as api from "./api";
import {
  Compass, GraduationCap, Users, Search, MessageCircle, Map, LayoutDashboard,
  Plus, X, ChevronDown, ChevronRight, ArrowRight, Send, Calendar,
  Star, CheckCircle2, Circle, Clock, GripVertical, Sparkles,
  BookOpen, Target, TrendingUp, Camera, Edit3, User, Zap, LogOut
} from "lucide-react";

/* ---------------- Design tokens ---------------- */
const C = {
  primary: "#F48947",
  primaryDark: "#E06F2E",
  accent: "#A465E2",
  bg: "#FFFBF7",
  ink: "#33241B",
  sub: "#96806F",
  line: "#F4E6D8",
  card: "#FFFFFF",
  soft: "#FFF3E8",
  softPurple: "#F5EDFC",
  green: "#3BA55D",
};
const SHADOW = "0 10px 30px rgba(244,137,71,0.10), 0 2px 8px rgba(51,36,27,0.05)";
const SHADOW_SM = "0 4px 14px rgba(51,36,27,0.06)";
const GRAD = "linear-gradient(135deg, #F48947 0%, #C878A8 55%, #A465E2 100%)";
const FREE_MESSAGES = 3;
const R = 20;

/* ---------------- Brand assets ---------------- */
const LOGO_IMG = "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAYEBQYFBAYGBQYHBwYIChAKCgkJChQODwwQFxQYGBcUFhYaHSUfGhsjHBYWICwgIyYnKSopGR8tMC0oMCUoKSj/2wBDAQcHBwoIChMKChMoGhYaKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCj/wAARCACfAKADASIAAhEBAxEB/8QAHAAAAQUBAQEAAAAAAAAAAAAAAAECAwQFBgcI/8QAPRAAAgEDAwEFBgMFBgcAAAAAAQIDAAQRBRIhMQYTQVFhFCJxgZGhFTKxByMzwdEkQmKy4fAlUlRjdJLx/8QAGgEAAwEBAQEAAAAAAAAAAAAAAAECAwQFBv/EACsRAAICAQMDAgYDAQEAAAAAAAABAgMRBCExEkFRYbETIoGRofAjccHR4f/aAAwDAQACEQMRAD8A+paKKKgoKKKKACigkAc1Ezk9OKWRpZJCQOpppkHgKjpKXUUojzIfDFG9qZRSyyulDw7f7FO3N4rUYYjoacXammS4kmeOePjS1AWJ6mgEjoaMi6WT0UxXB68U+mIKKKKYgooooAKKKKACmswX40rttHrUJOTk0m8FJZAkk80lFFQaBRRRQAUUUUAFFFFABRRRQAU9GIOKZRTTwJrJYoqFWKn0qYHIyKpPJm1gKKKKYgoJwMmio5Tk4pMaWRhOTk0lFGag1Cik3Um40ZAdRUbNgEscADJJ8K4i/wC3LLcMthaxvCDgPKxy3qAOgrC7U10LM2dFGls1DarWcHd0delYvZzW4dbgYohiuIyA8ZOcZ6EHxFcP2k1+7vr+aOKZ4rSNyqJGxXODjJx1NZXa6uutWLfPBtRoLLbHW9scnqVFed9i9duhqUVjdTPNBNlULnJRsZGD5cdK6HtL2lj0d1gij7+6YbtpOFQeBP8ASivW1zq+K9kK3QWwt+Ct2zo6K43Q+2YurtLe/hSEyHasiMdufAEHp8a7DcfGtqb4XLqgzG/T2US6bFgdRSbhSggjrWxgFPjbBwelMopoTWSxRTUOVp1UZATgZquT51JMcJUGCamTNILuKW8qSlA55pW4FSWV7e5t7iWWOC4ikkiOHVHBK/GrG2uB1bstf6deG80N5HUEsFRsSJ6f4h/vFVpu02qvby2WoxtGJEMbSrCVkXPjjgGuB6115jdFp/h/U9JaBW4lRNNd/K+h02v69pkcE1kboGaVGiJjG4RkjGWPQV5lIjRSNHKu2ReGU+FS3UC24RNsocjcd8ZQY8MA8/OljvJ0jVNysq8KJEV9vwyDivH1Ood8szWMeD29JpVp4/xvOfJ0HYe7ttMnuby+uBDG8eyMEEmQg5OAOuMfU1k6jFBd388umNmKRywjlIR1yfU4I+Bp1hYXGrQ39wXYm2i7wux4OP7uPgDjHHHrWX1FTOx/CjBr5d8eS4Vx+LKxS+bZNdjd7OSWel6tFc6nL70ediRYk2kjG5iDgY8hk03tfJFc6xLeWsqzWsu0LIvQEKAVPr41iAEkAdTwK1dXs7jQtQa1DndsBZuCsgP+E8Yzkc0Kxulwx8qfPfIOtRvVmfmaxjtgz7SMyzqAcKpDO3gqjqTXq2la9p2qvstZyJjz3Ug2v8vP5V5XLdTSx92zAR5zsRQik+ZAAzUttbrNCZF9ojMRG+RIzIo8jxyp+3qK00updDags55MtZpI6iKc3jHGNz2IjAzUDXdul2tq08QuWGREWG4j4VwcvafW78GCwhZQeA0cRaQjzJ6A1o9mey1zFex6hqrkSo3eLGG3MW83P8q9eOsdslGmLa7vseJLQqmLlfJJ9kt2dkCacGoABzSFa7tzzyWI4bHnUtVkYqepqzVxexlJbkU3JAplPk/PTKT5LjwJ/eoboaCeaaWJqRj/AAoL+pqOlAycedGQweX9uJjN2kuQTkRKkY+Qz+prBq7rc4udYvplOVeZiPhnA/SqgRjGzgDYpVSfVs4/ymvlLM22ycfV/Q+0oSqqhF+Ejs+ycZTsjrMuP4gcZ+Ef+tcUOgrt9LuDa9kxbd0Ns9tNKz55yd+OPgn3FcnPYSQSWqM8bC4CYZDkKWxlT5MAwOPLmuy/TWSrr6V2X5OPS3xVtvU+X7FaPiRD/iH612P7S4/7ZYzY/MjofkQf51ygtZu/lEaNIkEux2A6ctgnwA909a7LtuZLzQbe6mt2gZLjCqxySrDqeOOnSivTThp7epePw2F10Xqamn5/KRwtdh+zWfZqV5DnHeQhh8Vb/WuPrc7FTCLtJagnAkDR/UcfcVyaOXRfF+vvsdOuh16ea9Pbc9UYnb14pajpQxr6rJ8cOHjS00GnUwAipozlahqWLoaaJlwNlODUJJNSz+FQ0pcjjwFFFLg1JQrYB4qlrF0LLSru5zgxxsR8eg+5FPvLkwPHGkZllcEhd20ADGST8xWL2ihv9V002kMUMO51ZmaYkEDnHC+eKi3qUG4842NaYpzj1cZ3OA0a19t1W0tjyJJFDfDqfsDWnra2lvrmrWjK0FvIU2dzHu2MuG/LkcHJrX0HQ5dG1OO9vHiliUFf3WcoW90Mc9Rz96s/hNpf9ptZkvIu9EUkaKhJwMoCScda8rT6SyqCbSzn+9sY7f2e3fra52PDbil285XkRLJ5Oy9rcq693HYuCGGGIw+30z73NcnoEkkmsW0ZWF+/kjUpICVyuAreeRjr6kV3ctvp8MLWhnNvGU2mIXLKNp8ME4ArhbVorLtEj2bd/DBPmJifzADPXx+PpXTqpWRdbg8LKXv+N2Y6NxnG1Nb7v99StFdzRNIi7cSTb5ASdr9RtYeI5P8A9ruO163C9lGW82mRZ0AIbcSuTjJwMmkt+y+lwx77hXmYe8zvIQPPOAQAKp9rmhbRz7NLcSfvU3Zd2THPXdx8KShaqLFY87fbkUrardRW61jD/wCGP2OsodQ1Sa3njRw1u+3cM7W4APyzWTBJJY3schyJbeQE/FTz+ldB+zsZ19//AB2/Vam1Ps3Nf3d7e2MkXcyyM8SPkF/M56AE5x/KvOhpp20RnWt02ehPVQq1EoWvZpHfo6yIrocqwDA+h5FLWL2Zvlbs1bS3Ld2YcwPu6hlO3GPPpxWrbXEdyrGInKnDKylWU+oPNfQQblFSwfM2Q6JOPglpRx0pKKZA8N51LF1NQDqKni6mriTLgWYZWoQoqyRkEVBRJCi+wmKKr3/tHsr+yfxcjyzjPOM8ZxnGeKyu5uZOsOouf+5chB9m/lRgtLJqXlmLhkcSPFKmQrqAeDjIIPUcD6VkQ3DJrd1YNMZu5hjkLFQuCxORx6bfrWnplrLbRSCVvztlYw5YJx0BPJz1rAgtLm27ZajNOp7m5i3RP4EArx8RWVzawkv3DfubUpNSy+Ft91/6XOz1pLL7XLqcr3Dx3TrErN7qquMHaOPXmm2I/wCN663ncIPpEv8AWtHTDtu72PwJSQfNSD/kqrbxd3qWqnOTJOr/AA/dpxRNfL+9xqWZSz+8DZ7WV7a7t451SG53bwYgx94YPOR8s1wOkW3ddqLe0kIbZcmEkdDyRmu5u4pDFdZW6M7Bu4lgkICce6CuR0Poc/auU7NaPqC9pLU3NvJH3LieRnIPGTznJySa4dbCU5VtLLyt12X75PQ0NihCzqlhY49TrIYk1HQoopGbZNAqkqeeg/pVftRb3F3od2bi7du7XvQoRVTK889T96saDFJbactrPjvLeR4mx0IDEj7EVR1jS5r7TTbLAhui4JuXm4YA5OR1HwxXW94yTX0239Nzjg1Gxb8Pn/TmuyEhivb1kJDm0dV+LFQPua9BRFjRY1GFUBQPQcVx2j6Nc6draJO8TKwU5Qn3hkt4+RT7iujvRcyySPZlj7IFdkB/iknJX/0BI9SK59FROFSrksPdnRr7YWXdUHthFW3jeHtBNbbG7iRvblIHu7tuxufPPPzra00Z1K85AHdxD/PTUdXRXRtyMAwI8R4GqawXE0k88DSlBKUZI5O7ZgqgZB8cHdwT+ldlW738f6cVj6kdEwUDrk1GQKwjqE9oCDI7YH8K6iZWPoGA5+hrciYvGjlWQsoO1uoyOh9a1a7mHS4i7cGpouhqKp0GFFKKJk9haikGDnwNS0MMjFUyE8FeilIwcUlQahVDVI37y2njRpBGWV1QZO1h1A8cECr9ISAOaBrZlDTI5DNcXDo8avtRFcYbC55I8Mlj9KjnhuIrueSKHvo5mD+66qVIUAg5xxxWgZR4Cqd7qcdo6rIrHI3MRj3FzjJ5/TyPlRs9il1ZyQ/2z/oW+cyf1qxYW0y3ElxcKqMUEaorbsDJJJPmTj6VDqOrLZRhmjZ+v5ccADk1EdahCK0sywlsja/BBBIx5dQRSSSWYorEmSTpLb3tw4glljmKupjG7DbQpBGeOgOfWhUvZPyWyRDzml5+i5/Wqn49GbSKcGQtIgkEIA3geOfAYAPj4VZXVoe+aL2mMuucgnpjOefkfoaHHfLiGJJYHPpcpYT98jXakbSVIQLggrjOedxOfPFXrG2FrBs3F3LF3fGNzHqf5D0AqtbailxnumV9vXAII+Rq2k6tT6+xLUu5nPaXNszx2caPExJjLNjus9QR4rnkY58PWtCzgW1to4UJIUcserHqSfUnJqYEHoaKCW2+RQSOhIpKKKBCqMsBU9NjXAyepp1WkZyeWFFFFMka65GR1qGrFNdM8jrUtFRlggc7VJqAkk5NWGXgg1TvWe3tZpUXeY0ZgPPAzUNNvBtFoJH29OtZV3p4urh5ZJTkgbQUU7SAR4+HvHjjqagk1dlVN8HeOcncjbQVBI3AHJGSDwak1K8kitoZbYqveIXBdc5GAQPnmkoWRlt3Nkh13YNcWsMQnZWjXbv25LcYPiPKmRaWqSB2md/3bIQR1LZ59PzH60ov5I+5SaBy5SMu4wgBbIPuk5GMHikh1NpY+8FsVRm2xs0gAbAJJP8Ay4A9aP5EsLj6DIPwMe4FuSOMNmMHcfMc8ULo7GaRHUrAHYq+8HKY4GPPJHXjA9TUd1q82WNsECiInkbxu3YyD4jH++Kt/iqhVZo8qykrhxuOAcnb4DKkZzWubktwZYsLaS2muJZ7hriWUjBZcbBycDk8ZNWwTuz41j/jICtut2D8bVDcN88cf61abUfZyO/t9jLtWRTKNwYgHao/vEAj+VZSrsk917C4NcEg8VPG24c9RUOCTgcmpo12j1NKOTKWMDqkRPE0IniakrVIxlLsFFFFUQFFFFABRRRQAhAPWo3iyCMBlIwQalopDTwZDaNp7IqG1QBSSMEjk9fGnXWm29yipKgKr+UcjHGPD0rVIB6imGMeFJ5fc0VjMUaJars2wRZQKFO3pt/L9KaNEtgJQIIgJMbuvOOnw6npW33Z86Tu29KWJeX9yvisxl0O1EQj7iHYEMYGCfdJyR9eal/B7Mzd8YEMpBBbnoRg8dOa1O7b0pRGfOjD8g7PUzfwmyKlTbxkFVTgY4XoM+lJ+D2GYT7Mn7nGzk8Y6ePOPWtQRjxpwUDoKpdXkh2ESxnwGBUioF+NOooSwQ22FFFFMQUUUUAf/9k=";

const SCHOOLS = {
  berkeley: { name: "UC Berkeley", short: "Berkeley", chip: "#003262", chipText: "#FDB515" },
  ucla: { name: "UCLA", short: "UCLA", chip: "#2774AE", chipText: "#FFD100" },
  ucsd: { name: "UC San Diego", short: "UCSD", chip: "#182B49", chipText: "#FFCD00" },
};

const CATS = ["All", "Computer Science", "Engineering", "Pre-Med", "Law", "Business", "Social Impact", "Arts", "Research", "Berkeley-Specific Programs"];

const deriveCats = (tags, bio) => {
  const hay = (tags.join(" ") + " " + (bio || "")).toLowerCase();
  const map = {
    "Computer Science": ["cs", "computer", "coding", "software", "eecs", "programming", "ai"],
    Engineering: ["engineering", "mech", "robot", "aerospace", "hardware", "circuits"],
    "Pre-Med": ["med", "health", "clinical", "bio", "nurs", "doctor", "hospital"],
    Law: ["law", "legal", "debate", "policy", "government", "trial"],
    Business: ["business", "entrepreneur", "startup", "econ", "finance", "haas"],
    "Social Impact": ["nonprofit", "volunteer", "community", "impact", "service"],
    Arts: ["art", "design", "music", "film", "theater", "creative"],
    Research: ["research", "lab", "science"],
    "Berkeley-Specific Programs": ["m.e.t", "met", "regents", "cosmos"],
  };
  return Object.keys(map).filter((k) => map[k].some((w) => hay.includes(w)));
};

const safeSchool = (s) => (SCHOOLS[s] ? s : "berkeley");

const profileToMentor = (p) => ({
  id: p.id, demo: false,
  name: p.name || "Mentor", school: safeSchool(p.school), year: p.year || new Date().getFullYear(),
  major: "", role: p.role_title || "Mentor", photo: null,
  color: "#A465E2", color2: "#C79BEF",
  cats: deriveCats(p.tags || [], p.bio), tags: p.tags || [],
  rating: null, studentsHelped: 0,
  bio: p.bio || `${SCHOOLS[safeSchool(p.school)].short} mentor on LinkTeen.`,
  moment: "",
  path: [
    ...(p.experiences || []).map((q) => (q.title.length > 26 ? q.title.slice(0, 24) + "\u2026" : q.title)),
    SCHOOLS[safeSchool(p.school)].name,
  ],
  exp: (p.experiences || []).map((q) => ({ t: q.title, story: q.story, learned: "", time: "", why: q.why, note: q.note, alts: [] })),
  replies: [],
  avail: p.availability || null,
});

const profileToStudentContact = (p) => ({
  id: p.id, demo: false, name: p.name || "Student",
  school: safeSchool(p.target), target: safeSchool(p.target),
  grade: p.grade || "\u2014", interest: (p.interests || [])[0] || "", last: "",
  color: "#F48947", color2: "#A465E2", replies: [],
});

/* ---------------- Demo data: mentors & journeys ---------------- */
const MENTORS = [
  {
    id: "m1",
    demo: true,
    name: "Priya Sharma",
    school: "berkeley",
    year: 2022,
    major: "EECS",
    role: "Software Engineer at Figma",
    color: "#F48947",
    color2: "#FBBF77",
    cats: ["Computer Science", "Research", "Berkeley-Specific Programs"],
    tags: ["EECS", "COSMOS", "Research", "PIQ essays", "Regents'"],
    rating: 4.9,
    studentsHelped: 34,
    path: ["Science Olympiad", "COSMOS Cluster 5", "Independent Research", "Cal Alumni Scholar", "UC Berkeley EECS"],
    bio: "I got into Berkeley EECS by going absurdly deep on one thing — circuits — instead of collecting ten shallow activities. Now I help students find their version of the garage circuit board.",
    moment: "The moment that got me in wasn't a trophy. It was my PIQ about a circuit board that failed 40 times before it worked. My admissions reader later told me at a Regents' event that it was the most 'Berkeley' essay in her stack that week — obsession, failure, iteration, and zero polish for polish's sake.",
    exp: [
      {
        t: "Joined Science Olympiad (9th grade)",
        story: "I joined because I was already obsessed with building circuits in my garage and wanted people to nerd out with. I was terrible at competitions for a full year — we placed 14th of 15 at my first regional.",
        learned: "Depth beats breadth. One technical obsession, pursued for four years, gave every later step a spine.",
        time: "4 hrs/week, Sept–Apr",
        why: "Berkeley readers look for sustained intellectual curiosity, not a checklist. Four years in one club, with visible growth, reads as authentic.",
        note: "UCLA and UCSD score 'demonstrated interest in your major' the same way — a long arc in one area beats scattered clubs at all three.",
        alts: ["FIRST Robotics team", "Local hackathon circuit (e.g., Hack the Bay)", "Technology Student Association chapter"],
      },
      {
        t: "Became team captain junior year",
        story: "Three teammates quit two weeks before state. I had to learn how to delegate, recruit two freshmen mid-season, and rewrite our event assignments overnight. We placed 3rd — our best ever.",
        learned: "Leadership isn't a title. It's what you do when the plan collapses.",
        time: "6–8 hrs/week in season",
        why: "This became my leadership PIQ. Berkeley explicitly asks how you've responded to challenge — a real crisis with a real outcome is gold.",
        note: "UCLA's PIQ readers weight the exact same leadership prompt; UCSD looks for it in activity descriptions.",
        alts: ["Section leader in band who rebuilt a section", "Restarting a dying club as president", "Organizing a school-wide event after a sponsor pulled out"],
      },
      {
        t: "COSMOS Cluster 5 at UC Davis (summer after 10th)",
        story: "I applied on a whim after my coach mentioned it. Four weeks of embedded systems with actual UC faculty changed everything — it's where I realized EECS was a career, not a hobby.",
        learned: "How to work in a university lab, read a datasheet, and email a professor without panicking.",
        time: "4 weeks residential, apply by early Feb",
        why: "COSMOS is a UC program — it signals you sought out UC-level rigor early. My rec letter from my cluster instructor went straight into my Berkeley file.",
        note: "COSMOS is equally beloved by UCLA and UCSD readers — it's a UC-wide credibility signal.",
        alts: ["Stanford Pre-Collegiate Summer Institutes", "RSI (Research Science Institute)", "Cold-email a local university lab for a summer internship"],
      },
      {
        t: "Independent research: the 40-failure circuit board",
        story: "Senior fall I designed a low-cost EMG sensor board. It failed 40 times — bad traces, fried chips, one small fire. Version 41 worked, and I wrote my PIQ about versions 1 through 40.",
        learned: "Documentation of failure is more persuasive than a highlight reel.",
        time: "10 hrs/week, Aug–Dec",
        why: "Berkeley EECS wants builders who iterate. An essay about failure with a working artifact at the end is the strongest possible evidence.",
        note: "The same project anchored hypothetical UCLA/UCSD apps — I reused the narrative across all UC PIQs since the application is shared.",
        alts: ["Publish a small open-source tool with real users", "Science fair project taken to state level", "Arduino-based assistive device for a family member"],
      },
      {
        t: "Berkeley EECS admit + Regents' & Chancellor's Scholarship",
        story: "Named a Cal Alumni Leadership Scholar and offered Regents'. The interview was 80% about the circuit board — they'd clearly read the PIQ closely.",
        learned: "Everything compounds. The club fed the captaincy, the captaincy fed COSMOS, COSMOS fed the research, the research fed the essay.",
        time: "UC app: Aug–Nov 30 of senior year",
        why: "Regents' at Berkeley goes to ~2% of admits — it's the signal that a coherent four-year story beats a long résumé.",
        note: "UCLA and UCSD run their own Regents' programs with the same criteria — one strong UC app can win all three.",
        alts: ["Cal Alumni Leadership Award", "UCLA Alumni Scholarship", "UCSD Chancellor's Associates Scholars"],
      },
    ],
    replies: [
      "Great question! Honestly, the biggest thing was that I never treated it as a résumé item — I was genuinely obsessed, and that leaks into how you write about it. What part are you thinking of trying?",
      "For Berkeley specifically, the readers spend ~8 minutes per file. A four-year arc in one area jumps out instantly. And yes — the exact same arc works for UCLA and UCSD since it's one shared UC app.",
      "If you want, I can look at your current activity list and tell you which one is your 'circuit board' — the thing worth going deep on. Most students already have it and don't realize.",
      "Timing tip: COSMOS apps open in January and close early Feb. Sophomore summer is the sweet spot — it leaves junior year free for the independent project it inspires.",
    ],
  },
  {
    id: "m2",
    demo: true,
    name: "Marcus Lee",
    school: "berkeley",
    year: 2021,
    major: "M.E.T. (Haas + Engineering)",
    role: "Product Manager at Stripe",
    color: "#A465E2",
    color2: "#C9A0F0",
    cats: ["Business", "Social Impact", "Berkeley-Specific Programs"],
    tags: ["M.E.T.", "Haas", "Nonprofits", "DECA", "Grants"],
    rating: 4.8,
    studentsHelped: 27,
    path: ["DECA Competitor", "Founded TutorBridge", "$12K Grant Win", "Berkeley M.E.T. Early", "PM at Stripe"],
    bio: "Berkeley M.E.T. takes ~50 students a year. I got in by proving impact with numbers — a tutoring nonprofit that served 140 students — not by having the fanciest title.",
    moment: "In my M.E.T. interview they asked one question for 20 minutes: 'Walk me through how TutorBridge went from 4 students to 140.' Berkeley didn't care that I founded something. They cared that I could explain exactly how it grew.",
    exp: [
      {
        t: "DECA: lost badly, then placed at ICDC",
        story: "Freshman year I bombed my first roleplay so badly the judge laughed (kindly). I rebuilt my prep system, made states sophomore year, and placed top-10 at internationals junior year.",
        learned: "Business is a practicable skill, not a personality trait.",
        time: "3 hrs/week + 4 competition weekends/yr",
        why: "M.E.T. wants evidence you've tested your interest in business under pressure. A losing-to-winning arc is a ready-made PIQ.",
        note: "UCLA and UCSD both read DECA as rigor + initiative for business/econ majors.",
        alts: ["FBLA competitive events", "Diamond Challenge entrepreneurship competition", "Running a real small business (reselling, tutoring, lawn care) with tracked books"],
      },
      {
        t: "Founded TutorBridge — free tutoring nonprofit",
        story: "Started with me and 3 friends tutoring 4 middle schoolers at the library. Built a matching spreadsheet, then a website, then recruited 22 tutors. By senior year: 140 students served, 1,900 tutoring hours logged.",
        learned: "Track everything. '140 students, 1,900 hours' did more work in my app than any adjective.",
        time: "5–7 hrs/week for 3 years",
        why: "Berkeley's public mission is real — service at scale, with receipts, aligns with it directly. This was the core of my application.",
        note: "This is the single most transferable experience: UCLA and UCSD both weight sustained community impact heavily in comprehensive review.",
        alts: ["Scale an existing volunteer program instead of founding one", "Coding classes for seniors at a community center", "Food-recovery operation between restaurants and shelters"],
      },
      {
        t: "Won a $12K community grant",
        story: "Wrote my first-ever grant proposal to a local foundation to fund Chromebooks for tutees. Got rejected once, revised with actual usage data, won $12K on the second try.",
        learned: "Adults will fund teenagers who show up with data and a budget.",
        time: "~30 hrs total across 2 attempts",
        why: "Fundraising is leadership Berkeley can verify. It also became my 'greatest talent' PIQ — persuading with evidence.",
        note: "Grant wins read identically at UCLA/UCSD — concrete, verifiable, rare for high schoolers.",
        alts: ["School-district mini-grants", "Crowdfunding campaign with a public post-mortem", "Corporate sponsorship for a school program"],
      },
      {
        t: "Berkeley M.E.T. application + interview",
        story: "M.E.T. needs a separate essay and interview on top of the UC app. I told one story — TutorBridge — through a business lens (unit economics of free tutoring!) and an engineering lens (the matching algorithm).",
        learned: "Elite programs admit narratives, not lists.",
        time: "Essays: Oct–Nov; interviews: Feb",
        why: "M.E.T. is Berkeley-specific — dual degree, ~50 seats. Applying signals ambition even if you land in Haas or L&S instead.",
        note: "The same story maps to UCLA's Sharpe Fellows ambitions and UCSD's Rady school interests — one narrative, three doors.",
        alts: ["Berkeley Haas (Global Management Program)", "UCLA Economics + entrepreneurship minor path", "UCSD Rady undergraduate business pathways"],
      },
    ],
    replies: [
      "The #1 mistake I see: students found a club, hold the title, and have zero numbers. Berkeley wants receipts. What are you building right now?",
      "M.E.T. opens with the regular UC app (Nov 30 deadline) plus a supplement — start the supplement in October, not November. Ask me for my essay structure anytime.",
      "Honestly, the grant was easier than it sounds. Local foundations rarely get applications from students, so you stand out immediately. Want the template I used?",
      "And yes — everything I did for Berkeley was equally load-bearing for UCLA and UCSD. One UC application, one story, three great outcomes possible.",
    ],
  },
  {
    id: "m3",
    demo: true,
    name: "Danielle Ortiz",
    school: "ucla",
    year: 2023,
    major: "Human Biology & Society",
    role: "Med student at UCSF",
    color: "#2774AE",
    color2: "#7FB4DC",
    cats: ["Pre-Med", "Social Impact", "Research"],
    tags: ["Pre-Med", "Clinical hours", "EMT", "Public health"],
    rating: 4.9,
    studentsHelped: 41,
    path: ["UCSF Benioff Volunteer", "EMT Certification", "Community Health Research", "UCLA Human Biology", "UCSF Med"],
    bio: "I built my application on the Berkeley framework — depth, service, evidence — and it won me admits to Berkeley, UCLA, and UCSD. I chose UCLA for the hospital access, so I can tell you exactly how the same roadmap plays at all three.",
    moment: "The experience that unlocked everything was 200 volunteer hours at UCSF Benioff Children's. Not because of the hours — because week 30 is when a nurse finally let me help with a real intake, and that story became the essay all three UCs said yes to.",
    exp: [
      {
        t: "Volunteered 200 hrs at UCSF Benioff Children's Hospital",
        story: "Started stocking supply closets, which felt pointless for months. Around hour 120, staff started trusting me with family-facing work. The essay wasn't about medicine — it was about earning trust slowly.",
        learned: "Clinical exposure is about proximity to patients over time, not shadowing a surgeon once.",
        time: "4 hrs/week for ~15 months",
        why: "Sustained clinical service is the pre-med signal every UC screens for. Berkeley's readers flagged it in my Regents' interview; UCLA admitted me for it.",
        note: "Identical weight at Berkeley, UCLA, and UCSD — pick the hospital nearest you and stay for a year+.",
        alts: ["Kaiser volunteer programs", "Hospice volunteer training (heavier, incredible essays)", "Free clinic front-desk + translation work"],
      },
      {
        t: "EMT certification the summer after junior year",
        story: "Took an accelerated EMT-B course at a community college at 17. Ran my first real call two weeks after certifying. Suddenly 'I want to be a doctor' had evidence behind it.",
        learned: "Certifications turn interest into capability — and community college courses are open to high schoolers.",
        time: "6-week intensive + weekend shifts",
        why: "UC comprehensive review explicitly credits community college coursework. An EMT cert at 17 is rare and unforgettable in a file.",
        note: "If anything this played strongest with Berkeley and UCSD readers — both flagged the community-college rigor.",
        alts: ["CNA certification", "Medical Spanish certificate + clinic volunteering", "Wilderness First Responder"],
      },
      {
        t: "Community health research with a county epidemiologist",
        story: "I cold-emailed 11 people at the county health department. One answered. I spent a semester cleaning asthma-visit data and co-presented at a community board meeting.",
        learned: "Research doesn't require a fancy lab. Public data + a mentor + a question is enough.",
        time: "5 hrs/week, one semester",
        why: "This bridged service and scholarship — the exact combination Berkeley's public-mission rubric rewards, and what got me into UCLA's honors program.",
        note: "UCSD is arguably the best fit for this profile — their Triton Research & Experiential Learning ecosystem is built for it.",
        alts: ["School-based health survey with a teacher sponsor", "Local university public-health lab assistant", "Analyze open CDC/county datasets and publish a report"],
      },
      {
        t: "The UC application: one story, three admits",
        story: "I wrote four PIQs that all orbited one theme — earning trust in healthcare settings. Admitted to Berkeley (public health), UCLA (HumBio), and UCSD (human biology). Chose UCLA.",
        learned: "Because the UC app is shared, a Berkeley-caliber application is automatically a UCLA/UCSD-caliber application.",
        time: "Essays: Sept–Nov of senior year",
        why: "Berkeley taught me the bar; the bar is portable. Aim for the hardest target and the others come with it.",
        note: "This is the whole LinkTeen thesis in one experience.",
        alts: ["Apply to all three — the marginal cost is one checkbox", "Add UC Davis/Irvine as pre-med-friendly backups", "Regents' consideration is automatic at each campus"],
      },
    ],
    replies: [
      "Pre-med truth: UCs don't want 'well-rounded.' They want a spike with a heartbeat. Clinical hours + one research experience + one leadership story is the whole formula.",
      "Start volunteering NOW even if it's boring — the good stories only show up after month 6. Which hospitals are near you?",
      "I aimed at Berkeley the entire time and ended up choosing UCLA. The roadmap didn't change by a single milestone. That should be freeing, not confusing!",
      "The EMT course was the highest-leverage 6 weeks of my life. Happy to send you the list of CA community colleges that take 17-year-olds.",
    ],
  },
  {
    id: "m4",
    demo: true,
    name: "Kevin Nguyen",
    school: "ucsd",
    year: 2022,
    major: "Cognitive Science: Design & Interaction",
    role: "UX Researcher at Google",
    color: "#182B49",
    color2: "#5E7BA6",
    cats: ["Computer Science", "Arts", "Research"],
    tags: ["Design", "CogSci", "Portfolio", "HCI", "Research"],
    rating: 4.7,
    studentsHelped: 19,
    path: ["Robotics Club Designer", "Redesigned School App", "Design Portfolio", "HCI Lab Volunteer", "UCSD CogSci"],
    bio: "I was the kid who cared more about how the robot's controls felt than how it drove. I turned that into a design portfolio built to Berkeley's standard — and UCSD's CogSci program turned out to be the perfect home for it.",
    moment: "My hinge moment was redesigning our school's broken lunch-ordering app as an unpaid, unasked-for project. 1,100 students used it. Every UC essay I wrote traced back to watching a freshman order lunch in 9 seconds instead of 90.",
    exp: [
      {
        t: "Robotics club — but as the design person",
        story: "I couldn't out-code anyone, so I owned the driver station UI and our engineering notebook. Judges started citing our notebook in awards. I'd found a lane nobody wanted.",
        learned: "You don't have to be the best coder in the room. Find the seat nobody's sitting in.",
        time: "5 hrs/week, build season 12+",
        why: "UCs read 'unique role within a team' as maturity. My Berkeley-standard portfolio started as robotics notebook pages.",
        note: "Berkeley (CS + Art practice), UCLA (Design Media Arts), and UCSD (CogSci) all have homes for this exact hybrid.",
        alts: ["Yearbook/newspaper design lead", "Theater tech + projection design", "Game jam teams as the UI/UX person"],
      },
      {
        t: "Redesigned the school lunch app (uninvited)",
        story: "Our district's app took 90 seconds to order lunch. I interviewed 40 students, prototyped in Figma, and pitched the district IT office. They shipped 70% of my redesign.",
        learned: "Real users beat imaginary startups. The best project is a problem within walking distance.",
        time: "~120 hrs over one semester",
        why: "A shipped project with 1,100 users is the design equivalent of Priya's circuit board — concrete, verifiable, obsessive.",
        note: "This story anchored my UCSD app and would have been just as load-bearing at Berkeley or UCLA — user numbers travel.",
        alts: ["Redesign a local nonprofit's website for free", "Accessibility audit of your school's sites", "Design system for a club or small business"],
      },
      {
        t: "Built a portfolio to Berkeley's bar",
        story: "I studied what Berkeley's art practice and HCI admits showed, and held my portfolio to that standard: 4 case studies, process over polish, failure documented. It doubled as my UC 'additional comments' link.",
        learned: "Curate ruthlessly. Four deep case studies beat fourteen dribbble shots.",
        time: "8 hrs/week, junior spring",
        why: "Aiming at the hardest target (Berkeley) meant every other program saw an over-qualified portfolio.",
        note: "UCLA DMA requires a portfolio; UCSD doesn't but rewards one. Berkeley-bar work wins at all three.",
        alts: ["National Scholastic Art & Writing submissions", "Behance/personal site with process logs", "Congressional App Challenge entry"],
      },
      {
        t: "Volunteered in a university HCI lab",
        story: "Emailed 8 professors within 25 miles. One let me run participant sessions on weekends. I was the least qualified person in the room for 6 months, which is exactly where you want to be.",
        learned: "How research actually works: slowly, then all at once.",
        time: "4 hrs/week, senior year",
        why: "A faculty rec letter that says 'performs like an undergrad' is one of the rarest assets a high schooler can hold — at Berkeley or anywhere.",
        note: "UCSD's HDSI and CogSci labs are unusually open to this; Berkeley and UCLA labs say yes more than students think.",
        alts: ["Psychology lab participant-runner roles", "Remote research assistant for a PhD student", "Citizen-science projects with named contribution"],
      },
    ],
    replies: [
      "Design-track advice: your portfolio IS your application. Everything else is supporting evidence. Want me to look at a case study?",
      "The uninvited redesign is the highest-ROI project in existence — every school has broken software and zero students fixing it.",
      "I held everything to the Berkeley bar and it made my UCSD app untouchable. Aim high, land great — that's the whole trick.",
      "Cold-email template that got me the lab spot: 2 sentences about their paper, 1 sentence about my project, 1 ask. Professors answer specificity.",
    ],
  },
  {
    id: "m5",
    demo: true,
    name: "Rachel Kim",
    school: "berkeley",
    year: 2023,
    major: "Mechanical Engineering",
    role: "Propulsion Engineer at SpaceX",
    color: "#E2574C",
    color2: "#F2A099",
    cats: ["Engineering", "Research", "Berkeley-Specific Programs"],
    tags: ["MechE", "FIRST Robotics", "Machining", "CAD", "Build portfolio"],
    rating: 4.9,
    studentsHelped: 22,
    path: ["FIRST Robotics Build Lead", "Machine Shop Apprentice", "Adaptive Trike Project", "Berkeley MechE", "SpaceX Propulsion"],
    bio: "I got into Berkeley MechE with grease under my fingernails — a robotics build-lead role, a fab-shop apprenticeship, and one adaptive tricycle that mattered more than any award.",
    moment: "The thing that got me in was the adaptive trike I built for my little brother, who has cerebral palsy. Three prototypes, one bent frame, one very patient brother. My PIQ walked through why prototype two failed — Berkeley's engineering readers want to see how you think when metal doesn't cooperate.",
    exp: [
      {
        t: "FIRST Robotics — mechanical build lead",
        story: "Joined in 9th because the shop smelled like cut aluminum and I loved it. I was the only girl on the build side for two years. By 11th I ran the drivetrain team and redesigned our gearbox mid-season after we stripped gears at our first regional.",
        learned: "Real engineering has a deadline. The six-week build season taught me more about trade-offs than any class.",
        time: "15+ hrs/week during build season, 4 hrs/week off-season",
        why: "Berkeley MechE wants evidence you build, not just that you like physics. A named sub-team lead role with a specific redesign story is exactly that evidence.",
        note: "UCLA Samueli and UCSD Jacobs read hands-on build leadership identically — this experience is fully portable.",
        alts: ["VEX Robotics with a documented CAD portfolio", "Restore an engine or e-bike and log the process", "Technical theater — set rigging and stage machinery"],
      },
      {
        t: "Machine shop apprenticeship at a local fab shop",
        story: "The summer after 10th, I walked into a fabrication shop near my house and offered to sweep floors. By August I was running the manual mill and learning TIG welding. I got paid in scrap aluminum and knowledge.",
        learned: "Manufacturing intuition — knowing why a part is hard to make changes how you design it.",
        time: "Full-time, 7 weeks over summer",
        why: "Nobody else in the applicant pool had a rec letter from a machinist. Berkeley readers see thousands of coders; they see very few 17-year-olds who can hold a tolerance.",
        note: "Equally rare and equally valued at UCLA and UCSD — craft experience stands out at every UC engineering school.",
        alts: ["Makerspace membership + safety certifications", "Welding certificate at a community college", "Bike shop mechanic job with a build log"],
      },
      {
        t: "Built an adaptive tricycle for my brother",
        story: "Commercial adaptive trikes cost $4,000, so I designed one for my brother for $340 in parts. Prototype one was too heavy. Prototype two bent at the head tube. Prototype three is still in our garage, and he still rides it.",
        learned: "Engineering with a human on the other end changes everything — requirements stop being abstract.",
        time: "10 hrs/week for 8 months, junior year",
        why: "Iteration, documentation, and a person who benefited: it's Berkeley's engineering rubric compressed into one project. This was my main PIQ and my portfolio centerpiece.",
        note: "This exact project anchored the shared UC app — the same essay works word-for-word for UCLA and UCSD.",
        alts: ["e-NABLE 3D-printed prosthetics chapter", "Assistive device for a grandparent (reachers, ramps, mounts)", "Repair café volunteer — fix things for your community, log everything"],
      },
      {
        t: "Applied with a build portfolio, not a trophy list",
        story: "My activities list was short: robotics, the shop, the trike. In the UC app's additional comments I linked a one-page photo doc of everything I'd machined and welded. My admit letter came with a note from the Engineering dean's office.",
        learned: "Depth photographs well. Ten builds beat ten clubs.",
        time: "UC app: Aug–Nov 30 of senior year",
        why: "Berkeley MechE admits ~9% — a verifiable body of physical work is the strongest differentiator a mechanical applicant has.",
        note: "UCSD Jacobs explicitly invites supplementary portfolios for some programs; UCLA weighs the same evidence through the PIQs.",
        alts: ["FSAE-style summer programs", "Congressional App Challenge (hardware entries allowed)", "Science fair engineering division at state level"],
      },
    ],
    replies: [
      "First question I ask every future MechE: what have you physically built this month? Start there — even a wobbly shelf counts if you can explain the wobble.",
      "The fab shop thing sounds intimidating but isn't — small shops love free help. Walk in on a weekday afternoon, not a Monday morning. Want my exact pitch?",
      "For Berkeley MechE, one documented build with three failed iterations beats five clubs. Photograph everything, even the failures. Especially the failures.",
      "And yes — every bit of this transfers to UCLA Samueli and UCSD Jacobs. Same UC app, same love of people who actually make things.",
    ],
  },
  {
    id: "m6",
    demo: true,
    name: "Diego Fuentes",
    school: "ucsd",
    year: 2022,
    major: "Mechanical & Aerospace Engineering",
    role: "Test Engineer at Blue Origin",
    color: "#1F7A6D",
    color2: "#6FBFAF",
    cats: ["Engineering", "Research"],
    tags: ["Aerospace", "Rocketry", "Dual enrollment", "TARC", "Fundraising"],
    rating: 4.8,
    studentsHelped: 17,
    path: ["Founded Rocketry Club", "CC Calc & Physics", "TARC Nationals", "UCSD MAE", "Blue Origin"],
    bio: "I founded a rocketry club with $0 and five friends, built my application to the Berkeley bar, and chose UCSD for its rocket labs. Ask me about aerospace paths and dual enrollment.",
    moment: "Our qualification flight for TARC nationals shredded its parachute at 400 feet in front of the whole club. We rebuilt the recovery system in nine days and qualified on the last legal launch window. That nine-day sprint became the essay every UC responded to.",
    exp: [
      {
        t: "Founded a rocketry club from nothing",
        story: "Sophomore year, my school had no engineering clubs at all. Five of us started one with a $0 budget — bake sales first, then I cold-emailed local aerospace suppliers and landed $1,800 in sponsorships by writing an actual one-page sponsor deck.",
        learned: "Initiative is a muscle. Nobody gives a 15-year-old a budget; you go build one.",
        time: "5 hrs/week, plus launch weekends",
        why: "Founding something where nothing existed — with a funding trail to prove it — is exactly the 'created opportunity' signal Berkeley's comprehensive review names explicitly.",
        note: "UCSD and UCLA read founder-with-receipts stories the same way. The sponsor deck came up in my UCSD Regents' consideration.",
        alts: ["Revive a dead STEM club instead of founding one", "Civil Air Patrol cadet program", "Drone racing / FPV build team"],
      },
      {
        t: "Dual enrollment: calculus and physics at community college",
        story: "My school's math track topped out before calculus. So junior year I took Calc I/II and calc-based physics at the community college at night. It was harder than anything at my high school, and my UC GPA thanked me.",
        learned: "The UC system gives real weight to community college rigor — and the door is open to high schoolers.",
        time: "Two evenings/week, both semesters",
        why: "UC comprehensive review explicitly credits students who exceed what their school offers. For engineering, calc-based physics before senior year is a loud signal.",
        note: "This is arguably the single most portable move across Berkeley, UCLA, and UCSD — all three recalculate your GPA with those courses honors-weighted.",
        alts: ["UC Scout online A-G courses", "AP Physics C self-study with exam", "Summer math intensives at a CSU"],
      },
      {
        t: "TARC — The American Rocketry Challenge, national finals",
        story: "Two years of failed qualification attempts, then the shredded-parachute year. We placed 23rd of 100 at nationals in Virginia. Nobody remembers our placement; every UC reader remembered the nine-day rebuild.",
        learned: "Competitions are essay generators. The result matters less than the recovery story.",
        time: "8 hrs/week, Jan–May",
        why: "A national-level engineering competition with a documented failure-recovery arc hits both 'academic rigor' and 'response to challenge' in one activity.",
        note: "Applies identically at every UC — and UCSD's Triton Rocket Club recruiters knew TARC by name at orientation.",
        alts: ["Science Olympiad build events", "CanSat / cubesat student challenges", "Solar car or electrathon teams"],
      },
      {
        t: "One UC app, aimed at Berkeley, home at UCSD",
        story: "I wrote every PIQ to the Berkeley standard. Result: Berkeley waitlist, UCLA admit, UCSD admit with Regents' consideration. I chose UCSD for the MAE department and the student rocket labs — and it was the right call.",
        learned: "Aim at the hardest target and you can't lose. The waitlist stung for a week; the rocket lab lasted four years.",
        time: "Essays: Sept–Nov of senior year",
        why: "The Berkeley bar is the useful fiction — holding yourself to it produces an application every UC wants.",
        note: "This is the LinkTeen thesis from the other side: the framework got me three great outcomes, and I picked the best fit, not just the biggest name.",
        alts: ["Apply to all three — one app, three readers", "Add UC Davis (excellent aero-adjacent programs)", "UCSD SEDS and Triton Rocket Club start recruiting freshmen fall quarter"],
      },
    ],
    replies: [
      "Aerospace path truth: you don't need a fancy program, you need launches. TARC registration opens in September — is your school signed up?",
      "The sponsor deck was one page: who we are, what we're building, what $500 buys, photo of the team. Local suppliers said yes 3 times out of 11. Want the template?",
      "Dual enrollment is the most underrated move in the entire UC playbook. Which community colleges are near you? I'll tell you what to look for.",
      "I aimed at Berkeley and landed at UCSD with zero regrets — the MAE labs here put freshmen on real hardware. Happy to talk through how to rank the three for engineering.",
    ],
  },
  {
    id: "m7",
    demo: true,
    name: "Amara Okafor",
    school: "berkeley",
    year: 2021,
    major: "Political Science, Legal Studies minor",
    role: "JD Candidate at Harvard Law",
    color: "#C2711D",
    color2: "#E8B36A",
    cats: ["Law", "Social Impact"],
    tags: ["Pre-law", "Mock Trial", "Public policy", "PIQ essays", "Internships"],
    rating: 4.9,
    studentsHelped: 31,
    path: ["Mock Trial Captain", "City Youth Commission", "Public Defender Internship", "Berkeley PoliSci", "Harvard Law"],
    bio: "Pre-law at the UCs isn't a major — it's a track record. Mine was mock trial, a youth commission seat that changed a real policy, and a summer filing motions at the public defender's office.",
    moment: "The experience that got me into Berkeley was one Tuesday at the public defender's office, watching arraignment day: forty cases before lunch, ninety seconds each. My PIQ was about the gap between the law in my textbook and the law in that room. My Berkeley reader quoted it back to me at an admitted students event.",
    exp: [
      {
        t: "Mock Trial — lost the county final twice, then won it",
        story: "I joined as a shy freshman witness and lost the county final two years running as an attorney. Senior year, as captain, I rebuilt our objection drills from scratch and we finally took county. The losing years were the useful ones.",
        learned: "Advocacy is reps. Nobody is born able to think on their feet — you drill it.",
        time: "6 hrs/week, Oct–Mar",
        why: "A four-year arc with visible skill growth is Berkeley's favorite shape. The two losses made the win — and the essay — credible.",
        note: "UCLA and UCSD read sustained competitive advocacy the same way, and UCLA's mock trial program actively recruits from high school circuits.",
        alts: ["Speech & Debate (Lincoln-Douglas or Public Forum)", "Model UN with leadership progression", "Ethics Bowl team"],
      },
      {
        t: "Appointed to the City Youth Commission",
        story: "I applied to my city's youth commission on a whim junior year. Most meetings were boring. But I wrote a two-page memo on how our park curfew was being enforced unevenly across neighborhoods — and the council amended the enforcement policy that spring.",
        learned: "Government moves on paper. A well-argued memo from a 16-year-old can outweigh an hour of public comment.",
        time: "Monthly meetings + ~3 hrs/week on the memo, one semester",
        why: "Berkeley's public mission is not a slogan — a verifiable policy change with your name in the minutes is the strongest civic evidence a pre-law applicant can carry.",
        note: "For UCLA and UCSD, the same memo story slots directly into the 'made your community better' PIQ. Identical value.",
        alts: ["Student representative to the school board", "County youth advisory council", "City council member's district office volunteer"],
      },
      {
        t: "Summer internship at the public defender's office",
        story: "I cold-emailed nine county offices; one said yes. I spent the summer filing motions, organizing discovery boxes, and sitting in on arraignments. Unglamorous, unpaid, and the most formative eight weeks of my life.",
        learned: "Proximity beats prestige. Watching real lawyers work taught me what no summer 'law camp' could.",
        time: "20 hrs/week, 8 weeks",
        why: "Most pre-law applicants have opinions about the law; almost none have sat in a courtroom weekly. Berkeley readers can tell the difference instantly.",
        note: "The cold-email approach works in every county — LA and San Diego offices take high school volunteers too, which UCLA and UCSD readers recognize locally.",
        alts: ["Legal aid clinic front-desk volunteer", "Court Watch observer programs", "Local law firm records/admin internship"],
      },
      {
        t: "Berkeley PoliSci + Legal Studies — chosen for the department",
        story: "I picked Berkeley specifically for the Legal Studies program — one of the only places you can take real law-school-style courses as an undergrad. Wrote my 'why' around that, then made it true for four years.",
        learned: "Know why your target school specifically. Specificity in your head becomes specificity on the page.",
        time: "UC app: Sept–Nov 30",
        why: "Berkeley Legal Studies is a genuine differentiator for pre-law — knowing that, and building toward it, made my whole file coherent.",
        note: "UCLA's PoliSci department plus its DC program (CAPPP) is the equivalent lever; UCSD's poli sci is a research powerhouse. Same framework, different named door.",
        alts: ["UCLA Political Science + CAPPP Quarter in Washington", "UCSD Political Science / Public Policy", "Berkeley Rhetoric as an alternate pre-law major"],
      },
    ],
    replies: [
      "Pre-law reality check: there's no pre-law major and law schools don't care what you study. UCs want evidence you've seen real law up close. What's within 20 miles of you?",
      "The cold email that worked: 3 sentences. Who I am, that I can commit 20 hrs/week for 8 weeks, and one specific reason I chose *their* office. Nine sent, one yes — that's all you need.",
      "Mock trial losses are worth more than wins essay-wise. What happened in your last competition? There's probably a PIQ in it.",
      "Everything on my path reads identically at UCLA and UCSD — civic impact and courtroom proximity are UC-wide currency. Berkeley was just my north star.",
    ],
  },
  {
    id: "m8",
    demo: true,
    name: "Sofia Reyes",
    school: "ucla",
    year: 2022,
    major: "Political Science",
    role: "Legislative Aide, California State Assembly",
    color: "#4A62C9",
    color2: "#93A5EA",
    cats: ["Law", "Social Impact"],
    tags: ["Pre-law", "Debate", "Voter registration", "Government", "UCDC"],
    rating: 4.8,
    studentsHelped: 24,
    path: ["Speech & Debate", "Voter Drive: 312 Registered", "Assembly Internship", "UCLA PoliSci", "Sacramento"],
    bio: "I built my pre-law path on the Berkeley framework — evidence over titles — and chose UCLA for its Washington DC program. Debate gave me the voice; a voter drive with real numbers gave me the story.",
    moment: "The line that carried my application was a number: 312. That's how many seniors my team registered to vote across four high schools. Every UC reader can skim past 'passionate about civic engagement' — none of them skimmed past 312.",
    exp: [
      {
        t: "Speech & Debate — from panic attacks to state quals",
        story: "I signed up for Lincoln-Douglas debate freshman year and nearly quit after crying in a bathroom at my second tournament. I stayed. By junior year I qualified for states, and by senior year I was coaching the freshmen who reminded me of me.",
        learned: "The skill I use daily in the Assembly — arguing a position under pressure — was built in those rounds.",
        time: "6 hrs/week + one tournament weekend/month",
        why: "The growth arc (panic to state quals to coaching) is precisely the 'greatest skill' PIQ shape Berkeley trained me to write — and UCLA admitted me on it.",
        note: "Berkeley, UCLA, and UCSD all weight debate as academic rigor plus communication evidence. Fully interchangeable across the three.",
        alts: ["Mock Trial attorney track", "Junior State of America (JSA) chapters", "Toastmasters youth program if your school has no team"],
      },
      {
        t: "Ran a voter registration drive — 312 registered",
        story: "Junior spring, I partnered with the League of Women Voters and organized pre-registration tables at four high schools. I recruited 14 volunteers, handled the training, and kept a spreadsheet of every completed form. Final count: 312.",
        learned: "Organizing is logistics. The idealism takes an afternoon; the spreadsheet takes three months.",
        time: "4 hrs/week for a semester",
        why: "Concrete civic impact with a verifiable number — Berkeley's public-mission rubric and UCLA's service lens both light up for exactly this.",
        note: "This was my main PIQ across the shared UC app. One number, three schools, zero edits needed.",
        alts: ["Census/redistricting education campaign", "Naturalization ceremony volunteer + citizenship class tutor", "Ballot measure explainer zine or site for first-time voters"],
      },
      {
        t: "District office internship with my Assemblymember",
        story: "Senior year I interned at my Assemblymember's district office doing constituent casework — mostly helping people navigate unemployment claims. I learned what government looks like from the complaint-intake side.",
        learned: "Policy is personal. Every abstract bill is somebody's Tuesday problem.",
        time: "6 hrs/week, senior fall",
        why: "Casework experience is rare for high schoolers and instantly credible — it says you've done the unglamorous side of public service, which is most of it.",
        note: "District offices exist in every UC's backyard; readers at all three campuses know exactly what this work is.",
        alts: ["City hall department internship", "Congressional district office volunteer", "Campaign field organizing (canvassing with a role, not just a shift)"],
      },
      {
        t: "Chose UCLA for the road to Washington",
        story: "Admitted to UCLA and UCSD, waitlisted at Berkeley. I chose UCLA specifically for CAPPP — the Quarter in Washington program — and spent a quarter working in a Senate office because of it. That quarter got me my Assembly job.",
        learned: "Pick the school with the program that leads to the job, not the one with the loudest name.",
        time: "UC app: Sept–Nov 30",
        why: "Building to the Berkeley bar made me competitive everywhere; knowing UCLA's specific pre-law levers made the choice easy when decisions came.",
        note: "Berkeley's UCDC program and UCSD's DC internship pipeline are the sibling programs — every UC has a road to Washington if you know its name.",
        alts: ["UCLA CAPPP / Quarter in Washington", "UC Berkeley UCDC program", "UCSD Public Policy + DC internship pipeline"],
      },
    ],
    replies: [
      "Pre-law students always ask what to major in. Wrong question! Ask: what can I organize this semester that produces a number? Numbers are what readers remember.",
      "The League of Women Voters partnership took one email — civic orgs are desperate for student organizers. Want the contact structure I used?",
      "Debate anxiety is nearly universal, including for people who end up doing it professionally. The bathroom-crying year is part of my story now. Keep going.",
      "I held myself to the Berkeley bar and chose UCLA for CAPPP — the framework travels, the specific programs differ. Ask me how to map yours.",
    ],
  },
  {
    id: "m9",
    demo: true,
    name: "Grace Liu",
    school: "ucsd",
    year: 2023,
    major: "Neurobiology",
    role: "MD/PhD Student at UC San Diego",
    color: "#4C9A5F",
    color2: "#9AD0A8",
    cats: ["Pre-Med", "Research", "Social Impact"],
    tags: ["Pre-med", "Neuroscience", "Scribing", "Research", "Caregiving"],
    rating: 4.9,
    studentsHelped: 26,
    path: ["ER Scribe at 17", "Alzheimer's Lab Volunteer", "Founded Memory Café", "UCSD Neurobiology", "MD/PhD"],
    bio: "My grandmother's Alzheimer's diagnosis turned into a scribe job, a research lab seat, and a monthly memory café with 30 regulars. I built it all to the Berkeley standard and chose UCSD for its med-research pipeline.",
    moment: "Everything traces to my grandmother forgetting my name in October of my sophomore year. Instead of writing the sad version of that essay, I wrote about what I built because of it — the memory café where she laughed every month. Readers at Berkeley and UCSD both flagged that essay. Grief is common; response is rare.",
    exp: [
      {
        t: "Certified medical scribe in the ER at 17",
        story: "I took a scribe certification course the summer after junior year and worked paid weekend shifts in an emergency department. I charted hundreds of real patient encounters standing three feet from the physician.",
        learned: "Medicine is documentation, teamwork, and 4 a.m. decisions — and I still wanted it, which is the whole point of finding out early.",
        time: "12 hrs/week (weekend shifts), senior year",
        why: "Paid clinical work at 17 outranks shadowing by miles. The ER physicians who trained me wrote letters no teenager's file usually contains.",
        note: "Clinical depth is the universal pre-med currency at Berkeley, UCLA, and UCSD alike — scribing is simply the deepest version available to a high schooler.",
        alts: ["EMT certification (like Danielle's path)", "CNA certificate + skilled nursing facility work", "Hospital volunteer role held 12+ months"],
      },
      {
        t: "Volunteer in an Alzheimer's research lab",
        story: "I emailed the PI of a university Alzheimer's lab with one paragraph about my grandmother and one about my stats coursework. I started with data entry; fourteen months later my name was on a poster at a regional conference.",
        learned: "Labs run on reliability. Show up every week for a year and responsibilities find you.",
        time: "5 hrs/week for 14 months",
        why: "Research + personal stake + a named artifact (the poster) — Berkeley's rubric calls this 'sustained intellectual engagement' and it carried my whole file.",
        note: "UCSD's research ecosystem is the largest of the three for neuroscience — this experience is why I ranked it first, with Berkeley's framework as the yardstick.",
        alts: ["Psychology lab participant-runner role", "Public dataset analysis project (NIH/CDC open data)", "Summer research academies at a CSU or community college"],
      },
      {
        t: "Founded a monthly Memory Café",
        story: "A memory café is a social hour for dementia patients and their caregivers. I started one at our library: music, board games, coffee, no agenda. We grew from 6 attendees to 30 regulars, and caregivers told me it was the only hour they didn't feel alone.",
        learned: "Care is a service you can design. The medicine I want to practice looks like that room.",
        time: "One Saturday/month + ~3 hrs planning",
        why: "It fused the clinical, the research, and the personal into one verifiable act of service — the coherence Berkeley trains you to build is what UCSD admitted.",
        note: "Community health impact reads at full strength across all three UCs; this was the PIQ I didn't change a word of.",
        alts: ["Caregiver respite volunteer program", "Music/art hour at a memory care facility", "Bilingual health navigation help at a free clinic"],
      },
      {
        t: "Chose UCSD for the bench-to-bedside pipeline",
        story: "Admitted to Berkeley MCB and UCSD Neurobiology. I chose UCSD because the medical school, the hospital, and the labs share a campus — my scribe-lab-café triangle could continue without a car. Now I'm in its MD/PhD program.",
        learned: "The 'best' school is the one where your specific work continues. Mine continued here.",
        time: "UC app: Sept–Nov 30",
        why: "Berkeley set the bar my application cleared; UCSD offered the geography my path needed. Both things can be true.",
        note: "For pre-meds especially: Berkeley, UCLA, and UCSD each admit the same profile — clinical depth, research reliability, service with receipts. Build once, apply everywhere.",
        alts: ["Berkeley MCB + UCSF-adjacent volunteering", "UCLA Human Biology + hospital proximity (Danielle's path)", "UCSD Neurobiology + campus hospital pipeline"],
      },
    ],
    replies: [
      "Pre-med at 16 feels like a maze but it's really three lanes: clinical hours, one research seat, one service you built. Which lane is emptiest for you right now?",
      "Scribe certification took me 6 weeks and it's paid clinical experience — the single best-kept secret for pre-med high schoolers. Want the list of programs that take 17-year-olds?",
      "The lab email that worked was two paragraphs and one of them was personal. PIs are humans; they answer humans. I'll help you draft yours.",
      "I aimed at Berkeley and chose UCSD — for pre-med, the three UCs want the same file. Build the file, then pick your geography.",
    ],
  },
  {
    id: "m10",
    demo: true,
    name: "Noah Williams",
    school: "berkeley",
    year: 2022,
    major: "Environmental Economics & Policy",
    role: "Climate Analyst at Rewiring America",
    color: "#0E7C86",
    color2: "#63BFC7",
    cats: ["Social Impact", "Business", "Research"],
    tags: ["Climate", "Grants", "Organizing", "Policy", "Nonprofits"],
    rating: 4.7,
    studentsHelped: 15,
    path: ["Enviro Club: 8→45 Members", "School Garden + $2K Grant", "Youth Climate Summit", "Berkeley EEP", "Climate Policy"],
    bio: "I turned an eight-person environmental club into a 45-member operation with a garden, a grant, and a 300-person summit. Berkeley's Environmental Economics & Policy program was built for exactly that résumé.",
    moment: "The moment I point to is standing in a hardware store with a $2,000 grant check, buying lumber for a school garden I'd written into existence. Berkeley didn't admit 'president of environmental club.' It admitted 8-to-45 members, one garden, one grant, one summit — a story with receipts at every step.",
    exp: [
      {
        t: "President of Environmental Science Club: grew it from 8 to 45",
        story: "I inherited a club that was eight people eating lunch together. I gave it projects instead of meetings: a campus waste audit, a native plant survey, monthly creek cleanups with photographic before/afters. People join work, not clubs — we hit 45 members in 18 months.",
        learned: "Growth is a design problem. Give people something real to do and recruitment handles itself.",
        time: "5 hrs/week across two years",
        why: "'Get a leadership role' is a checkbox; '8 to 45 with named projects' is evidence. Berkeley's readers are trained to tell them apart in seconds.",
        note: "The membership-growth-with-projects story reads at full value at UCLA and UCSD — comprehensive review is UC-wide.",
        alts: ["Revive any dormant club with a project-first model", "Start a repair/reuse program with the custodial staff", "Green team partnership with your district's facilities office"],
      },
      {
        t: "School garden initiative funded by a $2K grant I wrote",
        story: "Our cafeteria composted nothing and our biology classes had no outdoor space. I wrote a grant to a regional environmental foundation — rejected once, funded at $2,000 on the resubmission — and we built six raised beds that three science classes now use.",
        learned: "A rejection with feedback is half an acceptance. The resubmission took one afternoon.",
        time: "~25 hrs writing + build weekends",
        why: "Fundraising plus a physical, permanent artifact at your school is the rarest kind of high school evidence. My Berkeley PIQ opened in that hardware store.",
        note: "Grant-funded impact is the same currency at UCLA and UCSD; the resubmission arc doubles as a 'response to setback' PIQ anywhere.",
        alts: ["District sustainability mini-grants", "Lowe's/Home Depot community project grants", "Crowdfund with a published budget and post-build report"],
      },
      {
        t: "Lead organizer, Bay Area Youth Climate Summit",
        story: "Senior year, three other club presidents and I organized a one-day summit: 300 students from 14 schools, 12 workshops, one very stressed group chat. I ran logistics and sponsorships. It still runs annually without us — which is the part I'm proudest of.",
        learned: "The real test of organizing is whether it survives your graduation.",
        time: "8 hrs/week, Aug–Feb",
        why: "Cross-school coordination at scale, with institutional persistence, is leadership Berkeley can't ignore — it's civic infrastructure, not an activity.",
        note: "Regional organizing plays identically at all three UCs; UCSD's readers flagged the 14-schools detail in my counselor's feedback.",
        alts: ["County-wide hackathon or case competition", "Youth advisory board for a local environmental nonprofit", "Regional conference for an existing org (key roles, not founding)"],
      },
      {
        t: "Berkeley EEP — the major that matched the résumé",
        story: "I found Environmental Economics & Policy in Berkeley's catalog junior year and realized my whole club life was an audition for it. My 'why Berkeley' was two paragraphs of specifics: EEP courses, the Rausser College, the campus's own carbon-neutrality work.",
        learned: "Reverse-engineer your target: find the exact program, then let it organize your last two years.",
        time: "UC app: Sept–Nov 30",
        why: "Specificity is credibility. Naming EEP — not 'the environment' — told Berkeley I'd done the homework on them, not just on myself.",
        note: "UCLA's Environmental Science and UCSD's Environmental Systems are the sibling programs — same framework, adjust the two paragraphs of specifics.",
        alts: ["UCLA Environmental Science (IoES)", "UCSD Environmental Systems Program", "Berkeley Society & Environment as the policy-heavier twin"],
      },
    ],
    replies: [
      "The 8-to-45 growth had one trick: projects with visible outcomes. What does your club actually *make*? Start there and recruitment fixes itself.",
      "Grant writing sounds adult and intimidating; it's a one-page letter with a budget table. First rejection is normal — mine funded on resubmit. Want my outline?",
      "Summit organizing tip: get three co-organizers from other schools first. Cross-school anything instantly reads bigger to UC readers because it is bigger.",
      "EEP at Berkeley, IoES at UCLA, ESYS at UCSD — same student, three doors. I'll help you write the two specific paragraphs for whichever you target.",
    ],
  },
];

/* ---------------- Demo chats ---------------- */
const INIT_CHATS = {
  m1: [
    { from: "them", text: "Hey! Saw you're targeting Berkeley for CS — that was me five years ago. Ask me anything about the EECS path 🐻", time: "Mon 4:12 PM" },
    { from: "me", text: "Hi Priya! How competitive is COSMOS actually? My counselor made it sound impossible.", time: "Mon 4:30 PM" },
    { from: "them", text: "Less impossible than it sounds — Cluster acceptance varies a lot. Strong math grades + a genuine 'why' essay is most of it. The bigger mistake is not applying. Apps open in January!", time: "Mon 4:33 PM" },
  ],
  m2: [
    { from: "them", text: "Welcome to LinkTeen! If you're even 20% curious about business + engineering, let's talk M.E.T. — I wish someone had told me about it in 10th grade.", time: "Tue 11:02 AM" },
  ],
  m3: [],
  m4: [],
};

/* ---------------- Demo students (mentor side) ---------------- */
const DEMO_STUDENTS = [
  {
    id: "s1",
    demo: true, name: "Ava Rodriguez", grade: 11, target: "berkeley", school: "berkeley",
    interest: "Computer Science", last: "Asked about COSMOS essays",
    color: "#F48947", color2: "#FBBF77",
    replies: [
      "Thank you!! I'll have the COSMOS draft ready by Friday 🙏",
      "Quick question — should I mention my robotics project in the COSMOS essay, or save it for the PIQs?",
      "That makes so much sense. Updating my activities list right now.",
      "Okay, deep-not-wide. I'm dropping two clubs and doubling down on the research idea.",
    ],
  },
  {
    id: "s2",
    demo: true, name: "Jordan Kim", grade: 10, target: "berkeley", school: "berkeley",
    interest: "Business", last: "Building a tutoring nonprofit",
    color: "#A465E2", color2: "#C9A0F0",
    replies: [
      "We're at 11 tutors now — I started tracking hours in a spreadsheet like you said!",
      "Could we do a quick call about the grant template this week?",
      "Just emailed the foundation. Fingers crossed 🤞",
      "M.E.T. in 10th grade feels far away but I'm bookmarking everything you're sending.",
    ],
  },
  {
    id: "s3",
    demo: true, name: "Sam Patel", grade: 12, target: "ucla", school: "ucla",
    interest: "Pre-Med", last: "PIQ draft review scheduled",
    color: "#2774AE", color2: "#7FB4DC",
    replies: [
      "Got it — I'll ask about family-facing volunteer roles at my next hospital shift.",
      "Pasting my PIQ opening below — is it too dramatic? Be honest 😅",
      "Signed up for the EMT info session Thursday. Thank you!!",
      "Nov 30 is so soon. Okay. One story, four PIQs. I can do this.",
    ],
  },
  {
    id: "s4",
    demo: true, name: "Maya Chen", grade: 9, target: "ucsd", school: "ucsd",
    interest: "Design", last: "Starting a portfolio",
    color: "#182B49", color2: "#5E7BA6",
    replies: [
      "Starting small: redesigning our club's signup page first!",
      "Is Figma okay for the portfolio or should I learn to code it?",
      "Just finished my first case study draft — can I send it over?",
      "The 'uninvited redesign' idea is genius. Our library website is SO broken.",
    ],
  },
  {
    id: "s5",
    demo: true, name: "Leo Thompson", grade: 11, target: "berkeley", school: "berkeley",
    interest: "Research", last: "Cold-emailing labs this week",
    color: "#0E7C86", color2: "#63BFC7",
    replies: [
      "Sent 6 cold emails today — one professor already replied!!",
      "What should I say in the follow-up? I don't want to sound desperate.",
      "The lab said I can start Saturdays 🎉🎉",
      "Week one done. Mostly labeling data, but I'm IN the room.",
    ],
  },
];
const STUDENT_CONTACTS = DEMO_STUDENTS;

const INIT_MENTOR_CHATS = {
  s1: [
    { from: "them", text: "Hi! I'm applying to COSMOS this cycle — my counselor said you did Cluster 5. Could you look at my essay once I have a draft?", time: "Mon 3:05 PM" },
    { from: "me", text: "Absolutely — send it whenever. One tip before you start: lead with the specific thing you're obsessed with, not why you 'love STEM.'", time: "Mon 3:22 PM" },
    { from: "them", text: "Okay that already changes my whole first paragraph 😅 Working on it!", time: "Mon 3:40 PM" },
  ],
  s2: [
    { from: "them", text: "Hey! I run a small tutoring group (4 tutors) and saw your TutorBridge journey. How did you get from 4 to 22 tutors??", time: "Tue 5:14 PM" },
  ],
  s3: [],
  s4: [
    { from: "them", text: "Hi! 9th grader here 👋 Is it too early to start a design portfolio?", time: "Wed 7:02 PM" },
  ],
  s5: [],
};

/* ---------------- Global CSS ---------------- */
const GlobalStyle = () => (
  <style>{`
    @import url('https://fonts.googleapis.com/css2?family=Outfit:wght@500;600;700;800&family=DM+Sans:ital,opsz,wght@0,9..40,400;0,9..40,500;0,9..40,700;1,9..40,400&display=swap');
    * { box-sizing: border-box; }
    .lt-app { font-family: 'DM Sans', sans-serif; color: ${C.ink}; }
    .lt-h { font-family: 'Outfit', sans-serif; }
    @keyframes ltToastIn { from { transform: translateX(120%); opacity: 0; } to { transform: translateX(0); opacity: 1; } }
    @keyframes ltFadeUp { from { transform: translateY(14px); opacity: 0; } to { transform: translateY(0); opacity: 1; } }
    @keyframes ltPop { 0% { transform: scale(.6); opacity: 0; } 70% { transform: scale(1.08); } 100% { transform: scale(1); opacity: 1; } }
    @keyframes ltSpin { 0% { transform: rotate(0deg); } 60% { transform: rotate(380deg); } 80% { transform: rotate(350deg); } 100% { transform: rotate(360deg); } }
    @keyframes ltDot { 0%, 60%, 100% { transform: translateY(0); opacity:.4 } 30% { transform: translateY(-4px); opacity:1 } }
    .lt-fadeup { animation: ltFadeUp .45s cubic-bezier(.2,.7,.3,1) both; }
    .lt-grad-text { background: linear-gradient(90deg, ${C.primary}, ${C.accent}); -webkit-background-clip: text; background-clip: text; color: transparent; }
    .lt-pop { animation: ltPop .5s cubic-bezier(.2,.7,.3,1) both; }
    .lt-card-hover { transition: transform .18s ease, box-shadow .18s ease; }
    .lt-card-hover:hover { transform: translateY(-3px); box-shadow: 0 16px 40px rgba(244,137,71,.16), 0 4px 12px rgba(51,36,27,.07); }
    .lt-btn { transition: transform .12s ease, filter .15s ease, box-shadow .15s ease; cursor: pointer; }
    .lt-btn:hover { filter: brightness(1.05); transform: translateY(-1px); }
    .lt-btn:active { transform: translateY(0) scale(.98); }
    .lt-btn:focus-visible, .lt-nav:focus-visible, input:focus-visible, textarea:focus-visible, select:focus-visible { outline: 3px solid ${C.accent}55; outline-offset: 2px; border-radius: 12px; }
    input, textarea, select { font-family: 'DM Sans', sans-serif; }
    ::placeholder { color: #C4AE9E; }
    .lt-scroll::-webkit-scrollbar { width: 8px; height: 8px; }
    .lt-scroll::-webkit-scrollbar-thumb { background: ${C.line}; border-radius: 8px; }
    @media (prefers-reduced-motion: reduce) {
      .lt-fadeup, .lt-pop, .lt-compass { animation: none !important; }
      .lt-card-hover, .lt-btn { transition: none !important; }
    }
  `}</style>
);

/* ---------------- Shared UI ---------------- */
function Avatar({ m, size = 44, ring = false }) {
  const initials = m.name.split(" ").map((w) => w[0]).join("").slice(0, 2);
  return (
    <div
      style={{
        width: size, height: size, borderRadius: "50%", flexShrink: 0, overflow: "hidden",
        background: `linear-gradient(135deg, ${m.color}, ${m.color2 || C.accent})`,
        display: "flex", alignItems: "center", justifyContent: "center",
        color: "#fff", fontWeight: 700, fontSize: size * 0.36,
        fontFamily: "'Outfit', sans-serif",
        boxShadow: ring ? `0 0 0 3px #fff, 0 0 0 5px ${m.color}44` : "none",
      }}
    >
      {m.photo ? <img src={m.photo} alt="" style={{ width: "100%", height: "100%", objectFit: "cover" }} /> : initials}
    </div>
  );
}

function SchoolBadge({ school, year, small = false }) {
  const s = SCHOOLS[school];
  return (
    <span
      className="lt-h"
      style={{
        background: s.chip, color: s.chipText, borderRadius: 999,
        padding: small ? "3px 10px" : "5px 14px", fontSize: small ? 11 : 12.5,
        fontWeight: 700, letterSpacing: 0.3, whiteSpace: "nowrap", display: "inline-block",
      }}
    >
      {s.short}{year ? ` '${String(year).slice(2)}` : ""}
    </span>
  );
}

function DemoBadge() {
  return (
    <span
      className="lt-h"
      title="Sample profile for demonstration — cannot respond"
      style={{
        background: "#F1E9E0", color: "#A08B7A", border: "1.5px dashed #D8C7B8",
        borderRadius: 999, padding: "3px 9px", fontSize: 10, fontWeight: 800,
        letterSpacing: 1.2, whiteSpace: "nowrap",
      }}
    >
      DEMO
    </span>
  );
}

function Chip({ active, children, onClick }) {
  return (
    <button
      className="lt-btn"
      onClick={onClick}
      style={{
        border: `1.5px solid ${active ? C.primary : C.line}`,
        background: active ? C.primary : "#fff",
        color: active ? "#fff" : C.sub,
        borderRadius: 999, padding: "8px 16px", fontSize: 13.5, fontWeight: 600,
        whiteSpace: "nowrap",
      }}
    >
      {children}
    </button>
  );
}

function TagPill({ text, onRemove, purple = false }) {
  return (
    <span
      style={{
        display: "inline-flex", alignItems: "center", gap: 6,
        background: purple ? C.softPurple : C.soft,
        color: purple ? C.accent : C.primaryDark,
        borderRadius: 999, padding: "6px 12px", fontSize: 13, fontWeight: 600,
      }}
    >
      {text}
      {onRemove && (
        <button onClick={onRemove} className="lt-btn" style={{ background: "none", border: "none", padding: 0, display: "flex", color: "inherit" }} aria-label={`Remove ${text}`}>
          <X size={13} />
        </button>
      )}
    </span>
  );
}

function PrimaryBtn({ children, onClick, big = false, style: st = {} }) {
  return (
    <button
      className="lt-btn lt-h"
      onClick={onClick}
      style={{
        background: GRAD,
        color: "#fff", border: "none", borderRadius: 16,
        padding: big ? "15px 32px" : "11px 22px",
        fontSize: big ? 16.5 : 14.5, fontWeight: 700,
        boxShadow: "0 8px 20px rgba(196,110,150,.35)",
        display: "inline-flex", alignItems: "center", gap: 8, ...st,
      }}
    >
      {children}
    </button>
  );
}

function GhostBtn({ children, onClick, style: st = {} }) {
  return (
    <button
      className="lt-btn lt-h"
      onClick={onClick}
      style={{
        background: "#fff", color: C.primaryDark, border: `1.5px solid ${C.line}`,
        borderRadius: 16, padding: "10px 20px", fontSize: 14, fontWeight: 700,
        display: "inline-flex", alignItems: "center", gap: 8, boxShadow: SHADOW_SM, ...st,
      }}
    >
      {children}
    </button>
  );
}

function Card({ children, style: st = {}, className = "", onClick }) {
  return (
    <div
      className={className}
      onClick={onClick}
      style={{ background: C.card, borderRadius: R, boxShadow: SHADOW_SM, border: `1px solid ${C.line}`, ...st }}
    >
      {children}
    </div>
  );
}

function Field({ label, children }) {
  return (
    <label style={{ display: "block", marginBottom: 18 }}>
      <div className="lt-h" style={{ fontSize: 13.5, fontWeight: 700, marginBottom: 7, color: C.ink }}>{label}</div>
      {children}
    </label>
  );
}

const inputStyle = {
  width: "100%", border: `1.5px solid ${C.line}`, borderRadius: 14,
  padding: "12px 15px", fontSize: 14.5, background: "#fff", color: C.ink,
};

function TagInput({ tags, setTags, placeholder, purple }) {
  const [val, setVal] = useState("");
  const add = () => {
    const t = val.trim();
    if (t && !tags.includes(t)) setTags([...tags, t]);
    setVal("");
  };
  return (
    <div style={{ ...inputStyle, display: "flex", flexWrap: "wrap", gap: 7, padding: 9 }}>
      {tags.map((t) => (
        <TagPill key={t} text={t} purple={purple} onRemove={() => setTags(tags.filter((x) => x !== t))} />
      ))}
      <input
        value={val}
        onChange={(e) => setVal(e.target.value)}
        onKeyDown={(e) => { if (e.key === "Enter") { e.preventDefault(); add(); } }}
        placeholder={tags.length ? "" : placeholder}
        style={{ border: "none", outline: "none", flex: 1, minWidth: 120, fontSize: 14, padding: "5px 6px", background: "transparent" }}
      />
    </div>
  );
}

function Toasts({ toasts }) {
  return (
    <div style={{ position: "fixed", top: 20, right: 20, zIndex: 100, display: "flex", flexDirection: "column", gap: 10 }}>
      {toasts.map((t) => (
        <div
          key={t.id}
          style={{
            background: "#fff", borderRadius: 16, boxShadow: SHADOW, border: `1px solid ${C.line}`,
            padding: "13px 18px", display: "flex", alignItems: "center", gap: 10,
            animation: "ltToastIn .35s cubic-bezier(.2,.7,.3,1) both", maxWidth: 340,
          }}
        >
          <span style={{ background: C.soft, borderRadius: 10, padding: 6, display: "flex", color: C.primaryDark }}>
            {t.icon || <Sparkles size={16} />}
          </span>
          <span style={{ fontSize: 13.5, fontWeight: 600 }}>{t.msg}</span>
        </div>
      ))}
    </div>
  );
}

/* ================= AUTH ================= */
function AuthScreen({ role, onBack }) {
  const [mode, setMode] = useState("signup");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [sent, setSent] = useState(false);
  const accent = role === "mentor" ? C.accent : C.primary;

  const go = async () => {
    if (!email.trim() || password.length < 6) { setError("Enter your email and a password of at least 6 characters."); return; }
    setBusy(true); setError("");
    try {
      if (mode === "signup") {
        const data = await api.signUp(email.trim(), password, role);
        if (!data.session) { setSent(true); setBusy(false); return; }
      } else {
        await api.signIn(email.trim(), password);
      }
    } catch (err) {
      const msg = (err && err.message) || "Something went wrong — try again.";
      setError(/not confirmed/i.test(msg)
        ? "Your email isn't confirmed yet — click the link in the email we sent you, then sign in."
        : msg);
      setBusy(false);
    }
  };

  if (sent) {
    return (
      <div style={{ minHeight: "100vh", background: C.bg, display: "flex", alignItems: "center", justifyContent: "center", padding: 24 }}>
        <Card className="lt-pop" style={{ padding: 34, borderRadius: 24, maxWidth: 440, textAlign: "center" }}>
          <div style={{ width: 68, height: 68, borderRadius: "50%", background: GRAD, display: "flex", alignItems: "center", justifyContent: "center", color: "#fff", margin: "0 auto 18px", boxShadow: "0 10px 26px rgba(196,110,150,.4)" }}>
            <Send size={28} />
          </div>
          <h1 className="lt-h" style={{ fontSize: 24, fontWeight: 800, margin: "0 0 10px" }}>Confirm your email</h1>
          <p style={{ color: C.sub, fontSize: 14.5, lineHeight: 1.6, margin: "0 0 6px" }}>We sent a confirmation link to</p>
          <p className="lt-h" style={{ fontWeight: 800, fontSize: 15, margin: "0 0 14px", wordBreak: "break-all" }}>{email}</p>
          <p style={{ color: C.sub, fontSize: 13.5, lineHeight: 1.6, margin: "0 0 22px" }}>
            Open that email, click the link, then come back here and sign in. (Check spam if it doesn't arrive within a minute.)
          </p>
          <PrimaryBtn big style={{ width: "100%", justifyContent: "center" }} onClick={() => { setSent(false); setMode("signin"); setPassword(""); }}>
            I've confirmed — Sign In <ArrowRight size={18} />
          </PrimaryBtn>
        </Card>
      </div>
    );
  }

  return (
    <div style={{ minHeight: "100vh", background: C.bg, display: "flex", alignItems: "center", justifyContent: "center", padding: 24 }}>
      <div className="lt-fadeup" style={{ width: "100%", maxWidth: 440 }}>
        <button className="lt-btn lt-h" onClick={onBack} style={{ background: "none", border: "none", color: C.sub, fontWeight: 700, fontSize: 14, display: "flex", alignItems: "center", gap: 5, padding: 0, marginBottom: 16, cursor: "pointer" }}>
          <ChevronRight size={16} style={{ transform: "rotate(180deg)" }} /> Back
        </button>
        <div style={{ textAlign: "center", marginBottom: 22 }}>
          <img src={LOGO_IMG} alt="LinkTeen" style={{ width: 64, height: 64, borderRadius: "50%", border: `2px solid ${C.line}`, marginBottom: 12 }} />
          <h1 className="lt-h" style={{ fontSize: 26, fontWeight: 800, margin: 0 }}>
            {mode === "signup" ? (role === "mentor" ? "Create your mentor account" : "Create your student account") : "Welcome back"}
          </h1>
          <p style={{ color: C.sub, fontSize: 14, marginTop: 6 }}>
            {mode === "signup" ? "Your account keeps your profile, roadmap, and messages saved." : "Sign in to pick up where you left off."}
          </p>
        </div>
        {!SUPABASE_CONFIGURED && (
          <div style={{ background: "#FFF6E5", border: "1.5px solid #F1DFB8", color: "#8A6A1F", borderRadius: 14, padding: "11px 15px", fontSize: 13, marginBottom: 14, lineHeight: 1.5 }}>
            ⚠️ Supabase keys aren't set yet, so accounts won't work. Open <b>src/supabaseClient.js</b> and paste your Project URL and key.
          </div>
        )}
        <Card style={{ padding: 26, borderRadius: 24 }}>
          <Field label="Email"><input style={inputStyle} type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" /></Field>
          <Field label="Password"><input style={inputStyle} type="password" value={password} onChange={(e) => setPassword(e.target.value)} onKeyDown={(e) => e.key === "Enter" && go()} placeholder="At least 6 characters" /></Field>
          {error && <div style={{ background: "#FDECEC", color: "#B0403A", borderRadius: 12, padding: "10px 14px", fontSize: 13, marginBottom: 14 }}>{error}</div>}
          <PrimaryBtn big onClick={go} style={{ width: "100%", justifyContent: "center", opacity: busy ? 0.7 : 1 }}>
            {busy ? "One sec…" : mode === "signup" ? "Create Account" : "Sign In"} <ArrowRight size={18} />
          </PrimaryBtn>
          <div style={{ textAlign: "center", marginTop: 14, fontSize: 13.5, color: C.sub }}>
            {mode === "signup" ? "Already have an account? " : "New here? "}
            <button className="lt-btn lt-h" onClick={() => { setMode(mode === "signup" ? "signin" : "signup"); setError(""); }} style={{ background: "none", border: "none", color: accent, fontWeight: 700, cursor: "pointer", padding: 0 }}>
              {mode === "signup" ? "Sign in" : "Create one"}
            </button>
          </div>
        </Card>
      </div>
    </div>
  );
}

/* ================= ROLE SELECTION ================= */
function RoleSelect({ onPick }) {
  return (
    <div style={{ minHeight: "100vh", background: `radial-gradient(900px 500px at 85% -10%, ${C.accent}22, transparent), radial-gradient(700px 400px at -10% 30%, ${C.primary}1A, transparent), ${C.bg}` }}>
      <div style={{ padding: "26px 28px 0", display: "flex", alignItems: "center", gap: 11 }}>
        <img src={LOGO_IMG} alt="LinkTeen logo" style={{ width: 48, height: 48, borderRadius: "50%", border: `2px solid ${C.line}`, boxShadow: SHADOW_SM }} />
        <span className="lt-h" style={{ fontSize: 21, fontWeight: 800 }}>LinkTeen</span>
      </div>
      <div style={{ height: "9vh", minHeight: 36 }} />
      <div className="lt-fadeup" style={{ position: "relative", maxWidth: 820, margin: "0 auto", padding: "0 24px 48px", textAlign: "center" }}>
        <h1 className="lt-h" style={{ fontSize: "clamp(27px, 6.5vw, 38px)", fontWeight: 800, margin: "0 0 10px", lineHeight: 1.18 }}>
          Real paths to <span className="lt-grad-text">Berkeley</span>,<br />from people who took them.
        </h1>
        <p style={{ color: C.sub, fontSize: 16, margin: "0 auto 30px", maxWidth: 540, lineHeight: 1.6 }}>
          Mentor journeys built around what it actually takes to get into UC Berkeley — and how the same roadmap carries you to UCLA and UCSD.
        </p>
        <div style={{ display: "flex", gap: 24, flexWrap: "wrap", justifyContent: "center" }}>
          {[
            { role: "student", icon: <GraduationCap size={34} />, title: "I'm a Student", desc: "Explore real journeys into Berkeley, UCLA & UCSD, build your roadmap, and talk to the mentors who lived them.", grad: [C.primary, "#FBB271"] },
            { role: "mentor", icon: <Users size={34} />, title: "I'm a Mentor", desc: "You made it to a top UC. Share the exact experiences that got you in and guide the next class of students.", grad: [C.accent, "#C79BEF"] },
          ].map((c, i) => (
            <button
              key={c.role}
              className="lt-btn lt-card-hover lt-fadeup"
              onClick={() => onPick(c.role)}
              style={{
                background: "#fff", border: `1.5px solid ${C.line}`, borderRadius: 28, boxShadow: SHADOW,
                width: 330, padding: "34px 30px", textAlign: "left", cursor: "pointer",
                animationDelay: `${0.1 + i * 0.1}s`,
              }}
            >
              <div style={{ width: 66, height: 66, borderRadius: 22, background: `linear-gradient(135deg, ${c.grad[0]}, ${c.grad[1]})`, display: "flex", alignItems: "center", justifyContent: "center", color: "#fff", marginBottom: 18, boxShadow: `0 10px 24px ${c.grad[0]}44` }}>
                {c.icon}
              </div>
              <div className="lt-h" style={{ fontSize: 23, fontWeight: 800, marginBottom: 8 }}>{c.title}</div>
              <div style={{ fontSize: 14.5, color: C.sub, lineHeight: 1.55 }}>{c.desc}</div>
              <div className="lt-h" style={{ marginTop: 18, color: c.grad[0], fontWeight: 700, fontSize: 14.5, display: "flex", alignItems: "center", gap: 6 }}>
                Get started <ArrowRight size={16} />
              </div>
            </button>
          ))}
        </div>
        <div className="lt-h" style={{ marginTop: 30, fontSize: 12.5, fontWeight: 700, color: C.sub, letterSpacing: 1.5, textTransform: "uppercase" }}>
          A Bridge to Excellence · Berkeley 🐻 · UCLA · UCSD
        </div>
      </div>
    </div>
  );
}

/* ================= MENTOR REGISTRATION ================= */
function MentorRegistration({ onDone }) {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [school, setSchool] = useState("berkeley");
  const [year, setYear] = useState("2022");
  const [roleTitle, setRoleTitle] = useState("");
  const [bio, setBio] = useState("");
  const [tags, setTags] = useState([]);
  const [photo, setPhoto] = useState(null);
  const fileRef = useRef(null);

  const submit = () => {
    if (!name.trim()) return;
    onDone({ name: name.trim(), email, school, year, roleTitle, bio, tags, photo, color: C.accent, color2: "#C79BEF" });
  };

  return (
    <div style={{ minHeight: "100vh", background: C.bg, padding: "48px 24px" }}>
      <div className="lt-fadeup" style={{ maxWidth: 640, margin: "0 auto" }}>
        <div className="lt-h" style={{ fontSize: 14, fontWeight: 700, color: C.accent, letterSpacing: 2, textTransform: "uppercase", marginBottom: 8 }}>Mentor registration</div>
        <h1 className="lt-h" style={{ fontSize: 32, fontWeight: 800, margin: "0 0 8px" }}>Share how you got in.</h1>
        <p style={{ color: C.sub, fontSize: 15, marginBottom: 28 }}>Students come here for the real story — especially what got you into Berkeley, and how it translates to UCLA and UCSD.</p>

        <Card style={{ padding: 30, borderRadius: 26 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 18, marginBottom: 24 }}>
            <button
              className="lt-btn"
              onClick={() => fileRef.current && fileRef.current.click()}
              style={{ width: 84, height: 84, borderRadius: "50%", border: `2px dashed ${C.accent}66`, background: C.softPurple, display: "flex", alignItems: "center", justifyContent: "center", color: C.accent, overflow: "hidden", flexShrink: 0 }}
              aria-label="Upload photo"
            >
              {photo ? <img src={photo} alt="Profile" style={{ width: "100%", height: "100%", objectFit: "cover" }} /> : <Camera size={26} />}
            </button>
            <div>
              <div className="lt-h" style={{ fontWeight: 700, fontSize: 15 }}>Upload photo</div>
              <div style={{ fontSize: 13, color: C.sub }}>Students trust faces. A casual photo works great.</div>
            </div>
            <input ref={fileRef} type="file" accept="image/*" style={{ display: "none" }} onChange={(e) => { const f = e.target.files && e.target.files[0]; if (f) setPhoto(URL.createObjectURL(f)); }} />
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "0 18px" }}>
            <Field label="Full name"><input style={inputStyle} value={name} onChange={(e) => setName(e.target.value)} placeholder="Jordan Rivera" /></Field>
            <Field label="Email"><input style={inputStyle} value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@berkeley.edu" /></Field>
            <Field label="UC school">
              <select style={inputStyle} value={school} onChange={(e) => setSchool(e.target.value)}>
                <option value="berkeley">UC Berkeley (most requested)</option>
                <option value="ucla">UCLA</option>
                <option value="ucsd">UC San Diego</option>
              </select>
            </Field>
            <Field label="Graduation year">
              <select style={inputStyle} value={year} onChange={(e) => setYear(e.target.value)}>
                {["2026","2025","2024","2023","2022","2021","2020","2019"].map((y) => <option key={y}>{y}</option>)}
              </select>
            </Field>
          </div>
          <Field label="Current role / title"><input style={inputStyle} value={roleTitle} onChange={(e) => setRoleTitle(e.target.value)} placeholder="Software Engineer at Figma" /></Field>
          <Field label="Your bio — lead with what got you into your UC">
            <textarea style={{ ...inputStyle, minHeight: 110, resize: "vertical" }} value={bio} onChange={(e) => setBio(e.target.value)} placeholder="e.g. Four years of Science Olympiad and a circuit board that failed 40 times got me into Berkeley EECS. Here's how the same arc works for UCLA and UCSD…" />
          </Field>
          <Field label="Expertise tags (type + Enter)">
            <TagInput tags={tags} setTags={setTags} placeholder="EECS, PIQ essays, COSMOS, M.E.T. …" purple />
          </Field>
          <PrimaryBtn big onClick={submit} style={{ width: "100%", justifyContent: "center", background: `linear-gradient(135deg, ${C.accent}, #8A48CC)`, boxShadow: "0 8px 20px rgba(164,101,226,.35)" }}>
            Create Mentor Profile <ArrowRight size={18} />
          </PrimaryBtn>
        </Card>
      </div>
    </div>
  );
}

/* ================= STUDENT ONBOARDING ================= */
function Onboarding({ onDone }) {
  const [step, setStep] = useState(1);
  const [name, setName] = useState("");
  const [grade, setGrade] = useState("10");
  const [target, setTarget] = useState("berkeley");
  const [interests, setInterests] = useState([]);
  const [photo, setPhoto] = useState(null);
  const fileRef = useRef(null);

  if (step === 2) {
    return (
      <div style={{ minHeight: "100vh", background: C.bg, display: "flex", alignItems: "center", justifyContent: "center", padding: 24 }}>
        <div className="lt-pop" style={{ textAlign: "center", maxWidth: 480 }}>
          <div
            className="lt-compass"
            style={{
              width: 108, height: 108, borderRadius: "50%", margin: "0 auto 26px",
              background: `linear-gradient(135deg, ${C.primary}, ${C.accent})`,
              display: "flex", alignItems: "center", justifyContent: "center", color: "#fff",
              boxShadow: "0 16px 40px rgba(244,137,71,.4)",
            }}
          >
            <Compass size={52} style={{ animation: "ltSpin 1.6s cubic-bezier(.3,.6,.3,1) .2s both" }} />
          </div>
          <h1 className="lt-h" style={{ fontSize: 34, fontWeight: 800, margin: "0 0 10px" }}>You're all set, {name.split(" ")[0]}!</h1>
          <p style={{ color: C.sub, fontSize: 16.5, lineHeight: 1.55, marginBottom: 30 }}>
            Let's build your path to Berkeley — or UCLA, or UCSD.
          </p>
          <PrimaryBtn big onClick={() => onDone({ name: name.trim(), grade, target, interests, photo })}>
            Explore LinkTeen <ArrowRight size={18} />
          </PrimaryBtn>
        </div>
      </div>
    );
  }

  return (
    <div style={{ minHeight: "100vh", background: C.bg, display: "flex", alignItems: "center", justifyContent: "center", padding: 24 }}>
      <div className="lt-fadeup" style={{ width: "100%", maxWidth: 520 }}>
        <div className="lt-h" style={{ fontSize: 13.5, fontWeight: 700, color: C.primary, letterSpacing: 2, textTransform: "uppercase", marginBottom: 8, textAlign: "center" }}>Step 1 of 2</div>
        <h1 className="lt-h" style={{ fontSize: 30, fontWeight: 800, margin: "0 0 6px", textAlign: "center" }}>Tell us about you</h1>
        <p style={{ color: C.sub, fontSize: 14.5, textAlign: "center", marginBottom: 26 }}>We'll match you with mentors who took the path you want.</p>
        <Card style={{ padding: 28, borderRadius: 26 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 16, marginBottom: 20 }}>
            <button
              className="lt-btn"
              onClick={() => fileRef.current && fileRef.current.click()}
              style={{ width: 74, height: 74, borderRadius: "50%", border: `2px dashed ${C.primary}66`, background: C.soft, display: "flex", alignItems: "center", justifyContent: "center", color: C.primaryDark, overflow: "hidden", flexShrink: 0, cursor: "pointer" }}
              aria-label="Upload profile photo"
            >
              {photo ? <img src={photo} alt="Profile" style={{ width: "100%", height: "100%", objectFit: "cover" }} /> : <Camera size={24} />}
            </button>
            <div>
              <div className="lt-h" style={{ fontWeight: 700, fontSize: 14.5 }}>Add a profile photo</div>
              <div style={{ fontSize: 12.5, color: C.sub }}>Optional — you can add or change it anytime from the sidebar.</div>
            </div>
            <input ref={fileRef} type="file" accept="image/*" style={{ display: "none" }} onChange={(e) => { const f = e.target.files && e.target.files[0]; if (f) setPhoto(URL.createObjectURL(f)); }} />
          </div>
          <Field label="Your name"><input style={inputStyle} value={name} onChange={(e) => setName(e.target.value)} placeholder="Alex Chen" /></Field>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(min(100%, 190px), 1fr))", gap: "0 18px" }}>
            <Field label="Grade">
              <select style={inputStyle} value={grade} onChange={(e) => setGrade(e.target.value)}>
                {["9", "10", "11", "12"].map((g) => <option key={g} value={g}>{g}th grade</option>)}
              </select>
            </Field>
            <Field label="Target school">
              <select style={inputStyle} value={target} onChange={(e) => setTarget(e.target.value)}>
                <option value="berkeley">UC Berkeley — the north star</option>
                <option value="ucla">UCLA</option>
                <option value="ucsd">UC San Diego</option>
              </select>
            </Field>
          </div>
          <Field label="Your interests (type + Enter)">
            <TagInput tags={interests} setTags={setInterests} placeholder="robotics, pre-med, debate, design…" />
          </Field>
          <PrimaryBtn big onClick={() => name.trim() && setStep(2)} style={{ width: "100%", justifyContent: "center" }}>
            Get Started <ArrowRight size={18} />
          </PrimaryBtn>
        </Card>
      </div>
    </div>
  );
}

/* ================= JOURNEY PATH NODES ================= */
function PathNodes({ path, color }) {
  return (
    <div style={{ display: "flex", flexWrap: "wrap", alignItems: "center", gap: 6, rowGap: 8 }}>
      {path.map((p, i) => (
        <React.Fragment key={i}>
          <span
            className="lt-h"
            style={{
              background: i === path.length - 1 ? color : C.soft,
              color: i === path.length - 1 ? "#fff" : C.primaryDark,
              borderRadius: 999, padding: "5px 11px", fontSize: 11.5, fontWeight: 700,
            }}
          >
            {p}
          </span>
          {i < path.length - 1 && <ArrowRight size={13} color={C.sub} style={{ flexShrink: 0 }} />}
        </React.Fragment>
      ))}
    </div>
  );
}

/* ================= EXPLORE ================= */
function Explore({ student, mentors, openJourney, talkTo }) {
  const [tab, setTab] = useState("journeys");
  const [cat, setCat] = useState("All");
  const [q, setQ] = useState("");
  const [schoolFilter, setSchoolFilter] = useState("all");

  const match = (m) => {
    const catOk = cat === "All" || (m.cats || []).includes(cat);
    const qOk = !q || (m.name + m.major + m.role + m.tags.join(" ") + m.path.join(" ")).toLowerCase().includes(q.toLowerCase());
    return catOk && qOk;
  };
  const ordered = [...mentors].sort((a, b) => (a.demo ? 1 : 0) - (b.demo ? 1 : 0));
  const journeys = ordered.filter(match);
  const mentorList = ordered.filter((m) => match(m) && (schoolFilter === "all" || m.school === schoolFilter));

  return (
    <div className="lt-fadeup">
      <div style={{ marginBottom: 6, display: "flex", alignItems: "center", gap: 10, flexWrap: "wrap" }}>
        <h1 className="lt-h" style={{ fontSize: "clamp(24px, 5.5vw, 32px)", fontWeight: 800, margin: 0 }}>Find Your Path to <span className="lt-grad-text">Berkeley</span></h1>
      </div>
      <p style={{ color: C.sub, fontSize: 14.5, margin: "4px 0 20px", display: "flex", alignItems: "center", gap: 7 }}>
        <Sparkles size={15} color={C.accent} /> Roadmaps here also work for UCLA & UCSD — same UC application, same core strengths.
      </p>

      <div style={{ display: "flex", gap: 12, marginBottom: 16, flexWrap: "wrap" }}>
        <div style={{ flex: 1, minWidth: 260, position: "relative" }}>
          <Search size={17} color={C.sub} style={{ position: "absolute", left: 15, top: 14 }} />
          <input
            style={{ ...inputStyle, paddingLeft: 42, borderRadius: 999, boxShadow: SHADOW_SM }}
            placeholder="Search journeys, programs, mentors… (try 'COSMOS' or 'research')"
            value={q}
            onChange={(e) => setQ(e.target.value)}
          />
        </div>
      </div>
      <div className="lt-scroll" style={{ display: "flex", gap: 8, overflowX: "auto", paddingBottom: 8, marginBottom: 18 }}>
        {CATS.map((c) => <Chip key={c} active={cat === c} onClick={() => setCat(c)}>{c}</Chip>)}
      </div>

      <div style={{ display: "inline-flex", background: "#fff", border: `1.5px solid ${C.line}`, borderRadius: 999, padding: 5, marginBottom: 22, boxShadow: SHADOW_SM }}>
        {[["journeys", "Mentor Journeys"], ["mentors", "Mentors"]].map(([id, label]) => (
          <button
            key={id}
            className="lt-btn lt-h"
            onClick={() => setTab(id)}
            style={{
              border: "none", borderRadius: 999, padding: "9px 22px", fontSize: 14, fontWeight: 700,
              background: tab === id ? GRAD : "transparent", color: tab === id ? "#fff" : C.sub,
            }}
          >
            {label}
          </button>
        ))}
      </div>

      {tab === "journeys" ? (
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(min(100%, 330px), 1fr))", gap: 20 }}>
          {journeys.map((m) => (
            <Card key={m.id} className="lt-card-hover" style={{ padding: 24, cursor: "pointer", display: "flex", flexDirection: "column", gap: 14 }} onClick={() => openJourney(m.id)}>
              <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                <Avatar m={m} size={50} ring />
                <div style={{ flex: 1 }}>
                  <div className="lt-h" style={{ fontWeight: 800, fontSize: 16.5 }}>{m.name}</div>
                  <div style={{ fontSize: 12.5, color: C.sub }}>{m.role}</div>
                </div>
                <div style={{ display: "flex", flexDirection: "column", gap: 5, alignItems: "flex-end" }}>
                  <SchoolBadge school={m.school} year={m.year} />
                  {m.demo && <DemoBadge />}
                </div>
              </div>
              <PathNodes path={m.path} color={m.color} />
              <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginTop: "auto" }}>
                <span style={{ fontSize: 11.5, fontWeight: 700, color: C.accent, background: C.softPurple, borderRadius: 999, padding: "5px 11px" }}>
                  Also works for UCLA/UCSD
                </span>
                <span className="lt-h" style={{ color: C.primary, fontWeight: 700, fontSize: 13.5, display: "flex", alignItems: "center", gap: 4 }}>
                  Read journey <ChevronRight size={15} />
                </span>
              </div>
            </Card>
          ))}
        </div>
      ) : (
        <>
          <div style={{ display: "flex", gap: 8, marginBottom: 18 }}>
            {[["all", "All UCs"], ["berkeley", "UC Berkeley"], ["ucla", "UCLA"], ["ucsd", "UCSD"]].map(([id, label]) => (
              <Chip key={id} active={schoolFilter === id} onClick={() => setSchoolFilter(id)}>{label}</Chip>
            ))}
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(min(100%, 300px), 1fr))", gap: 20 }}>
            {mentorList.map((m) => (
              <Card key={m.id} className="lt-card-hover" style={{ padding: 24 }}>
                <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 12 }}>
                  <Avatar m={m} size={54} ring />
                  <div>
                    <div className="lt-h" style={{ fontWeight: 800, fontSize: 16.5 }}>{m.name}</div>
                    <div style={{ fontSize: 12.5, color: C.sub }}>{m.major} · {m.role}</div>
                  </div>
                </div>
                <div style={{ display: "flex", gap: 8, alignItems: "center", marginBottom: 12, flexWrap: "wrap" }}>
                  <SchoolBadge school={m.school} year={m.year} small />
                  {m.demo && <DemoBadge />}
                  <span style={{ fontSize: 12.5, color: C.sub, display: "flex", alignItems: "center", gap: 4 }}>
                    {m.rating ? <><Star size={13} fill={C.primary} color={C.primary} /> {m.rating} · {m.studentsHelped} students</> : <><Sparkles size={13} color={C.accent} /> New mentor</>}
                  </span>
                </div>
                <p style={{ fontSize: 13.5, color: C.sub, lineHeight: 1.5, margin: "0 0 14px" }}>{m.bio}</p>
                <div style={{ display: "flex", gap: 10 }}>
                  <PrimaryBtn onClick={() => openJourney(m.id)} style={{ flex: 1, justifyContent: "center" }}>View Journey</PrimaryBtn>
                  <GhostBtn onClick={() => talkTo(m.id)} aria-label={`Message ${m.name}`}><MessageCircle size={16} /></GhostBtn>
                </div>
              </Card>
            ))}
          </div>
        </>
      )}
    </div>
  );
}

/* ================= JOURNEY DETAIL ================= */
function JourneyDetail({ mentorId, mentors, back, talkTo, addToRoadmap, onBookMentor }) {
  const m = mentors.find((x) => x.id === mentorId);
  const [openAlt, setOpenAlt] = useState(null);
  const s = SCHOOLS[m.school];
  const gotInLabel = m.school === "berkeley" ? "How I Got Into Berkeley" : `How I Got Into ${s.short} (on the Berkeley framework)`;

  return (
    <div className="lt-fadeup">
      <button className="lt-btn lt-h" onClick={back} style={{ background: "none", border: "none", color: C.sub, fontWeight: 700, fontSize: 14, display: "flex", alignItems: "center", gap: 5, padding: 0, marginBottom: 18 }}>
        <ChevronRight size={16} style={{ transform: "rotate(180deg)" }} /> Back to Explore
      </button>

      <Card style={{ padding: 32, borderRadius: 28, marginBottom: 26, background: `linear-gradient(135deg, #fff 55%, ${m.color}12)` }}>
        <div style={{ display: "flex", gap: 22, alignItems: "flex-start", flexWrap: "wrap" }}>
          <Avatar m={m} size={92} ring />
          <div style={{ flex: 1, minWidth: 260 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 12, flexWrap: "wrap" }}>
              <h1 className="lt-h" style={{ fontSize: 30, fontWeight: 800, margin: 0 }}>{m.name}</h1>
              <SchoolBadge school={m.school} year={m.year} />
              {m.demo && <DemoBadge />}
            </div>
            <div style={{ color: C.sub, fontSize: 14.5, margin: "6px 0 14px" }}>{m.major} · {m.role}</div>
            <p style={{ fontSize: 15, lineHeight: 1.65, margin: "0 0 14px" }}>{m.bio}</p>
            {m.moment && (
              <div style={{ background: C.soft, borderLeft: `4px solid ${C.primary}`, borderRadius: 14, padding: "14px 18px", fontSize: 14, lineHeight: 1.6, fontStyle: "italic", color: "#6B4A32" }}>
                "{m.moment}"
              </div>
            )}
            <div style={{ marginTop: 18, display: "flex", gap: 10, flexWrap: "wrap" }}>
              <PrimaryBtn onClick={() => talkTo(m.id)}>
                <MessageCircle size={17} /> Talk to Me About This
              </PrimaryBtn>
              <GhostBtn onClick={() => onBookMentor(m)}><Calendar size={16} /> Book a Call · $40</GhostBtn>
            </div>
          </div>
        </div>
      </Card>

      <h2 className="lt-h" style={{ fontSize: 23, fontWeight: 800, margin: "0 0 4px" }}>{gotInLabel}</h2>
      <p style={{ color: C.sub, fontSize: 14, marginBottom: 22 }}>Real experiences, in order — with alternatives if the exact program isn't available to you.</p>

      {m.exp.length === 0 && (
        <Card style={{ padding: 28, textAlign: "center", color: C.sub, fontSize: 14 }}>
          {m.name.split(" ")[0]} hasn't published their journey steps yet — send them a message to hear the story first-hand.
        </Card>
      )}
      <div style={{ position: "relative", paddingLeft: 34 }}>
        {m.exp.length > 0 && <div style={{ position: "absolute", left: 12, top: 8, bottom: 8, width: 3, background: `linear-gradient(${m.color}, ${C.accent})`, borderRadius: 3 }} />}
        {m.exp.map((e, i) => (
          <div key={i} style={{ position: "relative", marginBottom: 22 }}>
            <div style={{ position: "absolute", left: -30, top: 22, width: 17, height: 17, borderRadius: "50%", background: "#fff", border: `4px solid ${m.color}` }} />
            <Card style={{ padding: 24 }}>
              <div style={{ display: "flex", justifyContent: "space-between", gap: 12, flexWrap: "wrap", alignItems: "flex-start" }}>
                <h3 className="lt-h" style={{ fontSize: 17.5, fontWeight: 800, margin: 0, flex: 1, minWidth: 220 }}>{e.t}</h3>
                {e.time && (
                  <span style={{ fontSize: 12, color: C.sub, display: "flex", alignItems: "center", gap: 5, background: C.bg, borderRadius: 999, padding: "5px 12px", border: `1px solid ${C.line}` }}>
                    <Clock size={13} /> {e.time}
                  </span>
                )}
              </div>
              <p style={{ fontSize: 14.5, lineHeight: 1.65, margin: "12px 0", color: "#4A382C" }}>{e.story}</p>
              <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(240px, 1fr))", gap: 12, margin: "14px 0" }}>
                {e.learned && (
                  <div style={{ background: C.bg, borderRadius: 14, padding: "12px 15px" }}>
                    <div className="lt-h" style={{ fontSize: 11.5, fontWeight: 800, color: C.sub, textTransform: "uppercase", letterSpacing: 1, marginBottom: 5 }}>What I learned</div>
                    <div style={{ fontSize: 13.5, lineHeight: 1.5 }}>{e.learned}</div>
                  </div>
                )}
                <div style={{ background: C.soft, borderRadius: 14, padding: "12px 15px" }}>
                  <div className="lt-h" style={{ fontSize: 11.5, fontWeight: 800, color: C.primaryDark, textTransform: "uppercase", letterSpacing: 1, marginBottom: 5 }}>Why it mattered for Berkeley</div>
                  <div style={{ fontSize: 13.5, lineHeight: 1.5 }}>{e.why}</div>
                </div>
              </div>
              {e.note && (
                <div style={{ background: C.softPurple, borderRadius: 14, padding: "11px 15px", fontSize: 13, color: "#6E44A0", display: "flex", gap: 8, alignItems: "flex-start" }}>
                  <Sparkles size={15} style={{ flexShrink: 0, marginTop: 2 }} /> <span><b>UCLA / UCSD:</b> {e.note}</span>
                </div>
              )}
              <div style={{ marginTop: 14, display: "flex", gap: 10, flexWrap: "wrap", alignItems: "center" }}>
                {e.alts && e.alts.length > 0 && (
                  <GhostBtn onClick={() => setOpenAlt(openAlt === i ? null : i)}>
                    See Alternatives <ChevronDown size={15} style={{ transform: openAlt === i ? "rotate(180deg)" : "none", transition: "transform .2s" }} />
                  </GhostBtn>
                )}
                <GhostBtn onClick={() => talkTo(m.id, e.t)}><MessageCircle size={15} /> Talk to Me About This</GhostBtn>
                <GhostBtn onClick={() => addToRoadmap(m, e)} style={{ color: C.green, borderColor: "#CBE8D4" }}><Plus size={15} /> Add to My Roadmap</GhostBtn>
              </div>
              {openAlt === i && (
                <div className="lt-fadeup" style={{ marginTop: 12, border: `1.5px dashed ${C.line}`, borderRadius: 14, padding: "13px 16px" }}>
                  <div className="lt-h" style={{ fontSize: 12, fontWeight: 800, color: C.sub, textTransform: "uppercase", letterSpacing: 1, marginBottom: 8 }}>Similar experiences that work just as well</div>
                  {e.alts.map((a, j) => (
                    <div key={j} style={{ fontSize: 13.5, display: "flex", gap: 8, alignItems: "center", padding: "4px 0" }}>
                      <ArrowRight size={13} color={C.accent} /> {a}
                    </div>
                  ))}
                </div>
              )}
            </Card>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ================= SCHEDULING ================= */
const DAY_NAMES = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
const SLOT_TIMES = ["9:00 AM", "10:00 AM", "11:00 AM", "1:00 PM", "2:00 PM", "3:00 PM", "4:00 PM", "5:00 PM", "6:00 PM", "7:00 PM"];

const CALL_OPTIONS = [
  { mins: 30, price: 40, mentorGets: 30 },
  { mins: 60, price: 70, mentorGets: 50 },
];

// Demo mentors' weekly availability: weekday index -> times
const DEMO_AVAIL = {
  m1: { 1: ["4:00 PM", "5:00 PM"], 3: ["4:00 PM", "5:00 PM", "6:00 PM"], 6: ["10:00 AM", "11:00 AM"] },
  m2: { 2: ["6:00 PM", "7:00 PM"], 4: ["6:00 PM", "7:00 PM"], 0: ["1:00 PM", "2:00 PM"] },
  m3: { 1: ["7:00 PM"], 2: ["7:00 PM"], 6: ["9:00 AM", "10:00 AM", "11:00 AM"] },
  m4: { 3: ["5:00 PM", "6:00 PM"], 5: ["3:00 PM", "4:00 PM", "5:00 PM"] },
  m5: { 2: ["4:00 PM", "5:00 PM"], 6: ["11:00 AM", "1:00 PM"] },
  m6: { 1: ["6:00 PM"], 4: ["5:00 PM", "6:00 PM"], 0: ["2:00 PM", "3:00 PM"] },
  m7: { 3: ["7:00 PM"], 5: ["4:00 PM", "5:00 PM"], 6: ["10:00 AM"] },
  m8: { 2: ["5:00 PM", "6:00 PM"], 4: ["7:00 PM"], 0: ["11:00 AM", "1:00 PM"] },
  m9: { 1: ["9:00 AM"], 3: ["9:00 AM", "10:00 AM"], 5: ["6:00 PM", "7:00 PM"] },
  m10: { 2: ["3:00 PM", "4:00 PM"], 6: ["1:00 PM", "2:00 PM", "3:00 PM"] },
};

const availOf = (mentor) => (mentor.avail && Object.keys(mentor.avail).length ? mentor.avail : DEMO_AVAIL[mentor.id]) || {};

// Real dates over the next 3 weeks that match a mentor's weekly availability
function upcomingSlots(avail) {
  const out = [];
  const now = new Date();
  for (let d = 1; d <= 21; d++) {
    const date = new Date(now);
    date.setDate(now.getDate() + d);
    const times = (avail || {})[date.getDay()] || [];
    if (times.length) {
      out.push({
        key: date.toISOString().slice(0, 10),
        label: `${DAY_NAMES[date.getDay()]} ${date.getMonth() + 1}/${date.getDate()}`,
        times,
      });
    }
  }
  return out;
}

const STATUS_COLORS = {
  Requested: { bg: C.soft, color: C.primaryDark },
  Confirmed: { bg: "#E4F5EA", color: C.green },
  Declined: { bg: "#F3EDE7", color: C.sub },
};

function BookingModal({ mentor, onClose, onConfirm }) {
  const [mins, setMins] = useState(30);
  const [pick, setPick] = useState(null);
  const days = upcomingSlots(availOf(mentor));
  const opt = CALL_OPTIONS.find((o) => o.mins === mins);
  const first = mentor.name.split(" ")[0];

  return (
    <Modal title={`Book a call with ${first}`} onClose={onClose}>
      <div style={{ display: "flex", gap: 10, marginBottom: 20 }}>
        {CALL_OPTIONS.map((o) => (
          <button
            key={o.mins}
            className="lt-btn lt-h"
            onClick={() => setMins(o.mins)}
            style={{
              flex: 1, borderRadius: 16, padding: "14px 14px", cursor: "pointer", textAlign: "left",
              border: `2px solid ${mins === o.mins ? C.accent : C.line}`,
              background: mins === o.mins ? C.softPurple : "#fff",
            }}
          >
            <div style={{ fontWeight: 800, fontSize: 15 }}>{o.mins} minutes</div>
            <div style={{ fontSize: 20, fontWeight: 800, color: C.primaryDark, margin: "3px 0" }}>${o.price}</div>
            <div style={{ fontSize: 11.5, color: C.sub }}>{o.mins === 30 ? "Quick questions" : "Deep dive"}</div>
          </button>
        ))}
      </div>

      <div className="lt-h" style={{ fontSize: 13.5, fontWeight: 700, marginBottom: 9 }}>Pick a time</div>
      {days.length === 0 ? (
        <div style={{ border: `1.5px dashed ${C.line}`, borderRadius: 14, padding: 22, textAlign: "center", color: C.sub, fontSize: 13.5, marginBottom: 16 }}>
          {first} hasn't posted availability yet — send a message to ask about times.
        </div>
      ) : (
        <div className="lt-scroll" style={{ maxHeight: 260, overflowY: "auto", marginBottom: 16, paddingRight: 4 }}>
          {days.map((d) => (
            <div key={d.key} style={{ marginBottom: 13 }}>
              <div className="lt-h" style={{ fontSize: 11.5, fontWeight: 800, color: C.sub, textTransform: "uppercase", letterSpacing: 1, marginBottom: 7 }}>{d.label}</div>
              <div style={{ display: "flex", flexWrap: "wrap", gap: 7 }}>
                {d.times.map((t) => {
                  const active = pick && pick.key === d.key && pick.time === t;
                  return (
                    <button
                      key={t}
                      className="lt-btn lt-h"
                      onClick={() => setPick({ key: d.key, label: d.label, time: t })}
                      style={{
                        border: `1.5px solid ${active ? "transparent" : C.line}`,
                        background: active ? GRAD : "#fff", color: active ? "#fff" : C.ink,
                        borderRadius: 999, padding: "8px 15px", fontSize: 13, fontWeight: 700, cursor: "pointer",
                      }}
                    >
                      {t}
                    </button>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
      )}

      <div style={{ background: C.bg, borderRadius: 14, padding: "12px 15px", fontSize: 13, color: C.sub, marginBottom: 14, lineHeight: 1.55 }}>
        {pick
          ? <><b style={{ color: C.ink }}>{mins} min · {pick.label} at {pick.time} · ${opt.price}</b><br />{first} confirms before you're charged. Booking unlocks unlimited messaging for 30 days.</>
          : "Select a time above to continue."}
      </div>

      <PrimaryBtn big style={{ width: "100%", justifyContent: "center", opacity: pick ? 1 : 0.5 }} onClick={() => pick && onConfirm({ mentorId: mentor.id, mentorName: mentor.name, mins, price: opt.price, day: pick.label, time: pick.time, status: "Requested" })}>
        <Calendar size={17} /> Request Call · ${opt ? opt.price : ""}
      </PrimaryBtn>
    </Modal>
  );
}

function MentorSchedule({ mentor, avail, setAvail, bookings, setStatus, onMessage }) {
  const mobile = useIsMobile();
  const requests = bookings.filter((b) => b.status === "Requested");
  const confirmed = bookings.filter((b) => b.status === "Confirmed");
  const payFor = (mins) => (CALL_OPTIONS.find((o) => o.mins === mins) || { mentorGets: 0 }).mentorGets;
  const earnings = confirmed.reduce((sum, b) => sum + payFor(b.mins), 0);

  const toggle = (day, time) => {
    const times = avail[day] || [];
    const next = { ...avail, [day]: times.includes(time) ? times.filter((t) => t !== time) : [...times, time] };
    if (next[day].length === 0) delete next[day];
    setAvail(next);
  };

  const slotCount = Object.values(avail).reduce((n, arr) => n + arr.length, 0);

  return (
    <div className="lt-fadeup">
      <h1 className="lt-h" style={{ fontSize: "clamp(24px, 5.5vw, 30px)", fontWeight: 800, margin: "0 0 4px" }}>Schedule</h1>
      <p style={{ color: C.sub, fontSize: 14, margin: "0 0 22px" }}>
        Set the hours you're free, then approve student requests. You earn $30 per 30-min call and $50 per hour.
      </p>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(min(100%, 180px), 1fr))", gap: 16, marginBottom: 22 }}>
        {[
          { label: "Open slots", val: slotCount, icon: Clock, c: C.accent },
          { label: "Pending requests", val: requests.length, icon: Calendar, c: C.primary },
          { label: "Confirmed calls", val: confirmed.length, icon: CheckCircle2, c: C.green },
          { label: "Earnings", val: `$${earnings}`, icon: TrendingUp, c: "#2774AE" },
        ].map((s) => (
          <Card key={s.label} style={{ padding: "16px 18px" }}>
            <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 7, color: s.c }}>
              <s.icon size={16} /><span className="lt-h" style={{ fontSize: 11.5, fontWeight: 800, textTransform: "uppercase", letterSpacing: 0.8, color: C.sub }}>{s.label}</span>
            </div>
            <div className="lt-h" style={{ fontSize: 26, fontWeight: 800 }}>{s.val}</div>
          </Card>
        ))}
      </div>

      <Card style={{ padding: mobile ? 18 : 24, marginBottom: 20 }}>
        <h2 className="lt-h" style={{ fontSize: 18, fontWeight: 800, margin: "0 0 4px" }}>Your weekly availability</h2>
        <p style={{ fontSize: 12.5, color: C.sub, margin: "0 0 16px" }}>Tap the times you're usually free. Students only see these slots.</p>
        <div className="lt-scroll" style={{ overflowX: "auto" }}>
          <div style={{ minWidth: 620 }}>
            {DAY_NAMES.map((dn, day) => (
              <div key={dn} style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 8 }}>
                <div className="lt-h" style={{ width: 42, fontSize: 12.5, fontWeight: 800, color: C.sub, flexShrink: 0 }}>{dn}</div>
                <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
                  {SLOT_TIMES.map((t) => {
                    const on = (avail[day] || []).includes(t);
                    return (
                      <button
                        key={t}
                        className="lt-btn lt-h"
                        onClick={() => toggle(day, t)}
                        style={{
                          border: `1.5px solid ${on ? "transparent" : C.line}`,
                          background: on ? GRAD : "#fff", color: on ? "#fff" : C.sub,
                          borderRadius: 10, padding: "6px 10px", fontSize: 11.5, fontWeight: 700, cursor: "pointer",
                        }}
                      >
                        {t.replace(":00", "")}
                      </button>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
        </div>
      </Card>

      <Card style={{ padding: mobile ? 18 : 24 }}>
        <h2 className="lt-h" style={{ fontSize: 18, fontWeight: 800, margin: "0 0 16px" }}>Call requests</h2>
        {bookings.length === 0 && (
          <div style={{ border: `1.5px dashed ${C.line}`, borderRadius: 16, padding: 24, textAlign: "center", color: C.sub, fontSize: 13.5 }}>
            No requests yet. Students book calls from your journey page once they've used their free questions.
          </div>
        )}
        {bookings.map((b, i) => {
          const st = STATUS_COLORS[b.status] || STATUS_COLORS.Requested;
          return (
            <div key={b.id} style={{ display: "flex", gap: 12, alignItems: "center", flexWrap: "wrap", padding: "14px 0", borderTop: i ? `1px solid ${C.line}` : "none" }}>
              <div style={{ flex: 1, minWidth: 190 }}>
                <div className="lt-h" style={{ fontWeight: 800, fontSize: 14.5 }}>{b.studentName || "Student"}</div>
                <div style={{ fontSize: 12.5, color: C.sub, marginTop: 3 }}>
                  {b.mins} min · {b.day} at {b.time} · you earn ${payFor(b.mins)}
                </div>
              </div>
              <span className="lt-h" style={{ background: st.bg, color: st.color, borderRadius: 999, padding: "5px 12px", fontSize: 11.5, fontWeight: 800 }}>{b.status}</span>
              {b.status === "Requested" && (
                <div style={{ display: "flex", gap: 7 }}>
                  <button className="lt-btn lt-h" onClick={() => setStatus(b.id, "Confirmed")} style={{ background: GRAD, color: "#fff", border: "none", borderRadius: 12, padding: "8px 15px", fontSize: 12.5, fontWeight: 700, cursor: "pointer" }}>Accept</button>
                  <button className="lt-btn lt-h" onClick={() => setStatus(b.id, "Declined")} style={{ background: "#fff", color: C.sub, border: `1.5px solid ${C.line}`, borderRadius: 12, padding: "8px 15px", fontSize: 12.5, fontWeight: 700, cursor: "pointer" }}>Decline</button>
                </div>
              )}
              {b.studentId && (
                <button className="lt-btn" onClick={() => onMessage(b.studentId)} aria-label="Message student" style={{ background: "#fff", border: `1.5px solid ${C.line}`, borderRadius: 12, padding: 8, color: C.accent, display: "flex", cursor: "pointer" }}>
                  <MessageCircle size={15} />
                </button>
              )}
            </div>
          );
        })}
      </Card>
    </div>
  );
}

/* ================= MESSAGES ================= */
function Messages({ contacts, chats, activeChat, setActiveChat, draft, setDraft, sendMessage, typing, toast, emptyText, onBook, bookings, isMentorView }) {
  const endRef = useRef(null);
  const [booking, setBooking] = useState(null);
  const mobile = useIsMobile();
  const [showChat, setShowChat] = useState(() => Boolean(draft));
  const m = contacts.find((x) => x.id === activeChat) || contacts[0];
  const msgs = chats[activeChat] || [];
  const booked = !isMentorView && (bookings || []).some((b) => b.mentorId === activeChat && b.status !== "Declined");
  const sentCount = msgs.filter((x) => x.from === "me").length;
  const left = Math.max(0, FREE_MESSAGES - sentCount);
  const locked = !isMentorView && !booked && left === 0;

  useEffect(() => {
    if (endRef.current) endRef.current.scrollIntoView({ behavior: "smooth" });
  }, [msgs.length, typing]);

  return (
    <div className="lt-fadeup" style={{ display: "flex", gap: 0, height: mobile ? "calc(100dvh - 178px)" : "calc(100vh - 96px)", background: "#fff", borderRadius: mobile ? 18 : 24, border: `1px solid ${C.line}`, boxShadow: SHADOW_SM, overflow: "hidden" }}>
      <div className="lt-scroll" style={{ display: mobile && showChat ? "none" : "block", width: mobile ? "100%" : 300, borderRight: mobile ? "none" : `1px solid ${C.line}`, overflowY: "auto", flexShrink: 0 }}>
        <div className="lt-h" style={{ padding: "20px 20px 12px", fontWeight: 800, fontSize: 18 }}>Messages</div>
        {contacts.map((mm) => {
          const last = (chats[mm.id] || [])[(chats[mm.id] || []).length - 1];
          const active = activeChat === mm.id;
          return (
            <button
              key={mm.id}
              className="lt-btn"
              onClick={() => { setActiveChat(mm.id); if (mobile) setShowChat(true); }}
              style={{
                display: "flex", gap: 11, alignItems: "center", width: "100%", textAlign: "left",
                padding: "13px 18px", border: "none", background: active ? C.soft : "transparent",
                borderLeft: active ? `4px solid ${C.primary}` : "4px solid transparent", cursor: "pointer",
              }}
            >
              <Avatar m={mm} size={44} />
              <div style={{ overflow: "hidden", flex: 1 }}>
                <div style={{ display: "flex", gap: 7, alignItems: "center" }}>
                  <span className="lt-h" style={{ fontWeight: 700, fontSize: 14 }}>{mm.name}</span>
                  <SchoolBadge school={mm.school} year={mm.year} small />
                  {mm.demo && <DemoBadge />}
                </div>
                <div style={{ fontSize: 12, color: C.sub, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis", marginTop: 3 }}>
                  {last ? last.text : "Start the conversation"}
                </div>
              </div>
            </button>
          );
        })}
      </div>

      <div style={{ flex: 1, display: mobile && !showChat ? "none" : "flex", flexDirection: "column", minWidth: 0 }}>
        <div style={{ display: "flex", alignItems: "center", gap: mobile ? 9 : 12, padding: mobile ? "11px 12px" : "14px 20px", borderBottom: `1px solid ${C.line}`, background: C.bg }}>
          {mobile && (
            <button className="lt-btn" onClick={() => setShowChat(false)} aria-label="Back to conversations" style={{ background: "#fff", border: `1.5px solid ${C.line}`, borderRadius: 12, padding: 7, display: "flex", color: C.sub, cursor: "pointer", flexShrink: 0 }}>
              <ChevronRight size={16} style={{ transform: "rotate(180deg)" }} />
            </button>
          )}
          <Avatar m={m} size={mobile ? 38 : 44} ring />
          <div style={{ flex: 1 }}>
            <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
              <span className="lt-h" style={{ fontWeight: 800, fontSize: 15.5 }}>{m.name}</span>
              <SchoolBadge school={m.school} year={m.year} small />
              {m.demo && <DemoBadge />}
              {booked && (
                <span className="lt-h" style={{ background: C.softPurple, color: C.accent, borderRadius: 999, padding: "3px 10px", fontSize: 10.5, fontWeight: 800, letterSpacing: 0.5 }}>UNLIMITED · 30d</span>
              )}
            </div>
            {m.demo ? (
              <div style={{ fontSize: 12, color: C.sub, display: "flex", alignItems: "center", gap: 5, marginTop: 2 }}>
                <span style={{ width: 8, height: 8, borderRadius: 8, background: "#D8C7B8", display: "inline-block" }} /> Demo profile — won't respond
              </div>
            ) : (
              <div style={{ fontSize: 12, color: C.green, display: "flex", alignItems: "center", gap: 5, marginTop: 2 }}>
                <span style={{ width: 8, height: 8, borderRadius: 8, background: C.green, display: "inline-block" }} /> {(m.replies || []).length ? "Online now" : "Replies when they check in"}
              </div>
            )}
          </div>
          {!isMentorView && (
            <GhostBtn onClick={() => setBooking(m)}>
              <Calendar size={15} /> {mobile ? "Call" : "Schedule Call"}
            </GhostBtn>
          )}
        </div>

        <div className="lt-scroll" style={{ flex: 1, overflowY: "auto", padding: "22px 24px", display: "flex", flexDirection: "column", gap: 12, background: C.bg }}>
          {msgs.length === 0 && (
            <div style={{ textAlign: "center", color: C.sub, fontSize: 13.5, margin: "auto", maxWidth: 320 }}>
              <MessageCircle size={30} style={{ margin: "0 auto 10px", display: "block", color: C.primary }} />
              {emptyText(m)}
            </div>
          )}
          {msgs.map((msg, i) => (
            <div key={i} style={{ display: "flex", justifyContent: msg.from === "me" ? "flex-end" : "flex-start" }}>
              <div style={{ maxWidth: "72%" }}>
                <div
                  style={{
                    background: msg.from === "me" ? GRAD : "#fff",
                    color: msg.from === "me" ? "#fff" : C.ink,
                    borderRadius: msg.from === "me" ? "18px 18px 6px 18px" : "18px 18px 18px 6px",
                    padding: "11px 15px", fontSize: 14, lineHeight: 1.55,
                    boxShadow: SHADOW_SM, border: msg.from === "me" ? "none" : `1px solid ${C.line}`,
                  }}
                >
                  {msg.text}
                </div>
                <div style={{ fontSize: 10.5, color: C.sub, marginTop: 4, textAlign: msg.from === "me" ? "right" : "left" }}>{msg.time}</div>
              </div>
            </div>
          ))}
          {typing === activeChat && (
            <div style={{ display: "flex" }}>
              <div style={{ background: "#fff", border: `1px solid ${C.line}`, borderRadius: "18px 18px 18px 6px", padding: "13px 16px", display: "flex", gap: 5 }}>
                {[0, 1, 2].map((d) => (
                  <span key={d} style={{ width: 7, height: 7, borderRadius: 7, background: C.sub, display: "inline-block", animation: `ltDot 1.1s ${d * 0.15}s infinite` }} />
                ))}
              </div>
            </div>
          )}
          <div ref={endRef} />
        </div>

        {m.demo && (
          <div style={{ padding: "9px 16px", background: "#FBF5EE", borderTop: `1px solid ${C.line}`, fontSize: 12, color: "#A08B7A", textAlign: "center" }}>
            {m.name.split(" ")[0]} is a sample profile — your messages will be saved here, but no reply will come.
          </div>
        )}
        {locked ? (
          <div style={{ borderTop: `1px solid ${C.line}`, background: "#fff", padding: mobile ? "14px 12px" : "18px 20px" }}>
            <div style={{ background: `linear-gradient(135deg, ${C.soft}, ${C.softPurple})`, border: `1.5px solid ${C.line}`, borderRadius: 18, padding: mobile ? 16 : 20, textAlign: "center" }}>
              <div className="lt-h" style={{ fontWeight: 800, fontSize: 15.5, marginBottom: 5 }}>Ready to go deeper with {m.name.split(" ")[0]}?</div>
              <p style={{ fontSize: 13, color: C.sub, lineHeight: 1.55, margin: "0 0 14px" }}>
                You've used your {FREE_MESSAGES} free questions. Book a call to talk it through properly — and unlock unlimited messaging for 30 days.
              </p>
              <PrimaryBtn onClick={() => setBooking(m)}><Calendar size={16} /> See {m.name.split(" ")[0]}'s availability</PrimaryBtn>
              <div style={{ fontSize: 11.5, color: C.sub, marginTop: 11 }}>30 min · $40 &nbsp;·&nbsp; 60 min · $70 &nbsp;·&nbsp; unlimited messaging for 30 days</div>
            </div>
          </div>
        ) : (
          <>
            {!isMentorView && !booked && (
              <div style={{ padding: "7px 16px", borderTop: `1px solid ${C.line}`, background: "#FFFDFB", fontSize: 11.5, color: left === 1 ? C.primaryDark : C.sub, textAlign: "center", fontWeight: left === 1 ? 700 : 400 }}>
                {left} free question{left === 1 ? "" : "s"} left with {m.name.split(" ")[0]} · book a call for unlimited
              </div>
            )}
            <div style={{ display: "flex", gap: 10, padding: 16, borderTop: `1px solid ${C.line}`, background: "#fff" }}>
              <textarea
                value={draft}
                onChange={(e) => setDraft(e.target.value)}
                onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendMessage(); } }}
                placeholder={`Message ${m.name.split(" ")[0]}…`}
                rows={draft.length > 90 ? 3 : 1}
                style={{ ...inputStyle, resize: "none", borderRadius: 16, flex: 1 }}
              />
              <PrimaryBtn onClick={sendMessage} style={{ borderRadius: 16, padding: "11px 18px" }} aria-label="Send">
                <Send size={17} />
              </PrimaryBtn>
            </div>
          </>
        )}
      </div>

      {booking && (
        <BookingModal
          mentor={booking}
          onClose={() => setBooking(null)}
          onConfirm={(b) => { setBooking(null); onBook(b); }}
        />
      )}
    </div>
  );
}

/* ================= ROADMAP ================= */
const STATUSES = ["Not Started", "In Progress", "Complete"];
const STATUS_STYLE = {
  "Not Started": { bg: "#F3EDE7", color: C.sub, icon: Circle },
  "In Progress": { bg: C.soft, color: C.primaryDark, icon: Clock },
  "Complete": { bg: "#E4F5EA", color: C.green, icon: CheckCircle2 },
};

function Modal({ title, onClose, children, wide }) {
  // Open the card just below wherever the user currently is, let it grow to
  // its full height, and let the normal page scrollbar handle any overflow.
  const [topOffset] = useState(() => (typeof window !== "undefined" ? window.scrollY + 28 : 28));
  return (
    <div style={{ position: "absolute", inset: 0, background: "rgba(51,36,27,.35)", zIndex: 60, padding: "0 20px" }} onClick={onClose}>
      <div className="lt-pop" onClick={(e) => e.stopPropagation()} style={{ background: "#fff", borderRadius: 26, boxShadow: SHADOW, width: "100%", maxWidth: wide ? 720 : 520, margin: `${topOffset}px auto 48px`, padding: 28 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 18 }}>
          <h2 className="lt-h" style={{ fontSize: 20, fontWeight: 800, margin: 0 }}>{title}</h2>
          <button className="lt-btn" onClick={onClose} style={{ background: C.bg, border: "none", borderRadius: 12, padding: 8, display: "flex", cursor: "pointer" }} aria-label="Close"><X size={17} /></button>
        </div>
        {children}
      </div>
    </div>
  );
}

function AddFromJourneyModal({ mentors, onAdd, onClose, existing }) {
  const sorted = [...mentors.filter((m) => m.exp.length > 0)].sort((a, b) =>
    (a.demo ? 1 : 0) - (b.demo ? 1 : 0) || (a.school === "berkeley" ? -1 : 1) - (b.school === "berkeley" ? -1 : 1)
  );
  const [open, setOpen] = useState(sorted.length ? sorted[0].id : null);
  return (
    <Modal title="Add from a Mentor Journey" onClose={onClose} wide>
      <p style={{ fontSize: 13.5, color: C.sub, marginTop: -8, marginBottom: 16 }}>Berkeley mentors first — every experience notes its UCLA/UCSD applicability.</p>
      {sorted.map((m) => (
        <div key={m.id} style={{ border: `1.5px solid ${C.line}`, borderRadius: 18, marginBottom: 12, overflow: "hidden" }}>
          <button className="lt-btn" onClick={() => setOpen(open === m.id ? null : m.id)} style={{ display: "flex", alignItems: "center", gap: 12, width: "100%", padding: 14, background: open === m.id ? C.bg : "#fff", border: "none", textAlign: "left", cursor: "pointer" }}>
            <Avatar m={m} size={40} />
            <div style={{ flex: 1 }}>
              <span className="lt-h" style={{ fontWeight: 700, fontSize: 14.5 }}>{m.name}</span>
              <span style={{ marginLeft: 8 }}><SchoolBadge school={m.school} year={m.year} small /></span>
            </div>
            <ChevronDown size={17} color={C.sub} style={{ transform: open === m.id ? "rotate(180deg)" : "none", transition: "transform .2s" }} />
          </button>
          {open === m.id && m.exp.map((e, i) => {
            const added = existing.some((x) => x.title === e.t);
            return (
              <div key={i} style={{ display: "flex", gap: 12, padding: "12px 16px", borderTop: `1px solid ${C.line}`, alignItems: "flex-start" }}>
                <div style={{ flex: 1 }}>
                  <div className="lt-h" style={{ fontWeight: 700, fontSize: 13.5 }}>{e.t}</div>
                  <div style={{ fontSize: 12.5, color: C.sub, marginTop: 3 }}>{e.why}</div>
                </div>
                <button
                  className="lt-btn"
                  disabled={added}
                  onClick={() => onAdd(m, e)}
                  style={{
                    border: "none", borderRadius: 12, padding: 9, display: "flex", cursor: added ? "default" : "pointer",
                    background: added ? "#E4F5EA" : C.primary, color: added ? C.green : "#fff", flexShrink: 0,
                  }}
                  aria-label={added ? "Added" : `Add ${e.t}`}
                >
                  {added ? <CheckCircle2 size={17} /> : <Plus size={17} />}
                </button>
              </div>
            );
          })}
        </div>
      ))}
    </Modal>
  );
}

function AddCustomModal({ onAdd, onClose }) {
  const [f, setF] = useState({ title: "", desc: "", date: "", category: "Computer Science", notes: "" });
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  return (
    <Modal title="Add Custom Milestone" onClose={onClose}>
      <p style={{ fontSize: 13, color: C.sub, marginTop: -8, marginBottom: 16 }}>
        Make it a real experience, not a checkbox — "President of Environmental Science Club: grew membership 8 → 45, started school garden, won $2K grant" beats "get leadership role."
      </p>
      <Field label="Title"><input style={inputStyle} value={f.title} onChange={set("title")} placeholder="COSMOS Cluster 5 Application (due Feb 1)" /></Field>
      <Field label="Description"><textarea style={{ ...inputStyle, minHeight: 84, resize: "vertical" }} value={f.desc} onChange={set("desc")} placeholder="What you'll actually do, and the impact you're aiming for…" /></Field>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
        <Field label="Target date"><input type="date" style={inputStyle} value={f.date} onChange={set("date")} /></Field>
        <Field label="Category">
          <select style={inputStyle} value={f.category} onChange={set("category")}>
            {CATS.slice(1).map((c) => <option key={c}>{c}</option>)}
          </select>
        </Field>
      </div>
      <Field label="Notes"><input style={inputStyle} value={f.notes} onChange={set("notes")} placeholder="Why Berkeley (and UCLA/UCSD) will care about this" /></Field>
      <PrimaryBtn big style={{ width: "100%", justifyContent: "center" }} onClick={() => f.title.trim() && onAdd(f)}>
        <Plus size={17} /> Add to Roadmap
      </PrimaryBtn>
    </Modal>
  );
}

function Roadmap({ mentors, milestones, setMilestones, goExplore, addMilestone, talkTo, toast }) {
  const [showJourney, setShowJourney] = useState(false);
  const [showCustom, setShowCustom] = useState(false);
  const dragIdx = useRef(null);

  const cycle = (id) => {
    setMilestones(milestones.map((ms) => {
      if (ms.id !== id) return ms;
      const next = STATUSES[(STATUSES.indexOf(ms.status) + 1) % 3];
      if (next === "Complete") toast(`Milestone complete: ${ms.title} 🎉`, <CheckCircle2 size={16} color={C.green} />);
      api.updateMilestoneStatus(ms.id, next).catch(() => {});
      return { ...ms, status: next };
    }));
  };
  const remove = (id) => {
    setMilestones(milestones.filter((ms) => ms.id !== id));
    api.deleteMilestone(id).catch(() => {});
  };
  const onDrop = (i) => {
    const from = dragIdx.current;
    if (from === null || from === i) return;
    const arr = [...milestones];
    const [item] = arr.splice(from, 1);
    arr.splice(i, 0, item);
    setMilestones(arr);
    api.saveMilestoneOrder(arr.map((m, idx) => ({ id: m.id, position: idx }))).catch(() => {});
    dragIdx.current = null;
  };

  if (milestones.length === 0) {
    return (
      <div className="lt-fadeup" style={{ textAlign: "center", paddingTop: 70, maxWidth: 520, margin: "0 auto" }}>
        <div style={{ width: 96, height: 96, borderRadius: 30, background: `linear-gradient(135deg, ${C.primary}, ${C.accent})`, display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 24px", color: "#fff", boxShadow: "0 14px 34px rgba(244,137,71,.35)" }}>
          <Map size={44} />
        </div>
        <h1 className="lt-h" style={{ fontSize: 30, fontWeight: 800, margin: "0 0 10px" }}>Start building your Berkeley roadmap</h1>
        <p style={{ color: C.sub, fontSize: 15, lineHeight: 1.6, marginBottom: 26 }}>
          These experiences also set you up strong for UCLA and UCSD. Borrow steps from real mentor journeys, or add your own.
        </p>
        <div style={{ display: "flex", gap: 12, justifyContent: "center", flexWrap: "wrap" }}>
          <PrimaryBtn big onClick={goExplore}><BookOpen size={18} /> Browse Mentor Journeys to Get Ideas</PrimaryBtn>
          <GhostBtn onClick={() => setShowCustom(true)} style={{ padding: "15px 26px", fontSize: 15 }}><Plus size={17} /> Add Custom Milestone</GhostBtn>
        </div>
        {showCustom && <AddCustomModal onClose={() => setShowCustom(false)} onAdd={(f) => { addMilestone({ title: f.title, desc: f.desc, date: f.date, category: f.category, tag: f.notes || "Strong for Berkeley, UCLA & UCSD" }); setShowCustom(false); }} />}
      </div>
    );
  }

  const done = milestones.filter((m) => m.status === "Complete").length;

  return (
    <div className="lt-fadeup">
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", flexWrap: "wrap", gap: 14, marginBottom: 8 }}>
        <div>
          <h1 className="lt-h" style={{ fontSize: 30, fontWeight: 800, margin: 0 }}>My <span className="lt-grad-text">Berkeley</span> Roadmap</h1>
          <p style={{ color: C.sub, fontSize: 14, margin: "5px 0 0" }}>{done} of {milestones.length} complete · every step also strengthens UCLA & UCSD apps · drag to reorder</p>
        </div>
        <div style={{ display: "flex", gap: 10 }}>
          <GhostBtn onClick={() => setShowJourney(true)}><BookOpen size={15} /> Add from Journey</GhostBtn>
          <PrimaryBtn onClick={() => setShowCustom(true)}><Plus size={16} /> Add Custom Milestone</PrimaryBtn>
        </div>
      </div>

      <div style={{ height: 10, background: "#F3EDE7", borderRadius: 99, margin: "14px 0 24px", overflow: "hidden" }}>
        <div style={{ height: "100%", width: `${milestones.length ? (done / milestones.length) * 100 : 0}%`, background: `linear-gradient(90deg, ${C.primary}, ${C.accent})`, borderRadius: 99, transition: "width .4s ease" }} />
      </div>

      {milestones.map((ms, i) => {
        const st = STATUS_STYLE[ms.status];
        const Icon = st.icon;
        return (
          <div
            key={ms.id}
            draggable
            onDragStart={() => (dragIdx.current = i)}
            onDragOver={(e) => e.preventDefault()}
            onDrop={() => onDrop(i)}
          >
            <Card style={{ padding: "18px 20px", marginBottom: 14, display: "flex", gap: 14, alignItems: "flex-start", cursor: "grab", flexWrap: "wrap" }}>
              <GripVertical size={18} color="#D8C7B8" style={{ marginTop: 4, flexShrink: 0 }} />
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ display: "flex", gap: 10, alignItems: "center", flexWrap: "wrap" }}>
                  <span className="lt-h" style={{ fontWeight: 800, fontSize: 16 }}>{ms.title}</span>
                  {ms.date && <span style={{ fontSize: 12, color: C.sub, display: "flex", alignItems: "center", gap: 4 }}><Calendar size={12} /> {ms.date}</span>}
                </div>
                {ms.desc && <p style={{ fontSize: 13.5, color: "#5A463A", lineHeight: 1.55, margin: "7px 0" }}>{ms.desc}</p>}
                <div style={{ display: "flex", gap: 8, flexWrap: "wrap", alignItems: "center", marginTop: 8 }}>
                  <span style={{ fontSize: 11.5, fontWeight: 700, color: C.primaryDark, background: C.soft, borderRadius: 999, padding: "4px 11px" }}>🐻 {ms.tag}</span>
                  {ms.category && <span style={{ fontSize: 11.5, fontWeight: 700, color: C.accent, background: C.softPurple, borderRadius: 999, padding: "4px 11px" }}>{ms.category}</span>}
                </div>
              </div>
              <div style={{ display: "flex", flexDirection: "column", gap: 8, alignItems: "flex-end", flexShrink: 0 }}>
                <button className="lt-btn lt-h" onClick={() => cycle(ms.id)} style={{ background: st.bg, color: st.color, border: "none", borderRadius: 999, padding: "7px 14px", fontSize: 12.5, fontWeight: 700, display: "flex", alignItems: "center", gap: 6, cursor: "pointer" }}>
                  <Icon size={14} /> {ms.status}
                </button>
                <div style={{ display: "flex", gap: 6 }}>
                  <button className="lt-btn" onClick={() => talkTo(ms.mentorId || "m1", ms.title)} style={{ background: "#fff", border: `1.5px solid ${C.line}`, borderRadius: 12, padding: "7px 11px", fontSize: 12, fontWeight: 700, color: C.primaryDark, display: "flex", alignItems: "center", gap: 5, cursor: "pointer" }}>
                    <MessageCircle size={13} /> Discuss with Mentor
                  </button>
                  <button className="lt-btn" onClick={() => remove(ms.id)} style={{ background: "#fff", border: `1.5px solid ${C.line}`, borderRadius: 12, padding: 7, color: C.sub, display: "flex", cursor: "pointer" }} aria-label="Remove milestone">
                    <X size={14} />
                  </button>
                </div>
              </div>
            </Card>
          </div>
        );
      })}

      {showJourney && <AddFromJourneyModal mentors={mentors} existing={milestones} onClose={() => setShowJourney(false)} onAdd={(m, e) => addMilestone({ title: e.t, desc: e.story, category: m.cats[0], tag: `From ${m.name.split(" ")[0]}'s ${SCHOOLS[m.school].short} path`, mentorId: m.id })} />}
      {showCustom && <AddCustomModal onClose={() => setShowCustom(false)} onAdd={(f) => { addMilestone({ title: f.title, desc: f.desc, date: f.date, category: f.category, tag: f.notes || "Strong for Berkeley, UCLA & UCSD" }); setShowCustom(false); }} />}
    </div>
  );
}

/* ================= DASHBOARD ================= */
function Dashboard({ student, milestones, messagedMentors, bookings, goRoadmap, openJourney }) {
  const done = milestones.filter((m) => m.status === "Complete").length;
  const inProg = milestones.filter((m) => m.status === "In Progress").length;
  const progress = milestones.length ? Math.round((done / milestones.length) * 100) : 0;
  const hours = done * 12 + inProg * 4;
  const ready = Math.min(100, 22 + milestones.length * 7 + done * 9 + messagedMentors.length * 6);

  if (milestones.length === 0) {
    return (
      <div className="lt-fadeup" style={{ textAlign: "center", paddingTop: 80, maxWidth: 460, margin: "0 auto" }}>
        <LayoutDashboard size={40} color={C.primary} style={{ margin: "0 auto 16px", display: "block" }} />
        <h1 className="lt-h" style={{ fontSize: 26, fontWeight: 800 }}>Your dashboard unlocks with your first milestone</h1>
        <p style={{ color: C.sub, fontSize: 14.5, marginBottom: 24 }}>Add one experience to your roadmap and we'll start tracking your Berkeley Ready score.</p>
        <PrimaryBtn big onClick={goRoadmap}><Map size={18} /> Build My Roadmap</PrimaryBtn>
      </div>
    );
  }

  const stats = [
    { label: "Milestones", val: milestones.length, icon: Target, c: C.primary },
    { label: "Mentors connected", val: messagedMentors.length, icon: Users, c: C.accent },
    { label: "Hours logged", val: hours, icon: Clock, c: "#2774AE" },
    { label: "Roadmap progress", val: `${progress}%`, icon: TrendingUp, c: C.green },
  ];

  const feed = [
    { icon: Zap, c: C.primary, text: "Berkeley M.E.T. application opens Aug 1 — Marcus applied early and says the supplement takes 3 weeks. Start in July.", time: "Today" },
    inProg > 0 ? { icon: Clock, c: "#2774AE", text: `You have ${inProg} milestone${inProg > 1 ? "s" : ""} in progress — Priya suggests logging weekly notes; they become PIQ material.`, time: "Today" } : null,
    { icon: MessageCircle, c: C.accent, text: "Priya Sharma replied about COSMOS timing — apps open in January, Cluster 5 fills fast.", time: "Yesterday" },
    student.target !== "berkeley" && student.target === "ucla" ? { icon: Sparkles, c: "#2774AE", text: "UCLA TAP program deadline approaching — Danielle's clinical-hours path maps to it directly.", time: "2d ago" } : { icon: Sparkles, c: "#182B49", text: "UCSD's Triton Research Experiences open for summer — similar to the lab work that got Priya into Berkeley.", time: "2d ago" },
    done > 0 ? { icon: CheckCircle2, c: C.green, text: `Milestone complete: "${milestones.find((m) => m.status === "Complete").title}" — added to your Berkeley Ready score.`, time: "3d ago" } : null,
  ].filter(Boolean);

  const recs = [
    { m: MENTORS[0], text: "Based on your CS interest and Berkeley target, Priya's COSMOS → independent research path is a blueprint. Her Feb deadline note applies to you this year." },
    { m: MENTORS[3], text: "UCSD's Triton research ecosystem mirrors what got Priya into Berkeley — Kevin can show you how one lab email opens both doors." },
    { m: MENTORS[1], text: "Your roadmap leans technical. Marcus recommends one impact-with-numbers experience — Berkeley's public mission rewards it, and so do UCLA & UCSD." },
  ];

  return (
    <div className="lt-fadeup">
      <h1 className="lt-h" style={{ fontSize: 30, fontWeight: 800, margin: "0 0 4px" }}>Welcome back, {student.name.split(" ")[0]} 👋</h1>
      <p style={{ color: C.sub, fontSize: 14.5, marginBottom: 22 }}>Target: {SCHOOLS[student.target].name} · Grade {student.grade}</p>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(170px, 1fr))", gap: 16, marginBottom: 20 }}>
        {stats.map((s) => (
          <Card key={s.label} style={{ padding: "18px 20px" }}>
            <div style={{ display: "flex", alignItems: "center", gap: 9, color: s.c, marginBottom: 8 }}>
              <s.icon size={17} /><span className="lt-h" style={{ fontSize: 12, fontWeight: 800, textTransform: "uppercase", letterSpacing: 0.8, color: C.sub }}>{s.label}</span>
            </div>
            <div className="lt-h" style={{ fontSize: 30, fontWeight: 800 }}>{s.val}</div>
          </Card>
        ))}
        <Card style={{ padding: "18px 20px", background: `linear-gradient(135deg, ${C.primary}, ${C.accent})`, border: "none", color: "#fff" }}>
          <div className="lt-h" style={{ fontSize: 12, fontWeight: 800, textTransform: "uppercase", letterSpacing: 0.8, opacity: 0.9, display: "flex", alignItems: "center", gap: 8, marginBottom: 8 }}>
            <Star size={16} fill="#fff" /> Berkeley Ready
          </div>
          <div className="lt-h" style={{ fontSize: 30, fontWeight: 800 }}>{ready}<span style={{ fontSize: 16, opacity: 0.85 }}>/100</span></div>
          <div style={{ fontSize: 11.5, opacity: 0.9, marginTop: 4 }}>Also tracks UCLA & UCSD readiness</div>
        </Card>
      </div>

      {(bookings || []).length > 0 && (
        <Card style={{ padding: 24, marginBottom: 20 }}>
          <h2 className="lt-h" style={{ fontSize: 17.5, fontWeight: 800, margin: "0 0 14px" }}>Your calls</h2>
          {bookings.map((b, i) => (
            <div key={b.id} style={{ display: "flex", gap: 12, alignItems: "center", flexWrap: "wrap", padding: "11px 0", borderTop: i ? `1px solid ${C.line}` : "none" }}>
              <span style={{ background: C.softPurple, color: C.accent, borderRadius: 12, padding: 9, display: "flex" }}><Calendar size={16} /></span>
              <div style={{ flex: 1, minWidth: 170 }}>
                <div className="lt-h" style={{ fontWeight: 800, fontSize: 14 }}>{b.mentorName}</div>
                <div style={{ fontSize: 12.5, color: C.sub, marginTop: 2 }}>{b.mins} min · {b.day} at {b.time} · ${b.price}</div>
              </div>
              <span className="lt-h" style={{ background: b.status === "Confirmed" ? "#E4F5EA" : b.status === "Declined" ? "#F3EDE7" : C.soft, color: b.status === "Confirmed" ? C.green : b.status === "Declined" ? C.sub : C.primaryDark, borderRadius: 999, padding: "5px 12px", fontSize: 11.5, fontWeight: 800 }}>{b.status}</span>
            </div>
          ))}
        </Card>
      )}

      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(min(100%, 340px), 1fr))", gap: 20 }}>
        <Card style={{ padding: 24 }}>
          <h2 className="lt-h" style={{ fontSize: 17.5, fontWeight: 800, margin: "0 0 16px" }}>Activity feed</h2>
          {feed.map((f, i) => (
            <div key={i} style={{ display: "flex", gap: 13, padding: "12px 0", borderTop: i ? `1px solid ${C.line}` : "none" }}>
              <span style={{ background: `${f.c}18`, color: f.c, borderRadius: 12, padding: 9, display: "flex", alignSelf: "flex-start", flexShrink: 0 }}><f.icon size={16} /></span>
              <div>
                <div style={{ fontSize: 13.5, lineHeight: 1.55 }}>{f.text}</div>
                <div style={{ fontSize: 11.5, color: C.sub, marginTop: 4 }}>{f.time}</div>
              </div>
            </div>
          ))}
        </Card>
        <Card style={{ padding: 24 }}>
          <h2 className="lt-h" style={{ fontSize: 17.5, fontWeight: 800, margin: "0 0 16px" }}>Recommended for you</h2>
          {recs.map((r, i) => (
            <button key={i} className="lt-btn" onClick={() => openJourney(r.m.id)} style={{ display: "flex", gap: 12, padding: "13px 0", borderTop: i ? `1px solid ${C.line}` : "none", background: "none", border: "none", borderTopStyle: i ? "solid" : "none", textAlign: "left", width: "100%", cursor: "pointer" }}>
              <Avatar m={r.m} size={40} />
              <div>
                <div style={{ fontSize: 13, lineHeight: 1.55 }}>{r.text}</div>
                <div className="lt-h" style={{ fontSize: 12.5, fontWeight: 700, color: C.primary, marginTop: 5, display: "flex", alignItems: "center", gap: 4 }}>View journey <ChevronRight size={13} /></div>
              </div>
            </button>
          ))}
        </Card>
      </div>
    </div>
  );
}

/* ================= RESPONSIVE HELPERS ================= */
function useIsMobile() {
  const [mobile, setMobile] = useState(() => typeof window !== "undefined" && window.innerWidth < 768);
  useEffect(() => {
    const onResize = () => setMobile(window.innerWidth < 768);
    window.addEventListener("resize", onResize);
    return () => window.removeEventListener("resize", onResize);
  }, []);
  return mobile;
}

function MobileHeader({ right }) {
  return (
    <div style={{ position: "sticky", top: 0, zIndex: 30, background: "#FFFDFB", borderBottom: `1px solid ${C.line}`, display: "flex", alignItems: "center", gap: 9, padding: "10px 14px" }}>
      <img src={LOGO_IMG} alt="LinkTeen logo" style={{ width: 34, height: 34, borderRadius: "50%", border: `1.5px solid ${C.line}` }} />
      <span className="lt-h" style={{ fontSize: 18, fontWeight: 800 }}>LinkTeen</span>
      <div style={{ marginLeft: "auto", display: "flex", gap: 8, alignItems: "center" }}>{right}</div>
    </div>
  );
}

function MobileAvatarButton({ student, onPhotoChange }) {
  const fileRef = useRef(null);
  return (
    <>
      <button
        className="lt-btn"
        onClick={() => fileRef.current && fileRef.current.click()}
        aria-label="Change profile photo"
        style={{ width: 36, height: 36, borderRadius: "50%", border: "none", padding: 0, overflow: "hidden", cursor: "pointer", background: `linear-gradient(135deg, ${C.accent}, ${C.primary})`, color: "#fff", fontWeight: 800, fontFamily: "'Outfit',sans-serif", fontSize: 13, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}
      >
        {student.photo
          ? <img src={student.photo} alt="Your profile" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
          : student.name.split(" ").map((w) => w[0]).join("").slice(0, 2)}
      </button>
      <input ref={fileRef} type="file" accept="image/*" style={{ display: "none" }} onChange={(e) => { const f = e.target.files && e.target.files[0]; if (f) onPhotoChange(URL.createObjectURL(f)); e.target.value = ""; }} />
    </>
  );
}

function MobileIconButton({ onClick, label, children }) {
  return (
    <button className="lt-btn" onClick={onClick} aria-label={label} style={{ background: "#fff", border: `1.5px solid ${C.line}`, borderRadius: 12, padding: 8, color: C.sub, display: "flex", cursor: "pointer" }}>
      {children}
    </button>
  );
}

function MobileTabBar({ items, page, nav }) {
  return (
    <nav style={{ position: "fixed", left: 0, right: 0, bottom: 0, zIndex: 30, background: "#fff", borderTop: `1px solid ${C.line}`, display: "flex", padding: "6px 4px calc(8px + env(safe-area-inset-bottom))" }}>
      {items.map((n) => {
        const active = page === n.id || (page === "journey" && n.id === "explore");
        return (
          <button key={n.id} className="lt-btn" onClick={() => nav(n.id)} style={{ flex: 1, background: "none", border: "none", display: "flex", flexDirection: "column", alignItems: "center", gap: 3, padding: "4px 2px", color: active ? C.primaryDark : C.sub, cursor: "pointer" }}>
            <span style={{ background: active ? C.soft : "transparent", borderRadius: 12, padding: "5px 13px", display: "flex" }}><n.icon size={20} /></span>
            <span className="lt-h" style={{ fontSize: 10.5, fontWeight: 700, whiteSpace: "nowrap" }}>{n.label}</span>
          </button>
        );
      })}
    </nav>
  );
}

/* ================= SIDEBAR ================= */

const NAV = [
  { id: "explore", label: "Explore", icon: Compass },
  { id: "roadmap", label: "My Roadmap", icon: Map },
  { id: "messages", label: "Messages", icon: MessageCircle },
  { id: "dashboard", label: "Dashboard", icon: LayoutDashboard },
];

function Sidebar({ page, nav, student, onPhotoChange, onSignOut }) {
  const fileRef = useRef(null);
  return (
    <aside style={{ width: 244, flexShrink: 0, position: "fixed", top: 0, bottom: 0, left: 0, background: "#fff", borderRight: `1px solid ${C.line}`, display: "flex", flexDirection: "column", padding: "26px 16px 20px", zIndex: 20 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "0 10px", marginBottom: 30 }}>
        <img src={LOGO_IMG} alt="LinkTeen logo" style={{ width: 42, height: 42, borderRadius: "50%", boxShadow: "0 6px 16px rgba(244,137,71,.3)", border: `1.5px solid ${C.line}` }} />
        <span className="lt-h" style={{ fontSize: 21, fontWeight: 800 }}>LinkTeen</span>
      </div>
      <nav style={{ display: "flex", flexDirection: "column", gap: 5 }}>
        {NAV.map((n) => {
          const active = page === n.id || (page === "journey" && n.id === "explore");
          return (
            <button
              key={n.id}
              className="lt-btn lt-h lt-nav"
              onClick={() => nav(n.id)}
              style={{
                display: "flex", alignItems: "center", gap: 12, padding: "12px 14px",
                borderRadius: 15, border: "none", cursor: "pointer", fontSize: 14.5, fontWeight: 700,
                background: active ? C.soft : "transparent", color: active ? C.primaryDark : C.sub,
              }}
            >
              <n.icon size={19} /> {n.label}
            </button>
          );
        })}
      </nav>
      <div style={{ marginTop: "auto" }}>
        <div style={{ background: C.bg, border: `1px solid ${C.line}`, borderRadius: 18, padding: 15, display: "flex", gap: 11, alignItems: "center" }}>
          <button
            className="lt-btn"
            onClick={() => fileRef.current && fileRef.current.click()}
            title="Change profile photo"
            aria-label="Change profile photo"
            style={{ position: "relative", width: 46, height: 46, borderRadius: "50%", border: "none", padding: 0, cursor: "pointer", flexShrink: 0, background: `linear-gradient(135deg, ${C.accent}, ${C.primary})`, color: "#fff", fontWeight: 800, fontFamily: "'Outfit',sans-serif" }}
          >
            <span style={{ position: "absolute", inset: 0, borderRadius: "50%", overflow: "hidden", display: "flex", alignItems: "center", justifyContent: "center" }}>
              {student.photo
                ? <img src={student.photo} alt="Your profile" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
                : student.name.split(" ").map((w) => w[0]).join("").slice(0, 2)}
            </span>
            <span style={{ position: "absolute", bottom: -3, right: -3, width: 20, height: 20, borderRadius: "50%", background: "#fff", border: `1.5px solid ${C.line}`, display: "flex", alignItems: "center", justifyContent: "center", color: C.primaryDark, boxShadow: SHADOW_SM }}>
              <Camera size={11} />
            </span>
          </button>
          <input ref={fileRef} type="file" accept="image/*" style={{ display: "none" }} onChange={(e) => { const f = e.target.files && e.target.files[0]; if (f) onPhotoChange(URL.createObjectURL(f)); e.target.value = ""; }} />
          <div style={{ minWidth: 0 }}>
            <div className="lt-h" style={{ fontWeight: 800, fontSize: 13.5, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{student.name}</div>
            <div style={{ marginTop: 3 }}><SchoolBadge school={student.target} small /></div>
          </div>
        </div>
        <button className="lt-btn lt-h" onClick={onSignOut} style={{ marginTop: 10, width: "100%", background: "none", border: "none", color: C.sub, fontSize: 12.5, fontWeight: 700, cursor: "pointer", textAlign: "center" }}>
          Sign out
        </button>
      </div>
    </aside>
  );
}


/* ================= MENTOR SIDEBAR ================= */
const MENTOR_NAV = [
  { id: "mentorDash", label: "Dashboard", icon: LayoutDashboard },
  { id: "mentorMessages", label: "Messages", icon: MessageCircle },
  { id: "mentorSchedule", label: "Schedule", icon: Calendar },
];

function MentorSidebar({ page, nav, mentor, onEdit, onSignOut }) {
  return (
    <aside style={{ width: 244, flexShrink: 0, position: "fixed", top: 0, bottom: 0, left: 0, background: "#fff", borderRight: `1px solid ${C.line}`, display: "flex", flexDirection: "column", padding: "26px 16px 20px", zIndex: 20 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "0 10px", marginBottom: 8 }}>
        <img src={LOGO_IMG} alt="LinkTeen logo" style={{ width: 42, height: 42, borderRadius: "50%", boxShadow: "0 6px 16px rgba(164,101,226,.3)", border: `1.5px solid ${C.line}` }} />
        <span className="lt-h" style={{ fontSize: 21, fontWeight: 800 }}>LinkTeen</span>
      </div>
      <div className="lt-h" style={{ fontSize: 11, fontWeight: 800, color: C.accent, letterSpacing: 1.5, textTransform: "uppercase", padding: "0 12px", marginBottom: 22 }}>Mentor Studio</div>
      <nav style={{ display: "flex", flexDirection: "column", gap: 5 }}>
        {MENTOR_NAV.map((n) => {
          const active = page === n.id;
          return (
            <button
              key={n.id}
              className="lt-btn lt-h lt-nav"
              onClick={() => nav(n.id)}
              style={{
                display: "flex", alignItems: "center", gap: 12, padding: "12px 14px",
                borderRadius: 15, border: "none", cursor: "pointer", fontSize: 14.5, fontWeight: 700,
                background: active ? C.softPurple : "transparent", color: active ? C.accent : C.sub,
              }}
            >
              <n.icon size={19} /> {n.label}
            </button>
          );
        })}
      </nav>
      <div style={{ marginTop: "auto" }}>
        <div style={{ background: C.bg, border: `1px solid ${C.line}`, borderRadius: 18, padding: 15 }}>
          <div style={{ display: "flex", gap: 11, alignItems: "center", marginBottom: 12 }}>
            <div style={{ width: 42, height: 42, borderRadius: "50%", overflow: "hidden", background: `linear-gradient(135deg, ${C.accent}, #C79BEF)`, display: "flex", alignItems: "center", justifyContent: "center", color: "#fff", fontWeight: 800, fontFamily: "'Outfit',sans-serif", flexShrink: 0 }}>
              {mentor.photo ? <img src={mentor.photo} alt="" style={{ width: "100%", height: "100%", objectFit: "cover" }} /> : mentor.name.split(" ").map((w) => w[0]).join("").slice(0, 2)}
            </div>
            <div style={{ minWidth: 0 }}>
              <div className="lt-h" style={{ fontWeight: 800, fontSize: 13.5, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{mentor.name}</div>
              <div style={{ marginTop: 3 }}><SchoolBadge school={mentor.school} year={mentor.year} small /></div>
            </div>
          </div>
          <GhostBtn onClick={onEdit} style={{ width: "100%", justifyContent: "center", padding: "8px 14px", fontSize: 13, color: C.accent }}><Edit3 size={14} /> Edit Profile</GhostBtn>
          <button className="lt-btn lt-h" onClick={onSignOut} style={{ marginTop: 10, width: "100%", background: "none", border: "none", color: C.sub, fontSize: 12.5, fontWeight: 700, cursor: "pointer", textAlign: "center" }}>
            Sign out
          </button>
        </div>
      </div>
    </aside>
  );
}

/* ================= MENTOR DASHBOARD ================= */
function MentorDashboard({ mentor, journey, onAddExperience, onEdit, toast, onMessage }) {
  const [filter, setFilter] = useState("all");
  const [showAdd, setShowAdd] = useState(false);
  const [f, setF] = useState({ t: "", story: "", why: "", note: "" });
  const students = DEMO_STUDENTS.filter((st) => filter === "all" || st.target === filter);
  const s = SCHOOLS[mentor.school];

  return (
    <div>
      <div className="lt-fadeup" style={{ maxWidth: 1020 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 18, marginBottom: 26, flexWrap: "wrap" }}>
          <div style={{ width: 72, height: 72, borderRadius: "50%", overflow: "hidden", background: `linear-gradient(135deg, ${C.accent}, #C79BEF)`, display: "flex", alignItems: "center", justifyContent: "center", color: "#fff", fontFamily: "'Outfit',sans-serif", fontWeight: 800, fontSize: 24, boxShadow: "0 0 0 3px #fff, 0 0 0 5px " + C.accent + "44", flexShrink: 0 }}>
            {mentor.photo ? <img src={mentor.photo} alt="" style={{ width: "100%", height: "100%", objectFit: "cover" }} /> : mentor.name.split(" ").map((w) => w[0]).join("").slice(0, 2)}
          </div>
          <div style={{ flex: 1 }}>
            <div style={{ display: "flex", gap: 10, alignItems: "center", flexWrap: "wrap" }}>
              <h1 className="lt-h" style={{ fontSize: 27, fontWeight: 800, margin: 0 }}>{mentor.name}</h1>
              <SchoolBadge school={mentor.school} year={mentor.year} />
            </div>
            <div style={{ color: C.sub, fontSize: 14, marginTop: 4 }}>{mentor.roleTitle || "Mentor"} · {s.name}</div>
          </div>
          <GhostBtn onClick={onEdit}><Edit3 size={15} /> Edit Profile</GhostBtn>
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))", gap: 16, marginBottom: 24 }}>
          {[
            { label: "Students helped", val: 12, icon: Users, c: C.accent },
            { label: "Messages this week", val: 28, icon: MessageCircle, c: C.primary },
            { label: "Mentor rating", val: "4.9 ★", icon: Star, c: "#E7A93B" },
          ].map((st) => (
            <Card key={st.label} style={{ padding: 20 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 8, color: st.c }}>
                <st.icon size={17} /><span className="lt-h" style={{ fontSize: 12, fontWeight: 800, textTransform: "uppercase", letterSpacing: 0.8, color: C.sub }}>{st.label}</span>
              </div>
              <div className="lt-h" style={{ fontSize: 28, fontWeight: 800 }}>{st.val}</div>
            </Card>
          ))}
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(min(100%, 340px), 1fr))", gap: 20 }}>
          <Card style={{ padding: 24 }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 6, gap: 10, flexWrap: "wrap" }}>
              <h2 className="lt-h" style={{ fontSize: 18, fontWeight: 800, margin: 0 }}>{mentor.school === "berkeley" ? "Your Berkeley Journey" : `Your ${s.short} Journey (Berkeley framework)`}</h2>
              <PrimaryBtn onClick={() => setShowAdd(true)} style={{ background: `linear-gradient(135deg, ${C.accent}, #8A48CC)`, boxShadow: "0 6px 16px rgba(164,101,226,.3)" }}>
                <Plus size={15} /> {journey.length ? "Add Experience" : "Add Your Berkeley Journey"}
              </PrimaryBtn>
            </div>
            <p style={{ fontSize: 12.5, color: C.sub, margin: "0 0 14px" }}>Personal stories, why each mattered for Berkeley, and explicit notes on UCLA/UCSD applicability.</p>
            {journey.length === 0 && (
              <div style={{ border: `1.5px dashed ${C.line}`, borderRadius: 16, padding: "26px 18px", textAlign: "center", color: C.sub, fontSize: 13.5 }}>
                No experiences yet. Students want the real story — start with the moment you think got you in.
              </div>
            )}
            {journey.map((e, i) => (
              <div key={i} style={{ borderTop: i ? `1px solid ${C.line}` : "none", padding: "14px 0" }}>
                <div className="lt-h" style={{ fontWeight: 800, fontSize: 15 }}>{e.t}</div>
                <p style={{ fontSize: 13.5, color: "#4A382C", lineHeight: 1.55, margin: "6px 0" }}>{e.story}</p>
                {e.why && <div style={{ fontSize: 12.5, background: C.soft, color: C.primaryDark, borderRadius: 12, padding: "8px 12px", marginBottom: 6 }}><b>Why it mattered for Berkeley:</b> {e.why}</div>}
                {e.note && <div style={{ fontSize: 12.5, background: C.softPurple, color: "#6E44A0", borderRadius: 12, padding: "8px 12px" }}><b>UCLA / UCSD:</b> {e.note}</div>}
              </div>
            ))}
          </Card>

          <Card style={{ padding: 24 }}>
            <h2 className="lt-h" style={{ fontSize: 18, fontWeight: 800, margin: "0 0 12px" }}>My Students</h2>
            <div style={{ display: "flex", gap: 7, marginBottom: 14, flexWrap: "wrap" }}>
              {[["all", "All"], ["berkeley", "Berkeley"], ["ucla", "UCLA"], ["ucsd", "UCSD"]].map(([id, label]) => (
                <Chip key={id} active={filter === id} onClick={() => setFilter(id)}>{label}</Chip>
              ))}
            </div>
            {students.map((st, i) => (
              <div key={st.name} style={{ display: "flex", gap: 11, alignItems: "center", padding: "11px 0", borderTop: i ? `1px solid ${C.line}` : "none" }}>
                <div style={{ width: 38, height: 38, borderRadius: "50%", background: `linear-gradient(135deg, ${C.primary}, ${C.accent})`, color: "#fff", display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 800, fontSize: 13, fontFamily: "'Outfit',sans-serif", flexShrink: 0 }}>
                  {st.name.split(" ").map((w) => w[0]).join("")}
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ display: "flex", gap: 7, alignItems: "center" }}>
                    <span className="lt-h" style={{ fontWeight: 700, fontSize: 13.5 }}>{st.name}</span>
                    <SchoolBadge school={st.target} small />
                    {st.demo && <DemoBadge />}
                  </div>
                  <div style={{ fontSize: 12, color: C.sub, marginTop: 2 }}>Grade {st.grade} · {st.interest} · {st.last}</div>
                </div>
                <button className="lt-btn" onClick={() => onMessage(st.id)} style={{ background: "#fff", border: `1.5px solid ${C.line}`, borderRadius: 12, padding: 8, color: C.accent, display: "flex", cursor: "pointer", flexShrink: 0 }} aria-label={`Message ${st.name}`}>
                  <MessageCircle size={15} />
                </button>
              </div>
            ))}
          </Card>
        </div>

        {showAdd && (
          <Modal title="Add an experience to your journey" onClose={() => setShowAdd(false)}>
            <Field label="Experience title"><input style={inputStyle} value={f.t} onChange={(e) => setF({ ...f, t: e.target.value })} placeholder="COSMOS Cluster 5 at UC Davis" /></Field>
            <Field label="Your personal story"><textarea style={{ ...inputStyle, minHeight: 90, resize: "vertical" }} value={f.story} onChange={(e) => setF({ ...f, story: e.target.value })} placeholder="What actually happened — including the messy parts…" /></Field>
            <Field label="Why it mattered for Berkeley"><input style={inputStyle} value={f.why} onChange={(e) => setF({ ...f, why: e.target.value })} placeholder="What Berkeley readers valued about it" /></Field>
            <Field label="UCLA / UCSD applicability"><input style={inputStyle} value={f.note} onChange={(e) => setF({ ...f, note: e.target.value })} placeholder="How the same experience strengthens a UCLA or UCSD app" /></Field>
            <PrimaryBtn big style={{ width: "100%", justifyContent: "center", background: `linear-gradient(135deg, ${C.accent}, #8A48CC)`, boxShadow: "0 8px 20px rgba(164,101,226,.35)" }} onClick={() => {
              if (!f.t.trim()) return;
              onAddExperience(f);
              setF({ t: "", story: "", why: "", note: "" });
              setShowAdd(false);
              toast("Experience added — it's now visible on your Explore journey ✨");
            }}>
              <Plus size={17} /> Add Experience
            </PrimaryBtn>
          </Modal>
        )}
      </div>
    </div>
  );
}

/* ================= APP ================= */
export default function App() {
  const [toasts, setToasts] = useState([]);
  const toastId = useRef(0);
  const toast = (msg, icon) => {
    const id = ++toastId.current;
    setToasts((t) => [...t, { id, msg, icon }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 4000);
  };

  const [page, setPage] = useState("role");
  const [student, setStudent] = useState(null);
  const [mentorProfile, setMentorProfile] = useState(null);
  const [customMentors, setCustomMentors] = useState([]);
  const [mentorJourney, setMentorJourney] = useState([]);
  const [session, setSession] = useState(null);
  const [profile, setProfile] = useState(null);
  const [pendingRole, setPendingRole] = useState("student");
  const [realStudents, setRealStudents] = useState([]);
  const [booting, setBooting] = useState(true);
  const [bookings, setBookings] = useState([]);
  const [bookingMentor, setBookingMentor] = useState(null);
  const [myAvail, setMyAvail] = useState({});
  const roleRef = useRef(null);
  const isMobile = useIsMobile();
  const [journeyId, setJourneyId] = useState(null);
  const [milestones, setMilestones] = useState([]);
  const [chats, setChats] = useState(INIT_CHATS);
  const [activeChat, setActiveChat] = useState("m1");
  const [draft, setDraft] = useState("");
  const [typing, setTyping] = useState(null);
  const [messagedMentors, setMessagedMentors] = useState(["m1"]);
  const [mentorChats, setMentorChats] = useState(INIT_MENTOR_CHATS);
  const [mentorActiveChat, setMentorActiveChat] = useState("s1");
  const [mentorDraft, setMentorDraft] = useState("");
  const [mentorTyping, setMentorTyping] = useState(null);
  const replyIdx = useRef({});
  const msId = useRef(0);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => { setSession(data.session || null); setBooting(false); });
    const { data: sub } = supabase.auth.onAuthStateChange((_e, s) => setSession(s));
    return () => sub.subscription.unsubscribe();
  }, []);

  useEffect(() => { roleRef.current = profile ? profile.role : null; }, [profile]);

  useEffect(() => {
    if (!session) return;
    let alive = true;
    (async () => {
      try {
        const p = await api.getMyProfile();
        if (!alive) return;
        const rows = await api.fetchMentorsRaw();
        if (!alive) return;
        setCustomMentors(rows.filter((r) => r.id !== session.user.id).map(profileToMentor));
        if (!p) {
          const role = (session.user.user_metadata && session.user.user_metadata.role) || pendingRole;
          setPage(role === "mentor" ? "mentorReg" : "onboarding");
          return;
        }
        setProfile(p);
        const { chats: loaded, contacts } = await api.fetchMyChats(session.user.id);
        if (!alive) return;
        const myBookings = await api.fetchBookings(session.user.id, p.role);
        if (!alive) return;
        setBookings(myBookings);
        if (p.role === "student") {
          setStudent({ name: p.name, grade: p.grade || "10", target: safeSchool(p.target), interests: p.interests || [], photo: null });
          setMilestones(await api.fetchMilestones());
          setChats((c) => ({ ...INIT_CHATS, ...loaded }));
          setPage("explore");
        } else {
          setMentorProfile({ id: p.id, name: p.name, school: safeSchool(p.school), year: p.year || 2024, roleTitle: p.role_title || "", bio: p.bio || "", tags: p.tags || [], email: session.user.email, photo: null });
          setMyAvail(p.availability || {});
          const myExps = await api.fetchMyExperiences();
          if (!alive) return;
          setMentorJourney(myExps.map((q) => ({ t: q.title, story: q.story, why: q.why, note: q.note })));
          setMentorChats((c) => ({ ...INIT_MENTOR_CHATS, ...loaded }));
          setRealStudents(contacts.filter((x) => x.role === "student").map(profileToStudentContact));
          setPage("mentorDash");
        }
      } catch (err) {
        console.error(err);
        toast("Couldn't load your data — check your Supabase setup");
      }
    })();
    return () => { alive = false; };
  }, [session]);

  useEffect(() => {
    if (!session) return;
    const unsub = api.subscribeToMessages(session.user.id, async ({ senderId, entry }) => {
      if (roleRef.current === "mentor") {
        setMentorChats((c) => ({ ...c, [senderId]: [...(c[senderId] || []), entry] }));
        const prof = await api.getProfile(senderId);
        if (prof) setRealStudents((rs) => (rs.some((x) => x.id === senderId) ? rs : [profileToStudentContact(prof), ...rs]));
      } else {
        setChats((c) => ({ ...c, [senderId]: [...(c[senderId] || []), entry] }));
        const prof = await api.getProfile(senderId);
        if (prof && prof.role === "mentor") {
          setCustomMentors((cm) => (cm.some((x) => x.id === senderId) ? cm : [profileToMentor({ ...prof, experiences: [] }), ...cm]));
        }
      }
    });
    return unsub;
  }, [session]);

  const handleSignOut = async () => {
    await api.signOut();
    setSession(null); setProfile(null); setStudent(null); setMentorProfile(null);
    setMilestones([]); setCustomMentors([]); setRealStudents([]); setBookings([]); setMyAvail({});
    setChats(INIT_CHATS); setMentorChats(INIT_MENTOR_CHATS); setMentorJourney([]);
    setPage("role");
    toast("Signed out — see you soon! 👋");
  };

  const saveAvailability = (next) => {
    setMyAvail(next);
    api.saveAvailability(next).catch(() => {});
  };

  const setBookingStatus = (id, status) => {
    setBookings((bs) => bs.map((b) => (b.id === id ? { ...b, status } : b)));
    api.updateBookingStatus(id, status).catch(() => {});
    toast(`Call ${status.toLowerCase()}`, <Calendar size={16} />);
  };

  const allMentors = [...customMentors, ...MENTORS];


  const registerMentor = (m) => {
    const id = (session && session.user.id) || (mentorProfile && mentorProfile.id) || "u" + Date.now();
    setMentorProfile({ ...m, id });
    api.upsertProfile({ role: "mentor", name: m.name, school: m.school, year: Number(m.year) || null, role_title: m.roleTitle, bio: m.bio, tags: m.tags })
      .then((p) => setProfile(p))
      .catch(() => toast("Couldn't save your profile — check your Supabase setup"));
    setCustomMentors((cm) => {
      const prev = cm.find((x) => x.id === id);
      const entry = {
        id, demo: false,
        name: m.name, school: m.school, year: Number(m.year),
        major: "", role: m.roleTitle || "Mentor", photo: m.photo,
        color: C.accent, color2: "#C79BEF",
        cats: deriveCats(m.tags, m.bio), tags: m.tags,
        rating: null, studentsHelped: 0,
        bio: m.bio || `${SCHOOLS[m.school].short} '${String(m.year).slice(2)} mentor on LinkTeen.`,
        moment: "",
        path: prev ? prev.path : [SCHOOLS[m.school].name],
        exp: prev ? prev.exp : [],
        replies: [],
      };
      return [entry, ...cm.filter((x) => x.id !== id)];
    });
  };

  const addMentorExperience = (e) => {
    setMentorJourney((j) => [...j, e]);
    api.addExperience(e, mentorJourney.length).catch(() => toast("Couldn't save that experience — check your connection"));
    if (!mentorProfile) return;
    setCustomMentors((cm) => cm.map((x) => {
      if (x.id !== mentorProfile.id) return x;
      const exp = [...x.exp, { t: e.t, story: e.story, learned: "", time: "", why: e.why, note: e.note, alts: [] }];
      const path = [...exp.map((q) => (q.t.length > 26 ? q.t.slice(0, 24) + "…" : q.t)), SCHOOLS[x.school].name];
      return { ...x, exp, path };
    }));
  };

  const openJourney = (id) => { setJourneyId(id); setPage("journey"); window.scrollTo(0, 0); };

  const talkTo = (mentorId, topic) => {
    const m = allMentors.find((x) => x.id === mentorId);
    setActiveChat(mentorId);
    setDraft(
      topic
        ? `Hey ${m.name.split(" ")[0]}, I'm looking at your experience with ${topic} and would love to hear how it helped you get into Berkeley, and if you think it would help for UCLA/UCSD too...`
        : `Hey ${m.name.split(" ")[0]}, I'm looking at your journey and would love to hear how it helped you get into ${SCHOOLS[m.school].short}...`
    );
    setPage("messages");
  };

  const sendMessage = async () => {
    const text = draft.trim();
    if (!text) return;
    setDraft("");
    const now = new Date().toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
    setChats((c) => ({ ...c, [activeChat]: [...(c[activeChat] || []), { from: "me", text, time: now }] }));
    if (!messagedMentors.includes(activeChat)) setMessagedMentors((mm) => [...mm, activeChat]);
    const contact = allMentors.find((x) => x.id === activeChat);
    if (contact && !contact.demo) {
      try { await api.sendMessage(activeChat, text); }
      catch { toast("Message didn't send — check your connection"); }
    }
  };

  const sendMentorMessage = async () => {
    const text = mentorDraft.trim();
    if (!text) return;
    setMentorDraft("");
    const now = new Date().toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
    setMentorChats((c) => ({ ...c, [mentorActiveChat]: [...(c[mentorActiveChat] || []), { from: "me", text, time: now }] }));
    const contact = [...realStudents, ...STUDENT_CONTACTS].find((x) => x.id === mentorActiveChat);
    if (contact && !contact.demo) {
      try { await api.sendMessage(mentorActiveChat, text); }
      catch { toast("Message didn't send — check your connection"); }
    }
  };

  const addMilestone = (m) => {
    const tempId = "t" + (++msId.current);
    setMilestones((ms) => [...ms, { id: tempId, status: "Not Started", ...m }]);
    toast(`Added to your roadmap: ${m.title}`, <Map size={16} />);
    api.addMilestone(m, milestones.length)
      .then((row) => setMilestones((ms) => ms.map((x) => (x.id === tempId ? { ...x, id: row.id } : x))))
      .catch(() => {});
  };

  const addBooking = (b) => {
    const entry = { ...b, id: "b" + Date.now() };
    setBookings((bs) => [...bs, entry]);
    toast(`${b.mins}-min call requested with ${b.mentorName.split(" ")[0]} — ${b.day} at ${b.time}`, <Calendar size={16} />);
    api.createBooking(entry).catch(() => {});
  };

  /* ---- routing ---- */
  if (booting) {
    return (
      <div className="lt-app" style={{ minHeight: "100vh", background: C.bg, display: "flex", alignItems: "center", justifyContent: "center" }}>
        <GlobalStyle />
        <div className="lt-h" style={{ color: C.sub, fontWeight: 700, fontSize: 15 }}>Loading LinkTeen…</div>
      </div>
    );
  }
  if (page === "role") {
    return (
      <div className="lt-app"><GlobalStyle /><Toasts toasts={toasts} />
        <RoleSelect onPick={(r) => { setPendingRole(r); setPage("auth"); }} />
      </div>
    );
  }
  if (page === "auth") {
    return (
      <div className="lt-app"><GlobalStyle /><Toasts toasts={toasts} />
        <AuthScreen role={pendingRole} onBack={() => setPage("role")} />
      </div>
    );
  }
  if (page === "onboarding") {
    return (
      <div className="lt-app"><GlobalStyle /><Toasts toasts={toasts} />
        <Onboarding onDone={(s) => {
          setStudent(s);
          api.upsertProfile({ role: "student", name: s.name, grade: s.grade, target: s.target, interests: s.interests })
            .then((p) => setProfile(p))
            .catch(() => toast("Couldn't save your profile — check your Supabase setup"));
          setPage("explore");
          toast(`Welcome to LinkTeen, ${s.name.split(" ")[0]}! 🐻`);
        }} />
      </div>
    );
  }
  if (page === "mentorReg") {
    return (
      <div className="lt-app"><GlobalStyle /><Toasts toasts={toasts} />
        <MentorRegistration onDone={(m) => { registerMentor(m); setPage("mentorDash"); toast("Mentor profile is live — students can now find you on Explore 🎉"); }} />
      </div>
    );
  }
  if ((page === "mentorDash" || page === "mentorMessages" || page === "mentorSchedule") && !mentorProfile) {
    return (
      <div className="lt-app" style={{ minHeight: "100vh", background: C.bg, display: "flex", alignItems: "center", justifyContent: "center" }}>
        <GlobalStyle />
        <div className="lt-h" style={{ color: C.sub, fontWeight: 700, fontSize: 15 }}>Loading your Mentor Studio…</div>
      </div>
    );
  }
  if (page === "mentorDash" || page === "mentorMessages" || page === "mentorSchedule") {
    return (
      <div className="lt-app" style={{ background: `radial-gradient(1000px 520px at 100% -5%, ${C.accent}18, transparent), ${C.bg}`, minHeight: "100vh", position: "relative" }}>
        <GlobalStyle /><Toasts toasts={toasts} />
        {!isMobile && <MentorSidebar page={page} nav={setPage} mentor={mentorProfile} onEdit={() => setPage("mentorReg")} onSignOut={handleSignOut} />}
        {isMobile && (
          <MobileHeader right={<>
            <MobileIconButton onClick={() => setPage("mentorReg")} label="Edit profile"><Edit3 size={17} /></MobileIconButton>
            <MobileIconButton onClick={handleSignOut} label="Sign out"><LogOut size={17} /></MobileIconButton>
          </>} />
        )}
        <main style={isMobile ? { padding: "14px 14px 96px" } : { marginLeft: 244, padding: "34px 36px", maxWidth: 1180 }}>
          {page === "mentorDash" && (
            <MentorDashboard
              mentor={mentorProfile}
              journey={mentorJourney}
              onAddExperience={addMentorExperience}
              onEdit={() => setPage("mentorReg")}
              toast={toast}
              onMessage={(sid) => { setMentorActiveChat(sid); setPage("mentorMessages"); }}
            />
          )}
          {page === "mentorMessages" && (
            <Messages
              contacts={STUDENT_CONTACTS}
              chats={mentorChats}
              activeChat={mentorActiveChat}
              setActiveChat={setMentorActiveChat}
              draft={mentorDraft}
              setDraft={setMentorDraft}
              sendMessage={sendMentorMessage}
              typing={mentorTyping}
              toast={toast}
              isMentorView
              bookings={bookings}
              onBook={() => {}}
              emptyText={(c) => `Say hi to ${c.name.split(" ")[0]} — Grade ${c.grade}, targeting ${SCHOOLS[c.school].name}. They connected with you for guidance.`}
            />
          )}
          {page === "mentorSchedule" && (
            <MentorSchedule
              mentor={mentorProfile}
              avail={myAvail}
              setAvail={saveAvailability}
              bookings={bookings}
              setStatus={setBookingStatus}
              onMessage={(sid) => { setMentorActiveChat(sid); setPage("mentorMessages"); }}
            />
          )}
        </main>
        {isMobile && <MobileTabBar items={MENTOR_NAV} page={page} nav={setPage} />}
      </div>
    );
  }

  /* student shell */
  if (!student) {
    return (
      <div className="lt-app" style={{ minHeight: "100vh", background: C.bg, display: "flex", alignItems: "center", justifyContent: "center" }}>
        <GlobalStyle />
        <div className="lt-h" style={{ color: C.sub, fontWeight: 700, fontSize: 15 }}>Loading your LinkTeen…</div>
      </div>
    );
  }
  return (
    <div className="lt-app" style={{ background: `radial-gradient(1000px 520px at 100% -5%, ${C.accent}14, transparent), ${C.bg}`, minHeight: "100vh", position: "relative" }}>
      <GlobalStyle />
      <Toasts toasts={toasts} />
      {!isMobile && <Sidebar page={page} nav={setPage} student={student} onSignOut={handleSignOut} onPhotoChange={(url) => { setStudent((s) => ({ ...s, photo: url })); toast("Profile photo updated 📸"); }} />}
      {isMobile && (
        <MobileHeader right={<>
          <MobileAvatarButton student={student} onPhotoChange={(url) => { setStudent((s) => ({ ...s, photo: url })); toast("Profile photo updated 📸"); }} />
          <MobileIconButton onClick={handleSignOut} label="Sign out"><LogOut size={17} /></MobileIconButton>
        </>} />
      )}
      <main style={isMobile ? { padding: "14px 14px 96px" } : { marginLeft: 244, padding: "34px 36px", maxWidth: 1180 }}>
        {page === "explore" && <Explore student={student} mentors={allMentors} openJourney={openJourney} talkTo={talkTo} />}
        {page === "journey" && (
          <JourneyDetail
            mentorId={journeyId}
            mentors={allMentors}
            back={() => setPage("explore")}
            talkTo={talkTo}
            onBookMentor={(m) => setBookingMentor(m)}
            addToRoadmap={(m, e) => addMilestone({ title: e.t, desc: e.story, category: m.cats[0], tag: `From ${m.name.split(" ")[0]}'s ${SCHOOLS[m.school].short} path`, mentorId: m.id })}
          />
        )}
        {page === "roadmap" && <Roadmap mentors={allMentors} milestones={milestones} setMilestones={setMilestones} goExplore={() => setPage("explore")} addMilestone={addMilestone} talkTo={talkTo} toast={toast} />}
        {page === "messages" && <Messages contacts={allMentors} chats={chats} activeChat={activeChat} setActiveChat={setActiveChat} draft={draft} setDraft={setDraft} sendMessage={sendMessage} typing={typing} toast={toast} onBook={addBooking} bookings={bookings} emptyText={(c) => `Say hi to ${c.name.split(" ")[0]} — ask about any step in their ${SCHOOLS[c.school].short} journey.`} />}
        {page === "dashboard" && <Dashboard student={student} milestones={milestones} messagedMentors={messagedMentors} bookings={bookings} goRoadmap={() => setPage("roadmap")} openJourney={openJourney} />}
      </main>
      {isMobile && <MobileTabBar items={NAV} page={page} nav={setPage} />}
      {bookingMentor && (
        <BookingModal
          mentor={bookingMentor}
          onClose={() => setBookingMentor(null)}
          onConfirm={(b) => { setBookingMentor(null); addBooking(b); }}
        />
      )}
    </div>
  );
}
