import { createClient } from "@supabase/supabase-js";

// ============================================================
//  PASTE YOUR TWO SUPABASE VALUES BELOW (between the quotes).
//  Find them at: supabase.com → your project → Settings → API
//    1. "Project URL"        → SUPABASE_URL
//    2. "anon public" key    → SUPABASE_ANON_KEY
//  (The anon key is safe to be public — the database rules
//   decide what anyone can actually do with it.)
// ============================================================
const SUPABASE_URL = "PASTE_YOUR_PROJECT_URL_HERE";
const SUPABASE_ANON_KEY = "PASTE_YOUR_ANON_PUBLIC_KEY_HERE";

export const SUPABASE_ENABLED =
  !SUPABASE_URL.includes("PASTE") && !SUPABASE_ANON_KEY.includes("PASTE");

export const supabase = SUPABASE_ENABLED
  ? createClient(SUPABASE_URL, SUPABASE_ANON_KEY)
  : null;
