import { createClient } from "@supabase/supabase-js";

// ============================================================
// PASTE YOUR TWO VALUES FROM SUPABASE HERE
// (Supabase dashboard -> Project Settings -> API)
// The anon key is SAFE to be public — security is enforced by
// the database rules in supabase-setup.sql, not by hiding this.
// ============================================================
const SUPABASE_URL = "PASTE_YOUR_PROJECT_URL_HERE";
const SUPABASE_ANON_KEY = "PASTE_YOUR_ANON_PUBLIC_KEY_HERE";

export const SUPABASE_CONFIGURED = SUPABASE_URL.startsWith("https://");

export const supabase = createClient(
  SUPABASE_CONFIGURED ? SUPABASE_URL : "https://not-configured-yet.supabase.co",
  SUPABASE_CONFIGURED ? SUPABASE_ANON_KEY : "not-configured"
);
