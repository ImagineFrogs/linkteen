import { createClient } from "@supabase/supabase-js";

// ============================================================
// PASTE YOUR TWO VALUES FROM SUPABASE HERE
// (Supabase dashboard -> Project Settings -> API)
// The anon key is SAFE to be public — security is enforced by
// the database rules in supabase-setup.sql, not by hiding this.
// ============================================================
const SUPABASE_URL = "https://yiwwhztrvlnvxaxnrbkp.supabase.co";
const SUPABASE_ANON_KEY = "sb_publishable_U7Yan4EWHmv6KtxL5ASpiw_Wxa54hl0";

export const SUPABASE_CONFIGURED = SUPABASE_URL.startsWith("https://");

export const supabase = createClient(
  SUPABASE_CONFIGURED ? SUPABASE_URL : "https://not-configured-yet.supabase.co",
  SUPABASE_CONFIGURED ? SUPABASE_ANON_KEY : "not-configured"
);
