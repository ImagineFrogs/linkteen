-- ============================================================
-- LinkTeen scheduling add-on
-- Run this AFTER supabase-setup.sql
-- Supabase -> SQL Editor -> New query -> paste -> Run
-- ============================================================

-- Mentor weekly availability (repeats every week)
create table if not exists public.availability (
  id bigint generated always as identity primary key,
  mentor_id uuid not null references public.profiles(id) on delete cascade,
  weekday int not null check (weekday between 0 and 6),  -- 0 = Sunday
  start_hour int not null check (start_hour between 0 and 23),
  end_hour int not null check (end_hour between 1 and 24),
  created_at timestamptz default now()
);

-- Call bookings
create table if not exists public.bookings (
  id bigint generated always as identity primary key,
  mentor_id uuid not null references public.profiles(id) on delete cascade,
  student_id uuid not null references public.profiles(id) on delete cascade,
  starts_at timestamptz not null,
  duration_min int not null default 30,
  price_cents int not null default 3900,
  status text not null default 'requested',  -- requested | confirmed | declined | done
  room text not null default '',
  created_at timestamptz default now()
);

alter table public.availability enable row level security;
alter table public.bookings enable row level security;

-- Availability: everyone signed in can read (students need to see open slots);
-- mentors manage only their own
drop policy if exists "availability readable" on public.availability;
create policy "availability readable" on public.availability
  for select to authenticated using (true);
drop policy if exists "mentor writes own availability" on public.availability;
create policy "mentor writes own availability" on public.availability
  for insert to authenticated with check (mentor_id = auth.uid());
drop policy if exists "mentor deletes own availability" on public.availability;
create policy "mentor deletes own availability" on public.availability
  for delete to authenticated using (mentor_id = auth.uid());

-- Bookings: only the two people involved can see it
drop policy if exists "read own bookings" on public.bookings;
create policy "read own bookings" on public.bookings
  for select to authenticated using (student_id = auth.uid() or mentor_id = auth.uid());
drop policy if exists "student creates booking" on public.bookings;
create policy "student creates booking" on public.bookings
  for insert to authenticated with check (student_id = auth.uid());
drop policy if exists "either party updates booking" on public.bookings;
create policy "either party updates booking" on public.bookings
  for update to authenticated using (student_id = auth.uid() or mentor_id = auth.uid());

alter publication supabase_realtime add table public.bookings;
