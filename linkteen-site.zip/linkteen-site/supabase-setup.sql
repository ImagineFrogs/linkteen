-- ============================================================
-- LinkTeen database setup — paste this whole file into
-- Supabase: SQL Editor -> New query -> Run
-- ============================================================

-- 1) PROFILES: one row per signed-up user (student or mentor)
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  role text not null check (role in ('student','mentor')),
  name text not null default '',
  grade text,
  target text,
  interests text[] default '{}',
  school text,
  year int,
  role_title text,
  bio text default '',
  tags text[] default '{}',
  created_at timestamptz default now()
);

-- 2) EXPERIENCES: steps of a mentor's journey
create table public.experiences (
  id bigint generated always as identity primary key,
  mentor_id uuid not null references public.profiles(id) on delete cascade,
  title text not null,
  story text default '',
  why text default '',
  note text default '',
  position int default 0,
  created_at timestamptz default now()
);

-- 3) MILESTONES: a student's roadmap items
create table public.milestones (
  id bigint generated always as identity primary key,
  student_id uuid not null references public.profiles(id) on delete cascade,
  title text not null,
  description text default '',
  target_date text default '',
  category text default '',
  tag text default '',
  status text default 'Not Started',
  position int default 0,
  mentor_ref text,
  created_at timestamptz default now()
);

-- 4) MESSAGES: real chat between two users
create table public.messages (
  id bigint generated always as identity primary key,
  sender_id uuid not null references public.profiles(id) on delete cascade,
  recipient_id uuid not null references public.profiles(id) on delete cascade,
  body text not null,
  created_at timestamptz default now()
);

-- ---------- SECURITY RULES (who can see/change what) ----------
alter table public.profiles enable row level security;
alter table public.experiences enable row level security;
alter table public.milestones enable row level security;
alter table public.messages enable row level security;

-- Profiles: any signed-in user can browse the directory; you edit only your own
create policy "profiles are readable" on public.profiles
  for select to authenticated using (true);
create policy "insert own profile" on public.profiles
  for insert to authenticated with check (auth.uid() = id);
create policy "update own profile" on public.profiles
  for update to authenticated using (auth.uid() = id);

-- Experiences: everyone signed in can read; mentors manage their own
create policy "experiences are readable" on public.experiences
  for select to authenticated using (true);
create policy "mentor inserts own experiences" on public.experiences
  for insert to authenticated with check (mentor_id = auth.uid());
create policy "mentor updates own experiences" on public.experiences
  for update to authenticated using (mentor_id = auth.uid());
create policy "mentor deletes own experiences" on public.experiences
  for delete to authenticated using (mentor_id = auth.uid());

-- Milestones: fully private to the student who owns them
create policy "student reads own milestones" on public.milestones
  for select to authenticated using (student_id = auth.uid());
create policy "student inserts own milestones" on public.milestones
  for insert to authenticated with check (student_id = auth.uid());
create policy "student updates own milestones" on public.milestones
  for update to authenticated using (student_id = auth.uid());
create policy "student deletes own milestones" on public.milestones
  for delete to authenticated using (student_id = auth.uid());

-- Messages: only the two people in the conversation can read;
-- you can only send messages as yourself
create policy "read own conversations" on public.messages
  for select to authenticated using (sender_id = auth.uid() or recipient_id = auth.uid());
create policy "send as yourself" on public.messages
  for insert to authenticated with check (sender_id = auth.uid());

-- ---------- REALTIME (messages appear instantly) ----------
alter publication supabase_realtime add table public.messages;
