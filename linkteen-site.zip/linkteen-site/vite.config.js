import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// IMPORTANT: change "linkteen" below to your GitHub repo name if it differs.
export default defineConfig({
  plugins: [react()],
  base: "/linkteen/",
});
